"""Loopback bridge. CPU Ollama chat, CUDA Qwen3-TTS; real models installed separately."""
import argparse, base64, hmac, io, json, os, threading, urllib.request, urllib.parse, urllib.error, wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

class LocalModelFailure(RuntimeError):
    pass

class LoopbackOnlyRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise LocalModelFailure('OLLAMA_REDIRECT: unexpected redirect refused')

class ModelRuntime:
    def __init__(self, model_dir, text_model, ollama_url='http://127.0.0.1:11434'):
        self.model_dir, self.text_model, self.tts = model_dir, text_model, None
        parsed = urllib.parse.urlparse(ollama_url)
        if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost', '::1') or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in ('', '/'):
            raise ValueError('Ollama endpoint must be loopback HTTP')
        self.ollama_url = ollama_url.rstrip('/')
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), LoopbackOnlyRedirect())
        self.lock = threading.Lock()
    def chat(self, messages):
        if not isinstance(messages, list) or not messages or any(not isinstance(m, dict) or m.get('role') not in ('system', 'user', 'assistant') or not isinstance(m.get('content'), str) for m in messages):
            raise ValueError('Invalid messages')
        payload = {'model': self.text_model, 'messages': messages, 'stream': False,
                   'keep_alive': 0, 'options': {'num_gpu': 0, 'num_ctx': 8192, 'num_predict': 256, 'temperature': 0.5}}
        request = urllib.request.Request(self.ollama_url + '/api/chat', data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
        try:
            with self.opener.open(request, timeout=170) as response:
                value = json.load(response)
        except urllib.error.HTTPError as error:
            raw = error.read(8192).decode('utf-8', errors='replace').lower()
            hint = 'inspect Ollama model and runtime'
            if error.code == 404 and 'model' in raw and 'not found' in raw: hint = 'model missing from active model directory'
            elif 'memory' in raw: hint = 'insufficient available memory; close other applications'
            elif 'think' in raw: hint = 'Ollama model thinking option incompatibility'
            elif 'runner' in raw or 'load' in raw: hint = 'Ollama model load or runner failure'
            raise LocalModelFailure('OLLAMA_HTTP_' + str(error.code) + ': ' + hint) from None
        except urllib.error.URLError:
            raise LocalModelFailure('OLLAMA_CONNECT: local Ollama unreachable') from None
        except TimeoutError:
            raise LocalModelFailure('OLLAMA_TIMEOUT: local text inference exceeded 170 seconds') from None
        text = value.get('message', {}).get('content')
        if not isinstance(text, str) or not text.strip():
            raise RuntimeError('Ollama returned no text')
        return {'choices': [{'message': {'role': 'assistant', 'content': text}}]}
    def voice(self, data):
        if data.get('authorized') is not True:
            raise ValueError('Voice authorization required')
        text, reference, encoded = data.get('text'), data.get('reference_text'), data.get('reference_wav')
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 300 or not isinstance(reference, str) or not 1 <= len(reference.strip()) <= 1000 or not isinstance(encoded, str) or len(encoded) > 1500000:
            raise ValueError('Invalid text/reference')
        raw = base64.b64decode(encoded, validate=True)
        with wave.open(io.BytesIO(raw)) as audio:
            if audio.getnchannels() != 1 or audio.getsampwidth() != 2 or audio.getframerate() != 16000 or not 5 <= audio.getnframes() / 16000 <= 15:
                raise ValueError('Expected 5-15 second mono PCM reference')
            pcm = audio.readframes(audio.getnframes())
        import numpy as np
        import torch
        import soundfile as sf
        if not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable')
        if self.tts is None:
            from qwen_tts import Qwen3TTSModel
            self.tts = Qwen3TTSModel.from_pretrained(self.model_dir, device_map='cuda:0', dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16,
                                                    attn_implementation='sdpa', local_files_only=True)
        samples = np.frombuffer(pcm, dtype='<i2').astype(np.float32) / 32768.0
        with torch.inference_mode():
            wavs, rate = self.tts.generate_voice_clone(text=text, language='Chinese', ref_audio=(samples, 16000),
                ref_text=reference, do_sample=False, max_new_tokens=2048)
        output = io.BytesIO()
        sf.write(output, wavs[0], rate, format='WAV', subtype='PCM_16')
        result = output.getvalue()
        if len(result) > 10 * 1024 * 1024:
            raise ValueError('Generated audio too long')
        return result

def make_handler(runtime, key):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def send(self, code, data, mime='application/json'):
            payload = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode()
            self.send_response(code)
            for k, v in [('Content-Type', mime), ('Content-Length', str(len(payload))), ('Cache-Control', 'no-store')]:
                self.send_header(k, v)
            self.end_headers()
            try:
                self.wfile.write(payload)
            except (BrokenPipeError, ConnectionResetError):
                pass
        def authorized(self):
            return hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + key)
        def do_GET(self):
            if not self.authorized(): return self.send(401, {'error': 'Unauthorized'})
            if self.path != '/health': return self.send(404, {'error': 'Not found'})
            return self.send(200, {'voice_model_files': Path(runtime.model_dir).is_dir(), 'voice_loaded': runtime.tts is not None,
                'text_model': runtime.text_model, 'text_device': 'cpu', 'voice_device': 'cuda', 'local_only': True})
        def do_POST(self):
            if not self.authorized(): return self.send(401, {'error': 'Unauthorized'})
            if self.path not in ('/v1/chat/completions', '/v1/voice-clone', '/v1/release-voice'): return self.send(404, {'error': 'Not found'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if length <= 0 or length > 2 * 1024 * 1024: return self.send(413, {'error': 'Payload too large'})
                data = json.loads(self.rfile.read(length))
                if not isinstance(data, dict): raise ValueError('Expected object')
            except ValueError:
                return self.send(400, {'error': 'Invalid request'})
            if not runtime.lock.acquire(blocking=False): return self.send(409, {'error': 'Local models busy'})
            try:
                if self.path == '/v1/chat/completions': return self.send(200, runtime.chat(data.get('messages')))
                if self.path == '/v1/release-voice':
                    runtime.tts = None
                    import gc, sys
                    gc.collect()
                    torch = sys.modules.get('torch')
                    if torch is not None and torch.cuda.is_available(): torch.cuda.empty_cache()
                    return self.send(200, {'released': True})
                return self.send(200, runtime.voice(data), 'audio/wav')
            except LocalModelFailure as error:
                print('Local model failure:', str(error), flush=True)
                return self.send(503, {'error': 'Local inference failed; check service window'})
            except Exception as error:
                print('Local model failure:', type(error).__name__, '(check dependencies, model files and available CUDA memory)', flush=True)
                return self.send(503, {'error': 'Local inference failed; check service window'})
            finally:
                runtime.lock.release()
    return Handler

def parent_alive(pid):
    if os.name == 'nt':
        import ctypes
        kernel = ctypes.windll.kernel32
        kernel.OpenProcess.restype = ctypes.c_void_p
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle: return False
        code = ctypes.c_ulong()
        ok = kernel.GetExitCodeProcess(ctypes.c_void_p(handle), ctypes.byref(code))
        kernel.CloseHandle(ctypes.c_void_p(handle))
        return bool(ok and code.value == 259)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--model-dir', required=True)
    parser.add_argument('--text-model', default='qwen3:4b-instruct-2507-q4_K_M')
    parser.add_argument('--parent-pid', type=int)
    parser.add_argument('--ollama-url', default='http://127.0.0.1:11434')
    args = parser.parse_args()
    key = os.environ.get('STILLHERE_MODEL_KEY', '')
    if len(key) < 32: raise SystemExit('Missing dedicated service key')
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    if args.parent_pid:
        def watch():
            import time
            while parent_alive(args.parent_pid): time.sleep(2)
            os._exit(0)
        threading.Thread(target=watch, daemon=True).start()
    runtime = ModelRuntime(args.model_dir, args.text_model, args.ollama_url)
    print('STILLHERE loopback model bridge; voice model loads on first synthesis', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), make_handler(runtime, key)).serve_forever()

if __name__ == '__main__': main()
