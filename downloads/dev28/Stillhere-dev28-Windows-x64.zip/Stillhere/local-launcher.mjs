import net from 'node:net';
import {spawn} from 'node:child_process';
import {randomBytes,createHash} from 'node:crypto';
import {mkdir,readFile,writeFile,realpath} from 'node:fs/promises';
import {homedir} from 'node:os';
import {join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const appRoot=fileURLToPath(new URL('.',import.meta.url));let child=null,control=null,readyTimer=null,stopping=false;
function stop(){if(stopping)return;stopping=true;clearTimeout(readyTimer);child?.kill();if(control?.listening)control.close();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);process.on('SIGHUP',stop);process.on('exit',()=>child?.kill());
try{
 const dataHome=resolve(process.env.STILLHERE_LOCAL_HOME||(process.platform==='win32'?join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local'):join(homedir(),'.stillhere-local')));await mkdir(dataHome,{recursive:true,mode:0o700});const canonical=await realpath(dataHome);const identity=process.platform==='win32'?canonical.toLowerCase():canonical;const controlPort=45000+createHash('sha256').update(identity).digest().readUInt32BE(0)%10000;
 control=net.createServer(socket=>socket.end('Stillhere local launcher is running.\n'));await new Promise((resolve,reject)=>{control.once('error',reject);control.listen(controlPort,'127.0.0.1',resolve);});
 const tokenPath=join(canonical,'owner.token');let token;try{token=await readFile(tokenPath,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;token=randomBytes(32).toString('hex');await writeFile(tokenPath,token,{mode:0o600,flag:'wx'});}token=token.trim();if(!/^[a-f0-9]{64}$/i.test(token))throw Error('本机凭证文件格式异常，请先备份资料再处理。');await mkdir(join(canonical,'data'),{recursive:true,mode:0o700});
 const probe=net.createServer();await new Promise((resolve,reject)=>{probe.once('error',reject);probe.listen(0,'127.0.0.1',resolve);});const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
 const env={...process.env,PORT:String(port),PERSONA_LISTEN_HOST:'127.0.0.1',PERSONA_OWNER_TOKEN:token,PERSONA_DATA:join(canonical,'data','persona.json'),STILLHERE_PARENT_WATCH:'1'};for(const key of ['PERSONA_PUBLIC_ORIGIN','PERSONA_TLS_CERT','PERSONA_TLS_KEY'])delete env[key];
 console.log('续在本机版 · 资料目录：'+canonical);console.log('使用 Ctrl+C 停止服务。旧EXE的资料不会自动合并到此目录。');
 child=spawn(process.execPath,[join(appRoot,'server.mjs')],{cwd:appRoot,env,stdio:['ignore','pipe','pipe','ipc'],windowsHide:true});let output='',opened=false;
 readyTimer=setTimeout(()=>{console.error('本机服务启动超时，请查看窗口错误信息。');process.exitCode=1;stop();},30000);
 child.stdout.on('data',part=>{process.stdout.write(part);output=(output+part.toString()).slice(-8192);if(!opened&&output.includes('STILLHERE: http://127.0.0.1:'+port)){opened=true;clearTimeout(readyTimer);if(process.platform==='win32'&&!process.argv.includes('--no-browser')){const browser=spawn('rundll32.exe',['url.dll,FileProtocolHandler','http://127.0.0.1:'+port],{stdio:'ignore',windowsHide:true});browser.on('error',()=>console.error('无法自动打开浏览器，请复制上方本机地址。'));browser.unref();}}});child.stderr.on('data',part=>process.stderr.write(part));
 child.on('error',e=>{console.error('无法启动本机服务：'+e.message);process.exitCode=1;stop();});child.on('exit',(code,signal)=>{clearTimeout(readyTimer);child=null;if(control?.listening)control.close();if(!stopping)process.exitCode=code??(signal?1:0);});
}catch(e){console.error(e.code==='EADDRINUSE'?'同一资料目录的本机版已在运行，或控制端口被占用。请使用原窗口或关闭后重试。':e.message);process.exitCode=1;stop();}
