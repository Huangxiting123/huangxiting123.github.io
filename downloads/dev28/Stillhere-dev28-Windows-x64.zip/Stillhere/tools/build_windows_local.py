"""Package the local web application with a pinned official Windows Node runtime.
Does not execute Windows binaries or claim Windows runtime validation.
"""
from pathlib import Path
import argparse, hashlib, json, struct, zipfile

NODE_VERSION = 'v24.22.2'
NODE_ARCHIVE = f'node-{NODE_VERSION}-win-x64.zip'
NODE_SHA256 = 'ca1bff5d8ead13c9f2ea404a176db46bd430704d5b5113734049fa365e7799e2'
NODE_URL = f'https://nodejs.org/dist/{NODE_VERSION}/{NODE_ARCHIVE}'
ROOT = Path(__file__).resolve().parent.parent


def source_files(root):
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if (not path.is_file() or any(part in {'data', 'node_modules', '__pycache__', 'certs', 'runtime', '.git', 'build'} for part in rel.parts)
                or path.suffix.lower() in {'.key', '.pem', '.pfx', '.token', '.env', '.zip', '.exe'}
                or path.name in {'turnserver.conf', 'stillhere.env', 'start.cmd', 'start-mobile.cmd'}
                or path.name.startswith('.env')):
            continue
        yield path, rel.as_posix()


def build(runtime_zip, output):
    payload = Path(runtime_zip).read_bytes()
    if hashlib.sha256(payload).hexdigest() != NODE_SHA256:
        raise ValueError('Node runtime checksum does not match the pinned official release')
    with zipfile.ZipFile(runtime_zip) as runtime:
        prefix = f'node-{NODE_VERSION}-win-x64/'
        executable = runtime.read(prefix + 'node.exe')
        license_text = runtime.read(prefix + 'LICENSE')
    if executable[:2] != b'MZ':
        raise ValueError('Node runtime is not a PE executable')
    offset = struct.unpack_from('<I', executable, 0x3C)[0]
    if executable[offset:offset + 4] != b'PE\0\0' or struct.unpack_from('<H', executable, offset + 4)[0] != 0x8664:
        raise ValueError('Node runtime is not Windows x64')
    version = json.loads((ROOT / 'package.json').read_text())['version']
    manifest = {'product_version': version, 'kind': 'Windows x64 local launch package',
                'node_version': NODE_VERSION, 'node_archive_url': NODE_URL, 'node_archive_sha256': NODE_SHA256,
                'windows_runtime_tested': False, 'source_files': {}}
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, name in source_files(ROOT):
            data = path.read_bytes()
            archive.writestr('Stillhere/' + name, data)
            manifest['source_files'][name] = hashlib.sha256(data).hexdigest()
        archive.writestr('Stillhere/runtime/node.exe', executable)
        archive.writestr('Stillhere/runtime/LICENSE-Node.txt', license_text)
        archive.writestr('Stillhere/BUILD-INFO.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    return {'file': str(output), 'bytes': output.stat().st_size, 'node': NODE_VERSION,
            'product_version': version, 'windows_runtime_tested': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-zip', required=True, help='Official node-v24.22.2-win-x64.zip; verified against its pinned SHA256')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.runtime_zip, args.out), ensure_ascii=False))
