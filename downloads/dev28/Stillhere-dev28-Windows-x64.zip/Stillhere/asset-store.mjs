import {mkdir,readFile,writeFile,rename,unlink,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export const ASSET_MAX_BYTES=100*1024*1024;
export async function readAssetBody(req){let size=0;const parts=[];for await(const part of req){size+=part.length;if(size>ASSET_MAX_BYTES)fail(413,'单条素材不能超过100MB');parts.push(part);}if(!size)fail(400,'素材不能为空');return Buffer.concat(parts);}
export function createAssetStore(directory,{maxBytes=2*1024*1024*1024,maxCount=200}={}){
 let queue=Promise.resolve(),initialized=false;const index=join(directory,'index.json');
 const run=fn=>{const result=queue.then(fn);queue=result.catch(()=>{});return result;};
 async function read(){await mkdir(directory,{recursive:true,mode:0o700});let rows;try{rows=JSON.parse(await readFile(index,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;rows=[];}if(!Array.isArray(rows)||rows.some(x=>!validId(x.id)))throw Error('素材索引格式异常');if(!initialized){const ids=new Set(rows.map(r=>r.id+'.bin'));for(const name of await readdir(directory))if((/^[a-f0-9-]{36}\.bin$/.test(name)&&!ids.has(name))||name==='index.json.tmp')await unlink(join(directory,name)).catch(()=>{});initialized=true;}return rows;}
 async function commit(rows){await writeFile(index+'.tmp',JSON.stringify(rows,null,2),{mode:0o600});await rename(index+'.tmp',index);}
 function validId(id){return typeof id==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(id);}
 function publicRow({digest,...row}){return row;}
 return {
  list:()=>run(async()=>{const rows=await read();return {items:rows.map(publicRow).reverse(),usedBytes:rows.reduce((sum,r)=>sum+r.bytes,0),maxBytes,maxCount};}),
  save:({id,title,mime,body})=>run(async()=>{if(!validId(id))fail(400,'素材编号无效');if(typeof title!=='string'||!title.trim()||title.length>100)fail(400,'请输入100字以内的素材标题');const base=String(mime).split(';')[0].toLowerCase();if(!['video/webm','video/mp4','audio/webm','audio/ogg','audio/mp4','audio/wav','text/plain'].includes(base))fail(415,'不支持的素材格式');if(!Buffer.isBuffer(body)||!body.length||body.length>ASSET_MAX_BYTES)fail(413,'素材为空或超过100MB');if(base==='text/plain'&&body.length>64000)fail(413,'故事文字过长，请拆成多篇');const rows=await read(),digest=createHash('sha256').update(body).digest('hex'),existing=rows.find(r=>r.id===id);if(existing){if(existing.digest!==digest||existing.title!==title.trim()||existing.mime!==base)fail(409,'相同编号的素材内容已变化');return publicRow(existing);}if(rows.length>=maxCount||rows.reduce((s,r)=>s+r.bytes,0)+body.length>maxBytes)fail(413,'素材库容量已满，请先下载备份并删除不需要的素材');const row={id,title:title.trim(),mime:base,kind:base.startsWith('video/')?'video':base.startsWith('audio/')?'audio':'story',bytes:body.length,createdAt:new Date().toISOString(),status:'stored',digest};await writeFile(join(directory,id+'.bin'),body,{mode:0o600,flag:'wx'});try{await commit([...rows,row]);}catch(e){await unlink(join(directory,id+'.bin')).catch(()=>{});throw e;}return publicRow(row);}),
  load:id=>run(async()=>{const rows=await read(),row=rows.find(r=>r.id===id);if(!row)fail(404,'素材不存在');return {row:publicRow(row),body:await readFile(join(directory,row.id+'.bin'))};}),
  remove:id=>run(async()=>{const rows=await read();if(!rows.some(r=>r.id===id))fail(404,'素材不存在');await commit(rows.filter(r=>r.id!==id));await unlink(join(directory,id+'.bin')).catch(e=>{if(e.code!=='ENOENT'){initialized=false;throw e;}});return {removed:true};})
 };
}
