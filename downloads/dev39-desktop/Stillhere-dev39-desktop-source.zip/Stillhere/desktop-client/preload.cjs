const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('stillhere',{session:()=>ipcRenderer.invoke('session'),onboarding:()=>ipcRenderer.invoke('onboarding'),wechat:(action,data)=>ipcRenderer.invoke('wechat',action,data),models:(action)=>ipcRenderer.invoke('models',action),advanced:()=>ipcRenderer.invoke('advanced')});
