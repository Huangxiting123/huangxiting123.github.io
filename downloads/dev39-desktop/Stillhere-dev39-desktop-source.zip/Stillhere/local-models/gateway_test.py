import json, threading, unittest, urllib.request, urllib.error, os
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler
from http.server import ThreadingHTTPServer
from gateway import make_handler, ModelRuntime, LocalModelFailure
class FakeRuntime:
    def __init__(self):
        self.lock=threading.Lock();self.model_dir='.';self.text_model='fixture';self.tts=None
    def chat(self, messages): return {'choices':[{'message':{'content':'fixture text'}}]}
    def voice(self, data): return b'RIFF-test-fixture'
class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.runtime=FakeRuntime();self.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.runtime,'test-key'));self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start();self.base='http://127.0.0.1:'+str(self.server.server_port)
    def tearDown(self): self.server.shutdown();self.server.server_close();self.thread.join()
    def request(self,path,data=None,key='test-key'):
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        return urllib.request.urlopen(req)
    def test_auth_and_loopback_protocol(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/health',key='wrong')
        self.assertEqual(e.exception.code,401)
        with self.request('/health') as r:self.assertTrue(json.load(r)['local_only'])
        with self.request('/v1/chat/completions',{'messages':[]}) as r:self.assertIn('choices',json.load(r))
    def test_voice_release_clears_cached_model_and_requires_authorization(self):
        self.runtime.tts=object()
        with self.assertRaises(urllib.error.HTTPError) as error:self.request('/v1/release-voice',{},key='wrong')
        self.assertEqual(error.exception.code,401)
        self.assertIsNotNone(self.runtime.tts)
        with self.request('/v1/release-voice',{}) as response:self.assertTrue(json.load(response)['released'])
        self.assertIsNone(self.runtime.tts)
    def test_concurrent_tasks_are_rejected(self):
        self.runtime.lock.acquire()
        try:
            with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/voice-clone',{})
            self.assertEqual(e.exception.code,409)
        finally:self.runtime.lock.release()
    def test_ollama_endpoint_cannot_be_remote(self):
        with self.assertRaises(ValueError):ModelRuntime('.', 'fixture', 'https://remote.example')
    def test_real_runtime_rejects_unapproved_audio_before_loading_models(self):
        with self.assertRaises(ValueError):ModelRuntime('.', 'fixture').voice({'authorized':False})
class OllamaIntegrationTests(unittest.TestCase):
    def test_loopback_ignores_proxy_and_classifies_error_without_echoing_private_text(self):
        responses = [(200, {'message': {'content': 'fixture reply'}}),
                     (404, {'error': 'model not found private-story-sentinel'}),
                     (500, {'error': 'runner memory private-story-sentinel'})]
        requests = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                requests.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
                code, value = responses.pop(0)
                raw = json.dumps(value).encode()
                self.send_response(code); self.end_headers(); self.wfile.write(raw)
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        try:
            with patch.dict(os.environ, {'http_proxy': 'http://127.0.0.1:1', 'HTTP_PROXY': 'http://127.0.0.1:1', 'no_proxy': '', 'NO_PROXY': ''}):
                runtime = ModelRuntime('.', 'fixture', 'http://127.0.0.1:' + str(server.server_port))
                self.assertEqual(runtime.chat([{'role':'user','content':'fixture'}])['choices'][0]['message']['content'], 'fixture reply')
                for expected in ('OLLAMA_HTTP_404', 'OLLAMA_HTTP_500'):
                    with self.assertRaises(LocalModelFailure) as error: runtime.chat([{'role':'user','content':'fixture'}])
                    self.assertIn(expected, str(error.exception)); self.assertNotIn('private-story-sentinel', str(error.exception))
                self.assertNotIn('think', requests[0])
                self.assertEqual(requests[0]['keep_alive'], '5m')
                self.assertNotIn('num_gpu', requests[0]['options'])
        finally: server.shutdown(); server.server_close(); thread.join()
    def test_warm_text_model_releases_before_voice_and_cpu_fallback_is_explicit(self):
        calls=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                calls.append((self.path,body)); self.send_response(200); self.end_headers()
                self.wfile.write(json.dumps({'message':{'content':'fixture'}}).encode())
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            runtime=ModelRuntime('.', 'fixture','http://127.0.0.1:'+str(server.server_port))
            runtime.tts=object()
            with patch.dict(os.environ,{'STILLHERE_TEXT_DEVICE':'auto'}):runtime.chat([{'role':'user','content':'fixture'}])
            self.assertIsNone(runtime.tts)
            self.assertNotIn('num_gpu',calls[-1][1]['options'])
            runtime.unload_text();self.assertEqual(calls[-1][0],'/api/generate');self.assertEqual(calls[-1][1]['keep_alive'],0)
            with patch.dict(os.environ,{'STILLHERE_TEXT_DEVICE':'cpu'}):runtime.chat([{'role':'user','content':'fixture'}])
            self.assertEqual(calls[-1][1]['options']['num_gpu'],0)
        finally:server.shutdown();server.server_close();thread.join()
    def test_unexpected_redirect_is_refused(self):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_POST(self):
                self.send_response(307); self.send_header('Location', 'https://example.invalid'); self.end_headers()
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        try:
            runtime = ModelRuntime('.', 'fixture', 'http://127.0.0.1:' + str(server.server_port))
            with self.assertRaises(LocalModelFailure) as error: runtime.chat([{'role':'user','content':'fixture'}])
            self.assertIn('OLLAMA_REDIRECT', str(error.exception))
        finally: server.shutdown(); server.server_close(); thread.join()
if __name__=='__main__':unittest.main()
