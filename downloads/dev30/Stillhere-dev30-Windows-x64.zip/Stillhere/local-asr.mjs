import {execFile} from 'node:child_process';
import {access,mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {readPcmWav,pcmWav,ASSET_AUDIO_RATE} from './asset-audio.mjs';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function createLocalAsr({directory,language='zh',execute=execFile}={}){
 let active=false,child=null,closed=false,settled=Promise.resolve();
 const executable=join(directory,process.platform==='win32'?'sherpa-onnx-offline.exe':'sherpa-onnx-offline');
 const files=['tiny-encoder.int8.onnx','tiny-decoder.int8.onnx','tiny-tokens.txt'];
 async function status(){let available=true;try{await Promise.all([executable,...files.map(f=>join(directory,f))].map(p=>access(p)));}catch{available=false;}return {available,busy:active,engine:'sherpa-onnx / Whisper tiny int8',language,maxSeconds:65,localOnly:true};}
 async function transcribe(bytes,{signal}={}){
 if(closed||signal?.aborted)fail(409,'转写已取消');if(active)fail(409,'已有本机转写任务，请稍后重试');const samples=readPcmWav(bytes);active=true;let finish;settled=new Promise(resolve=>{finish=resolve;});let dir;
 try{if(!(await status()).available)fail(503,'本地转写组件未就绪，请完整安装本版转写组件');dir=await mkdtemp(join(tmpdir(),'stillhere-asr-'));const texts=[];let partIndex=0;
 for(let start=0;start<samples.length;start+=20*ASSET_AUDIO_RATE){if(signal?.aborted||closed)fail(409,'转写已取消');const part=samples.subarray(start,start+20*ASSET_AUDIO_RATE),rms=Math.sqrt(part.reduce((sum,x)=>sum+x*x,0)/part.length);if(rms<0.0003)continue;const path=join(dir,'part-'+String(partIndex++)+'.wav');await writeFile(path,pcmWav(part),{mode:0o600});
 const stdout=await new Promise((resolve,reject)=>{const abort=()=>child?.kill();signal?.addEventListener('abort',abort,{once:true});child=execute(executable,['--whisper-encoder='+join(directory,files[0]),'--whisper-decoder='+join(directory,files[1]),'--tokens='+join(directory,files[2]),'--whisper-language='+language,'--whisper-task=transcribe','--num-threads=2',path],{windowsHide:true,timeout:120000,maxBuffer:1024*1024,encoding:'utf8'},(error,out)=>{signal?.removeEventListener('abort',abort);child=null;if(error)reject(Object.assign(Error(signal?.aborted||closed?'转写已取消':error.killed?'本机转写超时，请缩短素材后重试':'本地转写引擎运行失败，请检查组件是否完整、内存是否充足'),{status:502}));else resolve(out);});});
 let value;try{value=JSON.parse(stdout.trim());}catch{fail(502,'本地转写引擎返回格式异常');}if(typeof value.text!=='string')fail(502,'本地转写引擎没有返回文字');if(value.text.trim())texts.push(value.text.trim());
 }
 if(signal?.aborted||closed)fail(409,'转写已取消');const text=texts.join('\n');if(!text||text.length>10000)fail(422,'未识别到有效语音，请检查收音或缩短素材后重试');return {text,engine:'sherpa-onnx / Whisper tiny int8',language,durationSeconds:samples.length/ASSET_AUDIO_RATE};
 }finally{try{if(dir)await rm(dir,{recursive:true,force:true});}finally{active=false;finish();}}
 }
 return {status,transcribe,close(){closed=true;child?.kill();return settled;}};
}
