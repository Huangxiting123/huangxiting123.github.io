"""Package the local web application with a pinned official Windows Node runtime.
Does not execute Windows binaries or claim Windows runtime validation.
"""
from pathlib import Path
import argparse, hashlib, json, struct, zipfile

NODE_VERSION = 'v22.23.4'
NODE_ARCHIVE = f'node-{NODE_VERSION}-win-x64.zip'
NODE_SHA256 = 'cbc74b5e0982c9dbb41525fd8fb5dcd32fbee237863f7829072f4639a1ce5f20'
NODE_URL = f'https://nodejs.org/dist/{NODE_VERSION}/{NODE_ARCHIVE}'
ROOT = Path(__file__).resolve().parent.parent


def source_files(root):
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if (not path.is_file() or any(part in {'data', 'node_modules', '__pycache__', 'certs', 'runtime', '.git', 'build'} for part in rel.parts)
                or path.suffix.lower() in {'.key', '.pem', '.pfx', '.token', '.env', '.zip', '.exe'}
                or path.name in {'turnserver.conf', 'stillhere.env', 'start.cmd', 'start-mobile.cmd'}
                or path.name.startswith('.env')):
            continue
        yield path, rel.as_posix()


def copy_compressed_member(destination, source_path, source_name, target_name):
    """Copy an already verified official DEFLATE member without recompression.

    zipfile has no public raw-entry-copy API. The ZIP local header and central
    directory are rebuilt with explicit sizes/CRC; payload remains byte-identical.
    The finished archive is independently CRC-tested by release verification.
    """
    with zipfile.ZipFile(source_path) as source:
        original = source.getinfo(source_name)
        if original.compress_type != zipfile.ZIP_DEFLATED or original.flag_bits & 1:
            raise ValueError('Expected an unencrypted official DEFLATE entry')
        with open(source_path, 'rb') as stream:
            stream.seek(original.header_offset)
            header = stream.read(30)
            if header[:4] != b'PK\x03\x04':
                raise ValueError('Invalid official ZIP local header')
            name_size, extra_size = struct.unpack_from('<HH', header, 26)
            stream.seek(name_size + extra_size, 1)
            compressed = stream.read(original.compress_size)
        if len(compressed) != original.compress_size:
            raise ValueError('Truncated official runtime member')
        entry = zipfile.ZipInfo(target_name, original.date_time)
        entry.compress_type = original.compress_type
        entry.file_size, entry.compress_size, entry.CRC = original.file_size, original.compress_size, original.CRC
        entry.external_attr = original.external_attr
        entry.header_offset = destination.fp.tell()
        destination.fp.write(entry.FileHeader(False))
        destination.fp.write(compressed)
        destination.filelist.append(entry)
        destination.NameToInfo[target_name] = entry
        destination.start_dir = destination.fp.tell()
        destination._didModify = True


def build(runtime_zip, output, asr_dir=None):
    payload = Path(runtime_zip).read_bytes()
    if hashlib.sha256(payload).hexdigest() != NODE_SHA256:
        raise ValueError('Node runtime checksum does not match the pinned official release')
    with zipfile.ZipFile(runtime_zip) as runtime:
        prefix = f'node-{NODE_VERSION}-win-x64/'
        executable = runtime.read(prefix + 'node.exe')
        license_text = runtime.read(prefix + 'LICENSE')
    if executable[:2] != b'MZ':
        raise ValueError('Node runtime is not a PE executable')
    offset = struct.unpack_from('<I', executable, 0x3C)[0]
    if executable[offset:offset + 4] != b'PE\0\0' or struct.unpack_from('<H', executable, offset + 4)[0] != 0x8664:
        raise ValueError('Node runtime is not Windows x64')
    version = json.loads((ROOT / 'package.json').read_text())['version']
    manifest = {'product_version': version, 'kind': 'Windows x64 local launch package',
                'node_version': NODE_VERSION, 'node_archive_url': NODE_URL, 'node_archive_sha256': NODE_SHA256,
                'windows_runtime_tested': False, 'source_files': {}}
    asr_files = {}
    if asr_dir:
        asr_manifest = json.loads((ROOT / 'tools/asr-assets.json').read_text())
        for name, digest in asr_manifest['files'].items():
            data = (Path(asr_dir) / name).read_bytes()
            if hashlib.sha256(data).hexdigest() != digest:
                raise ValueError('ASR file checksum mismatch: ' + name)
            asr_files[name] = data
        binary = asr_files['sherpa-onnx-offline.exe']
        pe_offset = struct.unpack_from('<I', binary, 0x3C)[0]
        if binary[:2] != b'MZ' or binary[pe_offset:pe_offset + 4] != b'PE\0\0' or struct.unpack_from('<H', binary, pe_offset + 4)[0] != 0x8664:
            raise ValueError('ASR executable is not Windows x64')
        manifest['local_asr'] = asr_manifest
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path, name in source_files(ROOT):
            data = path.read_bytes()
            archive.writestr('Stillhere/' + name, data)
            manifest['source_files'][name] = hashlib.sha256(data).hexdigest()
        copy_compressed_member(archive, runtime_zip, prefix + 'node.exe', 'Stillhere/runtime/node.exe')
        archive.writestr('Stillhere/runtime/LICENSE-Node.txt', license_text)
        for name, data in asr_files.items():
            archive.writestr('Stillhere/runtime/asr/' + name, data)
        archive.writestr('Stillhere/BUILD-INFO.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    return {'file': str(output), 'bytes': output.stat().st_size, 'node': NODE_VERSION,
            'product_version': version, 'windows_runtime_tested': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-zip', required=True, help='Official node-v22.23.4-win-x64.zip; verified against its pinned SHA256')
    parser.add_argument('--out', required=True)
    parser.add_argument('--asr-dir', help='Verified selected Windows ASR executable and model files')
    args = parser.parse_args()
    print(json.dumps(build(args.runtime_zip, args.out, args.asr_dir), ensure_ascii=False))
