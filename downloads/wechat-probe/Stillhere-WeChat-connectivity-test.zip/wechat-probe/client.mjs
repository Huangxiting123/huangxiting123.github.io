import {randomBytes,randomUUID,randomInt} from 'node:crypto';
const ROOT='https://ilinkai.weixin.qq.com';
export function officialOrigin(value){const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||u.search||u.hash||!['','/'].includes(u.pathname)||!(u.hostname==='weixin.qq.com'||u.hostname.endsWith('.weixin.qq.com')))throw Error('微信返回了未允许的接口域名，已停止');return u.origin;}
export function createWechatProbe({fetcher=fetch}={}){
 let token=null,userId=null,botId=null,base=ROOT,pollBase=ROOT,qrcode=null,cursor='',controller=new AbortController(),generation=0,busy=false;
 let state={phase:'idle',bound:false,received:false,sendAccepted:false,phoneConfirmed:false,note:'先获取二维码，用你本人的微信扫码授权。'};
 const snapshot=()=>structuredClone(state);
 const headers=(auth=true,json=true)=>({...json?{'Content-Type':'application/json','AuthorizationType':'ilink_bot_token','X-WECHAT-UIN':Buffer.from(String(randomBytes(4).readUInt32BE())).toString('base64')}:{},'iLink-App-Id':'bot','iLink-App-ClientVersion':String((2<<16)|(4<<8)|8),...auth&&token?{Authorization:'Bearer '+token}:{}});
 async function call(path,{body,auth=true,origin=base,signal=controller.signal}={}){
  const r=await fetcher(officialOrigin(origin)+path,{method:body?'POST':'GET',redirect:'error',headers:headers(auth,!!body),...(body?{body:JSON.stringify(auth?{...body,base_info:{channel_version:'2.4.8',bot_agent:'StillhereProbe/0.1.0'}}:body)}:{}),signal:AbortSignal.any([signal,AbortSignal.timeout(45000)])});
  if(!r.ok)throw Error('微信接口HTTP '+r.status);const data=await r.json();if((typeof data.ret==='number'&&data.ret!==0)||(typeof data.errcode==='number'&&data.errcode!==0))throw Error('微信接口返回错误码 '+String(data.errcode||data.ret)+'；请按手机提示处理，或截图错误码。');return data;
 }
 function stop(){generation++;controller.abort();controller=new AbortController();token=null;userId=null;botId=null;qrcode=null;cursor='';base=ROOT;pollBase=ROOT;busy=false;state={phase:'stopped',bound:false,received:false,sendAccepted:false,phoneConfirmed:false,note:'已停止，本次登录凭证已从工具内存清除。平台绑定可在微信ClawBot中管理。'};}
 async function serial(fn){if(busy)throw Error('上一项微信请求还在处理中，请稍候');busy=true;const current=generation;try{await fn(current);}catch(e){if(current===generation){state.note=e.name==='AbortError'?'请求已停止':'网络或接口请求失败：'+e.message;state.phase='error';}throw e;}finally{if(current===generation)busy=false;}return snapshot();}
 return {snapshot,stop,
 async login(){stop();state.phase='loading';state.note='正在向微信官方接口申请二维码…';return serial(async current=>{const v=await call('/ilink/bot/get_bot_qrcode?bot_type=3',{auth:false,body:{local_token_list:[]},origin:ROOT});if(current!==generation)return;if(typeof v.qrcode!=='string'||typeof v.qrcode_img_content!=='string'||v.qrcode_img_content.length>10000)throw Error('二维码响应格式无效');qrcode=v.qrcode;state={...state,phase:'waiting_scan',qrContent:v.qrcode_img_content,note:'用手机微信扫一扫，并在手机确认ClawBot授权。'};});},
 async pollLogin(code){if(!qrcode||token)return snapshot();if(code!==undefined&&!/^\d{4,10}$/.test(code))throw Error('请输入手机提示的数字验证码');return serial(async current=>{const v=await call('/ilink/bot/get_qrcode_status?qrcode='+encodeURIComponent(qrcode)+(code?'&verify_code='+encodeURIComponent(code):''),{auth:false,origin:pollBase});if(current!==generation)return;
 if(v.status==='confirmed'){if(typeof v.bot_token!=='string'||!v.bot_token||typeof v.ilink_user_id!=='string'||!v.ilink_user_id||typeof v.ilink_bot_id!=='string')throw Error('授权响应缺少扫码者身份，不能开始收发验证');const validated=officialOrigin(v.baseurl||ROOT);token=v.bot_token;userId=v.ilink_user_id;botId=v.ilink_bot_id;base=validated;state={...state,phase:'bound',bound:true,qrContent:null,note:'扫码授权成功。点击开始一次收发验证，再向手机ClawBot会话发送指定口令。'};}
 else if(v.status==='scaned_but_redirect'){pollBase=officialOrigin(v.redirect_host?.startsWith('https://')?v.redirect_host:'https://'+v.redirect_host);state.note='已扫码，继续确认授权…';}
 else if(v.status==='need_verifycode'){state.phase='need_code';state.note='微信要求验证码，请按手机显示填写，不要把验证码发给他人。';}
 else if(['expired','verify_code_blocked','binded_redirect'].includes(v.status)){state.phase=v.status;state.qrContent=null;state.note=v.status==='expired'?'二维码已过期，请重新获取。':v.status==='binded_redirect'?'微信提示此绑定已存在，请在手机ClawBot管理绑定后重试。':'微信已限制本次验证，请按手机提示处理，不继续自动尝试。';qrcode=null;}
 else {state.phase=v.status==='scaned'?'scanned':'waiting_scan';state.note=v.status==='scaned'?'已扫码，请在手机确认。':'等待手机扫码…';}
 });},
 arm(){if(!token||!userId)throw Error('请先扫码完成授权');if(busy)throw Error('上一项请求还在处理中');state={...state,phase:'waiting_message',received:false,sendAccepted:false,phoneConfirmed:false,challenge:'续在验证 '+randomInt(100000,1000000),note:'只处理扫码者在ClawBot会话中发送的本次验证口令；收到后回复一次。'};return snapshot();},
 async pollMessages(){if(!token||state.phase!=='waiting_message')return snapshot();return serial(async current=>{const v=await call('/ilink/bot/getupdates',{body:{get_updates_buf:cursor}});if(current!==generation)return;if(typeof v.get_updates_buf==='string')cursor=v.get_updates_buf;
 for(const msg of Array.isArray(v.msgs)?v.msgs:[]){if(msg.message_type!==1||msg.from_user_id!==userId||msg.group_id||!msg.context_token||typeof msg.context_token!=='string')continue;const texts=(msg.item_list||[]).filter(x=>x.type===1&&typeof x.text_item?.text==='string').map(x=>x.text_item.text.trim());if(texts.length!==1||texts[0]!==state.challenge)continue;
 state.received=true;state.phase='sending';state.note='已收到本人验证口令，正在回发一次测试消息…';
 // One attempt only. A timeout may mean delivery is uncertain; never resend automatically.
 const sent=await call('/ilink/bot/sendmessage',{body:{msg:{from_user_id:'',to_user_id:userId,client_id:randomUUID(),message_type:2,message_state:2,context_token:msg.context_token,item_list:[{type:1,text_item:{text:'续在微信接入测试成功。已收到你的验证口令；这是一次固定回复，尚未连接分身记忆或大模型。'}}]}}});if(current!==generation)return;if(sent.ret!==0)throw Error('发送响应缺少成功码，结果不确定；不会自动重发，请到手机确认。');state.sendAccepted=true;state.phase='sent';state.note='微信接口已接受回复，请到手机确认是否收到，再点击“我已收到微信回复”。';break;}
 });},
 confirmPhone(){if(!state.sendAccepted)throw Error('请先完成测试消息发送');state.phoneConfirmed=true;state.phase='verified';state.note='你已确认手机收到回复：本次文字收发验证通过。语音、视频及分身模型尚未实测接入。';return snapshot();}
 };
}
