import {modelStoragePlan,modelEnvironment} from './storage.mjs';
import {findOllama,startOwnedOllama} from './ollama.mjs';
import net from 'node:net';
import {spawn,execFileSync} from 'node:child_process';
import {mkdir,readFile,writeFile,rename,access,rm,statfs,realpath} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const taskHome=process.env.STILLHERE_LOCAL_HOME||join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local');
let managedOllama=null;
process.on('exit',()=>managedOllama?.child.kill());for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>{managedOllama?.child.kill();process.exit(1);});
const hash=data=>createHash('sha256').update(data).digest('hex');
async function exists(p){try{await access(p);return true;}catch{return false;}}
async function run(exe,args,env=process.env){await new Promise((resolve,reject)=>{const child=spawn(exe,args,{env,stdio:'inherit',windowsHide:false});child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error('安装步骤失败，退出码 '+code+'；请保留上方错误信息')));});}
try{
 if(process.platform!=='win32')throw Error('此安装器只用于Windows；开发桥接程序可独立部署');
 console.log('模型安装器 dev32-E1：支持独立模型磁盘，保留原资料目录。');
 console.log('本地体验配置：16GB内存、NVIDIA显卡。请先停止主程序，准备至少15GB磁盘空间。首次下载会有数GB。');
 console.log('模型从Ollama与ModelScope下载到本机；不会上传你的故事或声音。');
 await mkdir(taskHome,{recursive:true});const canonical=(await realpath(taskHome)).toLowerCase();const lease=45000+createHash('sha256').update(canonical).digest().readUInt32BE(0)%10000;const occupied=await new Promise(resolve=>{const socket=net.createConnection({host:'127.0.0.1',port:lease});const finish=value=>{socket.destroy();resolve(value);};socket.once('connect',()=>finish(true));socket.once('error',()=>finish(false));socket.setTimeout(1000,()=>finish(false));});if(occupied)throw Error('请先在主程序启动窗口按Ctrl+C停止服务，再运行模型安装');let stored=null;try{stored=JSON.parse(await readFile(join(taskHome,'model-storage.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
 const plan=modelStoragePlan({programRoot:dirname(dirname(fileURLToPath(import.meta.url))),dataHome:taskHome,stored});
 for(const path of [plan.modelsHome,plan.tools,plan.temp,plan.cache,plan.pythonInstall,plan.ollamaModels])await mkdir(path,{recursive:true});
 const disk=await statfs(plan.modelsHome),available=Number(disk.bavail)*Number(disk.bsize);
 console.log('原有资料与凭证目录：'+taskHome);console.log('模型、Python、缓存与安装临时文件目录：'+plan.modelsHome);console.log('模型所在磁盘可用空间：'+(available/1024**3).toFixed(1)+' GiB');
 if(available<15*1024**3)throw Error('模型所在磁盘空间不足15GB：'+plan.modelsHome+'；可用安装模型到E盘.cmd选择E盘');
 await writeFile(join(taskHome,'model-storage.json.tmp'),JSON.stringify({modelsHome:plan.modelsHome},null,2));await rename(join(taskHome,'model-storage.json.tmp'),join(taskHome,'model-storage.json'));
 const environment=modelEnvironment(plan);let existingConfig=null;try{existingConfig=JSON.parse(await readFile(join(taskHome,'local-models.json'),'utf8'));}catch{}
 const ollama=await findOllama(existingConfig?.ollamaExecutable);console.log('Ollama程序：'+ollama);console.log('启动独立模型服务，模型库：'+plan.ollamaModels);
 managedOllama=await startOwnedOllama(ollama,environment);await run(ollama,['pull','qwen3:4b-instruct-2507-q4_K_M'],managedOllama.env);
 const tools=plan.tools,uv=join(tools,'uv.exe');
 const expectedExe='1791d7a9ed5b6df13ccf80f102e025c333010d96326b4ff0262aa3b578835c5a';
 if(!await exists(uv)||hash(await readFile(uv))!==expectedExe){
  const response=await fetch('https://github.com/astral-sh/uv/releases/download/0.13.7/uv-x86_64-pc-windows-msvc.zip',{signal:AbortSignal.timeout(180000)});if(!response.ok)throw Error('无法下载Python环境工具');const data=Buffer.from(await response.arrayBuffer());if(hash(data)!=='0cdc5b38fe5a8168ed6a25814f5ba43c21d313dd3187314fccb37b7cec46e021')throw Error('下载工具校验失败，未执行');const archive=join(tools,'uv-windows.zip');await writeFile(archive,data);
  await run('powershell.exe',['-NoProfile','-NonInteractive','-Command','Expand-Archive -LiteralPath $env:STILLHERE_SETUP_ZIP -DestinationPath $env:STILLHERE_SETUP_TOOLS -Force'],{...process.env,STILLHERE_SETUP_ZIP:archive,STILLHERE_SETUP_TOOLS:tools,...environment});if(hash(await readFile(uv))!==expectedExe)throw Error('uv.exe完整性校验失败');
 }
 const runtime=plan.runtime,python=plan.python;if(!await exists(python))await run(uv,['venv','--python','3.12',runtime],environment);
 await run(uv,['pip','install','--python',python,'torch==2.7.1','torchaudio==2.7.1','--index-url','https://download.pytorch.org/whl/cu118'],environment);
 await run(uv,['pip','install','--python',python,'qwen-tts==0.1.1','modelscope==1.40.2'],environment);
 await run(python,['-c',"import torch; print('CUDA:',torch.cuda.is_available()); assert torch.cuda.is_available(), 'CUDA unavailable: inspect NVIDIA driver and PyTorch installation'; print('GPU:',torch.cuda.get_device_name(0),'VRAM GiB:',round(torch.cuda.get_device_properties(0).total_memory/1024**3,1))"],environment);
 await run(python,[join(dirname(fileURLToPath(import.meta.url)),'download_models.py'),'--home',taskHome,'--models-home',plan.modelsHome,'--ollama-url',managedOllama.url,'--ollama-executable',ollama],environment);
 console.log('安装流程已完成。请重新启动主程序，再用本人声样试听。首次模型运行与相似度尚待验收。');
}catch(e){console.error(e.message);process.exitCode=1;}finally{managedOllama?.child.kill();}
