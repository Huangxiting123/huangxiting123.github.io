import json, threading, unittest, urllib.request, urllib.error
from http.server import ThreadingHTTPServer
from gateway import make_handler, ModelRuntime
class FakeRuntime:
    def __init__(self):
        self.lock=threading.Lock();self.model_dir='.';self.text_model='fixture';self.tts=None
    def chat(self, messages): return {'choices':[{'message':{'content':'fixture text'}}]}
    def voice(self, data): return b'RIFF-test-fixture'
class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.runtime=FakeRuntime();self.server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(self.runtime,'test-key'));self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start();self.base='http://127.0.0.1:'+str(self.server.server_port)
    def tearDown(self): self.server.shutdown();self.server.server_close();self.thread.join()
    def request(self,path,data=None,key='test-key'):
        req=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        return urllib.request.urlopen(req)
    def test_auth_and_loopback_protocol(self):
        with self.assertRaises(urllib.error.HTTPError) as e:self.request('/health',key='wrong')
        self.assertEqual(e.exception.code,401)
        with self.request('/health') as r:self.assertTrue(json.load(r)['local_only'])
        with self.request('/v1/chat/completions',{'messages':[]}) as r:self.assertIn('choices',json.load(r))
    def test_concurrent_tasks_are_rejected(self):
        self.runtime.lock.acquire()
        try:
            with self.assertRaises(urllib.error.HTTPError) as e:self.request('/v1/voice-clone',{})
            self.assertEqual(e.exception.code,409)
        finally:self.runtime.lock.release()
    def test_ollama_endpoint_cannot_be_remote(self):
        with self.assertRaises(ValueError):ModelRuntime('.', 'fixture', 'https://remote.example')
    def test_real_runtime_rejects_unapproved_audio_before_loading_models(self):
        with self.assertRaises(ValueError):ModelRuntime('.', 'fixture').voice({'authorized':False})
if __name__=='__main__':unittest.main()
