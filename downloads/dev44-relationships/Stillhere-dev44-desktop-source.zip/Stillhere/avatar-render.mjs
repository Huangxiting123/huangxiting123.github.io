import {readFile,mkdir,writeFile,rm,mkdtemp,access} from 'node:fs/promises';
import {join,dirname} from 'node:path';import {homedir} from 'node:os';import {spawn} from 'node:child_process';import {readPcmWav} from './asset-audio.mjs';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function validateLipInput(input,portrait){
 if(!portrait)fail(409,'请先保存本人照片');if(input?.authorized!==true)fail(400,'请确认本人形象口型生成授权');if(input.portraitId!==portrait.id)fail(409,'本人形象已变化，请刷新重试');
 const a=input.audioBase64;if(typeof a!=='string'||a.length>650000||a.length%4!==0||!/^[A-Za-z0-9+/]*={0,2}$/.test(a))fail(400,'声音格式无效');
 const audio=Buffer.from(a,'base64'),samples=readPcmWav(audio);if(samples.length<3200||samples.length>15*16000)fail(400,'首版口型视频支持0.2—15秒声音，请缩短回复');
 const c=input.crop;if(!Array.isArray(c)||c.length!==4||c.some(n=>!Number.isInteger(n))||c[0]<0||c[1]<0||c[2]>portrait.width||c[3]>portrait.height||c[2]-c[0]<48||c[3]-c[1]<48)fail(400,'人脸区域无效或过小，请使用清晰正面单人照');return {audio,crop:c};
}
export function createAvatarRenderer({root,home=process.env.STILLHERE_LOCAL_HOME||join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local'),releaseVoice=async()=>{},execute=executePython}={}){
 let busy=false;
 async function config(){try{const c=JSON.parse(await readFile(join(home,'avatar-models.json'),'utf8'));if(c.version!==1||typeof c.python!=='string'||typeof c.modelDir!=='string')throw Error('bad config');await access(c.python);await access(join(c.modelDir,'manifest.json'));return c;}catch(e){if(e.code==='ENOENT')return null;throw e;}}
 return {get busy(){return busy;},async status(){return {installed:Boolean(await config()),busy,engine:'MuseTalk 1.5 experimental',maxSeconds:15,realTime:false};},async render(input,portrait,{signal}={}){
  const data=validateLipInput(input,portrait);if(busy)fail(409,'口型模型正在生成，请等待或取消');busy=true;let dir;
  try{const c=await config();if(!c)fail(503,'请先双击安装真人口型模型.cmd，完成后重启软件');await releaseVoice({signal});if(signal?.aborted)fail(409,'生成已取消');const jobs=join(dirname(c.modelDir),'avatar-jobs');await mkdir(jobs,{recursive:true,mode:0o700});dir=await mkdtemp(join(jobs,'render-'));await Promise.all([writeFile(join(dir,'portrait.png'),Buffer.from(portrait.pngBase64,'base64'),{mode:0o600}),writeFile(join(dir,'audio.wav'),data.audio,{mode:0o600}),writeFile(join(dir,'crop.json'),JSON.stringify(data.crop),{mode:0o600})]);await execute(c.python,[join(root,'local-avatar','render.py'),'--models',c.modelDir,'--job',dir],{signal});if(signal?.aborted)fail(409,'生成已取消');const output=await readFile(join(dir,'result.mp4'));if(output.length>40*1024*1024||output.length<16||output.subarray(4,8).toString()!=='ftyp')fail(502,'口型模型未返回有效MP4视频');return output;
  }finally{try{if(dir)await rm(dir,{recursive:true,force:true});}finally{busy=false;}}
 }};
}
async function executePython(exe,args,{signal}={}){
 await new Promise((resolve,reject)=>{const child=spawn(exe,args,{env:{...process.env,HF_HUB_OFFLINE:'1',TRANSFORMERS_OFFLINE:'1',PYTHONUNBUFFERED:'1'},stdio:['ignore','pipe','pipe'],windowsHide:true});let settled=false;
 const kill=()=>{if(process.platform==='win32'&&child.pid){const killer=spawn('taskkill.exe',['/PID',String(child.pid),'/T','/F'],{stdio:'ignore',windowsHide:true});killer.on('error',()=>child.kill());}else child.kill('SIGTERM');};
 const abort=()=>{kill();};signal?.addEventListener('abort',abort,{once:true});const timer=setTimeout(()=>kill(),15*60*1000);
 for(const stream of [child.stdout,child.stderr])stream.on('data',p=>process.stderr.write(p));
 const finish=(error)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);error?reject(error):resolve();};
 child.once('error',()=>finish(Object.assign(Error('无法启动本机口型运行环境，请检查安装'),{status:503})));child.once('exit',code=>finish(code===0&&!signal?.aborted?null:Object.assign(Error(signal?.aborted?'口型生成已取消':'口型生成失败，请查看启动窗口AVATAR_FAILED日志'),{status:502})));if(signal?.aborted)abort();
 });
}
