import test from 'node:test';
import assert from 'node:assert/strict';
import {localReadiness} from './local-readiness.mjs';
const find=(options,id)=>localReadiness(options).find(x=>x.id===id);
test('unconfigured local experience offers text without claiming device or provider readiness',()=>{
 assert.equal(find({},'identity').status,'action');assert.equal(find({confirmed:true},'text').status,'ready');
 assert.equal(find({},'devices').status,'unavailable');assert.equal(find({},'avatar').status,'pending');
 assert.match(find({state:{role:'contact'}},'asr').detail,/档案所有者/);
});
test('configured services and browser capabilities are not marked verified',()=>{
 const options={state:{speech:{asr:{configured:true},tts:{configured:true}}},secure:true,media:true,recorder:true,rtc:true};
 for(const id of ['asr','tts']){assert.equal(find(options,id).status,'configured');assert.match(find(options,id).detail,/实际请求验证/);}
 assert.equal(find(options,'devices').status,'action');assert.equal(find(options,'recording').status,'available');assert.equal(find(options,'remote').status,'available');
 assert.equal(find({...options,devicePhase:'preview'},'devices').status,'ready');
});
test('revocation and configuration removal immediately remove readiness without leaking profile data',()=>{
 const secret='PRIVATE-NAME-TOKEN-URL';const state={role:'owner',profile:{name:secret},speech:{asr:{configured:false,url:secret,key:secret}}};
 const report=localReadiness({state,confirmed:false});assert.doesNotMatch(JSON.stringify(report),new RegExp(secret));
 assert.equal(report.find(x=>x.id==='identity').status,'action');assert.equal(report.find(x=>x.id==='asr').status,'action');
 assert.match(find({state:{mode:'demo'},confirmed:true},'text').detail,/未验证真实模型/);
});
