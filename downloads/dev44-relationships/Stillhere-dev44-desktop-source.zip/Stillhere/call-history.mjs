// Retain IDs only. Content must always come from a fresh authorized state response.
export function createCallHistory({now=()=>Date.now()}={}){
 let start=null,end=null,ids=new Set();
 return {
  begin(){start=now();end=null;ids=new Set();},
  add(id){if(start!==null&&end===null&&typeof id==='string')ids.add(id);},
  finish(){if(start!==null&&end===null)end=now();},
  clear(){start=null;end=null;ids=new Set();},
  snapshot(){return {startedAt:start,endedAt:end,messageIds:[...ids]};}
 };
}
export function authorizedCallSummary(history,state){
 const ids=new Set(history.messageIds);
 const messages=(state.messages||[]).filter(m=>m.role==='assistant'&&ids.has(m.id));
 const referenceIds=new Set(messages.flatMap(m=>m.memoryIds||[]));
 const memories=(state.memories||[]).filter(m=>referenceIds.has(m.id));
 return {seconds:history.startedAt===null?0:Math.max(0,Math.floor(((history.endedAt??history.startedAt)-history.startedAt)/1000)),messages,memories};
}
