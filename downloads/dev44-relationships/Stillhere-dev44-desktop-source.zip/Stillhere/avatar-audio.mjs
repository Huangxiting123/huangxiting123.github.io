// Volume envelope only; this is not phoneme recognition or a reconstructed face.
export function mouthLevel(samples){
 if(!samples?.length)return 0;let sum=0;for(const value of samples){if(!Number.isFinite(value))return 0;const s=Math.max(-1,Math.min(1,value));sum+=s*s;}return Math.max(0,Math.min(1,(Math.sqrt(sum/samples.length)-0.015)*3));
}
export function smoothMouth(previous,target,elapsed=1/60){
 if(![previous,target,elapsed].every(Number.isFinite))return 0;const p=Math.max(0,Math.min(1,previous)),t=Math.max(0,Math.min(1,target)),seconds=Math.max(0,Math.min(0.25,elapsed));return p+(t-p)*(1-Math.exp(-seconds/(t>p?0.045:0.09)));
}
export function avatarCaption(phase,{playing=false,paused=false,buffering=false}={}){
 const labels={idle:'等待交流',listening:'正在聆听（录音中）',transcribing:'正在整理你说的话',review:'请先核对字幕',thinking:'正在查找记忆并组织回答',synthesizing:'正在准备回复声音',done:'本轮交流结束',failed:'处理失败，可查看文字提示'};
 if(phase==='demo')return playing?'本机测试音 · 非人物声音':'等待播放本机测试音';
 if(phase==='speaking')return buffering?'声音正在缓冲':playing?'正在说话 · 声音驱动示意':paused?'回复播放已暂停':'等待声音播放';return labels[phase]||labels.idle;
}
export function avatarTestTone(){
 const rate=16000,count=Math.round(rate*1.8),bytes=new Uint8Array(44+count*2),view=new DataView(bytes.buffer);const text=(offset,value)=>{for(let i=0;i<value.length;i++)bytes[offset+i]=value.charCodeAt(i);};text(0,'RIFF');view.setUint32(4,bytes.length-8,true);text(8,'WAVEfmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,rate,true);view.setUint32(28,rate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);text(36,'data');view.setUint32(40,count*2,true);for(let i=0;i<count;i++){const t=i/rate,fade=Math.min(1,t/0.08,(1.8-t)/0.08),envelope=0.18*(0.15+0.85*Math.sin(t*Math.PI*2)**2)*Math.max(0,fade);view.setInt16(44+i*2,Math.round(32767*envelope*Math.sin(2*Math.PI*220*t)),true);}return bytes;
}
