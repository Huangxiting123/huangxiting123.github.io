// Owns only local device tracks. No recording, signalling, or remote transport.
export function createVideoSession({getUserMedia,onChange=()=>{},now=()=>Date.now()}){
 let epoch=0,stream=null,phase='idle',muted=false,startedAt=null,error='',videoEnabled=true;
 const snapshot=()=>({phase,stream,muted,startedAt,error,videoEnabled});
 const emit=()=>onChange(snapshot());
 function stopTracks(value){for(const t of value?.getTracks()||[])t.stop();}
 function end(message=''){epoch++;const old=stream;stream=null;phase='idle';muted=false;startedAt=null;error=message;stopTracks(old);emit();}
 async function start({video=true}={}){
  if(phase!=='idle')return;
  videoEnabled=Boolean(video);const current=++epoch;phase='requesting';error='';emit();
  try{
   const acquired=await getUserMedia({video:videoEnabled?{facingMode:'user'}:false,audio:{echoCancellation:true,noiseSuppression:true}});
   if(current!==epoch){stopTracks(acquired);return;}
   stream=acquired;
   if(videoEnabled&&!stream.getVideoTracks().length||!stream.getAudioTracks().length)throw Error('没有获取到摄像头或麦克风，请检查设备。');
   for(const track of stream.getTracks())track.addEventListener('ended',()=>{if(current===epoch)end('设备已断开，请检查后重试。');},{once:true});
   startedAt=now();phase='preview';emit();
  }catch(e){if(current!==epoch)return;end(e.name==='NotAllowedError'?(videoEnabled?'未获得摄像头或麦克风权限，可选择仅麦克风模式或继续文字对话。':'未获得麦克风权限，可继续使用文字对话。'):e.name==='NotFoundError'?(videoEnabled?'未找到摄像头或麦克风，可选择仅麦克风模式重试。':'未找到麦克风，可继续使用文字对话。'):e.message||'设备启动失败');}
 }
 function toggleMute(){if(phase!=='preview')return;muted=!muted;for(const track of stream.getAudioTracks())track.enabled=!muted;emit();}
 return {start,end,toggleMute,snapshot};
}
