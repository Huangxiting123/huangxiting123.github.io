import {randomUUID} from 'node:crypto';
const fail=(message,status=400)=>{throw Object.assign(Error(message),{status});};
const text=(value,max,required=false)=>{if(typeof value!=='string'||value.length>max||required&&!value.trim())fail('培养资料字段为空或超过长度限制');return value.trim();};
export function defaultTwin(){return {revision:0,timezone:'Asia/Shanghai',hobbies:[],speakingExamples:[],thinkingExamples:[],scenes:[],routines:[],replyHabit:{minSeconds:0,maxSeconds:0},currentStatus:null};}
function windows(r){const start=toMinute(r.start),end=toMinute(r.end);return r.days.flatMap(day=>{const a=(day-1)*1440+start,b=(day-1)*1440+end+(end<start?1440:0);return b>10080?[[a,10080],[0,b-10080]]:[[a,b]];});}
function toMinute(s){if(typeof s!=='string'||!/^([01]\d|2[0-3]):[0-5]\d$/.test(s))fail('作息时间格式无效');return Number(s.slice(0,2))*60+Number(s.slice(3));}
export function updateTwin(state,input){
 if(!input||typeof input!=='object')fail('培养资料更新无效');
 const previous={...defaultTwin(),...state.twinTraining};if(!Number.isInteger(input.revision)||input.revision!==previous.revision)fail('培养资料已变化，请重新加载后再保存',409);
 const patch=input.patch;if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(k=>!['hobbies','speakingExamples','thinkingExamples','scenes','routines','replyHabit'].includes(k)))fail('培养资料更新无效');
 const next=structuredClone({...previous,...patch});if(next.timezone!=='Asia/Shanghai')fail('本版作息使用中国时间');
 for(const key of ['hobbies','speakingExamples','thinkingExamples','scenes','routines'])if(!Array.isArray(next[key])||next[key].length>20)fail('每类培养资料最多20项');
 for(const key of ['speakingExamples','thinkingExamples','scenes','routines'])if(next[key].some(x=>!x||typeof x!=='object'||Array.isArray(x)))fail('培养条目格式无效');
 next.hobbies=[...new Set(next.hobbies.map(x=>text(x,100,true)))];const ids=new Set();const id=value=>{const v=value??randomUUID();if(typeof v!=='string'||!/^[a-f0-9-]{36}$/.test(v)||ids.has(v))fail('培养条目编号无效或重复');ids.add(v);return v;};
 next.speakingExamples=next.speakingExamples.map(x=>({id:id(x.id),situation:text(x.situation,200,true),response:text(x.response,600,true),rhythm:text(x.rhythm,200)}));
 next.thinkingExamples=next.thinkingExamples.map(x=>({id:id(x.id),situation:text(x.situation,300,true),decision:text(x.decision,600,true),reason:text(x.reason,1000,true)}));
 next.scenes=next.scenes.map(x=>({id:id(x.id),name:text(x.name,80,true),description:text(x.description,1000,true)}));
 const sceneIds=new Set(next.scenes.map(s=>s.id));next.routines=next.routines.map(x=>{if(!sceneIds.has(x.sceneId))fail('作息引用的场景不存在，请先修改或删除对应作息');if(!Array.isArray(x.days)||!x.days.length||x.days.some(d=>!Number.isInteger(d)||d<1||d>7))fail('请选择有效的星期');toMinute(x.start);toMinute(x.end);if(x.start===x.end)fail('作息开始和结束不能相同');return {id:id(x.id),days:[...new Set(x.days)].sort(),start:x.start,end:x.end,sceneId:x.sceneId,activity:text(x.activity,200,true)};});
 const slots=next.routines.flatMap(r=>windows(r).map(w=>({start:w[0],end:w[1],id:r.id}))).sort((a,b)=>a.start-b.start);for(let i=1;i<slots.length;i++)if(slots[i].start<slots[i-1].end)fail('作息时段重叠，请调整后保存');
 const {minSeconds,maxSeconds}=next.replyHabit||{};if(!Number.isInteger(minSeconds)||!Number.isInteger(maxSeconds)||minSeconds<0||maxSeconds<minSeconds||maxSeconds>3600)fail('回复间隔应为0—3600秒，最大值不小于最小值');next.replyHabit={minSeconds,maxSeconds};
 if(next.currentStatus&&!sceneIds.has(next.currentStatus.sceneId))next.currentStatus=null;
 next.revision=previous.revision+1;state.twinTraining=next;state.messages=[];state.contextRevision++;return next;
}
export function setTwinStatus(state,input,now=new Date()){
 if(!input||typeof input!=='object')fail('状态格式无效');
 const record={...defaultTwin(),...state.twinTraining};if(input.revision!==record.revision)fail('培养资料已变化，请重新加载',409);
 if(input.clear===true)record.currentStatus=null;else{if(!record.scenes.some(s=>s.id===input.sceneId))fail('请先选择已保存场景');if(!Number.isInteger(input.validMinutes)||input.validMinutes<1||input.validMinutes>1440)fail('状态有效期应为1—1440分钟');record.currentStatus={sceneId:input.sceneId,activity:text(input.activity,200,true),reportedAt:now.toISOString(),expiresAt:new Date(now.getTime()+input.validMinutes*60000).toISOString(),source:'owner_reported'};}
 record.revision++;state.twinTraining=record;state.messages=[];state.contextRevision++;return record;
}
export function twinContext(state,now=new Date(),question=''){
 const record={...defaultTwin(),...state.twinTraining};const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{timeZone:record.timezone,weekday:'short',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(now).map(x=>[x.type,x.value]));const day=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].indexOf(parts.weekday),minute=day*1440+Number(parts.hour)*60+Number(parts.minute);
 let current={kind:'unknown',notice:'没有有效的本人当前状态，也没有匹配的作息；不能猜测真实行踪。'};
 if(record.currentStatus&&Date.parse(record.currentStatus.expiresAt)>now.getTime()&&Date.parse(record.currentStatus.reportedAt)<=now.getTime()){
  const scene=record.scenes.find(s=>s.id===record.currentStatus.sceneId);if(scene)current={kind:'owner_reported',scene,activity:record.currentStatus.activity,reportedAt:record.currentStatus.reportedAt,expiresAt:record.currentStatus.expiresAt,notice:'本人自述，仅在有效期内使用，不是设备实时定位。'};
 }else{const routine=record.routines.find(r=>windows(r).some(([start,end])=>minute>=start&&minute<end));if(routine){const scene=record.scenes.find(s=>s.id===routine.sceneId);if(scene)current={kind:'simulated',scene,activity:routine.activity,routineId:routine.id,notice:'按作息选择的模拟生活情境，不是本人当前真实行踪。'};}}
 const words=[...new Set(question.toLowerCase().match(/[a-z0-9]+|[\u4e00-\u9fff]/g)||[])];const examples=record.thinkingExamples.map((x,i)=>({x,i,score:words.reduce((n,w)=>n+(JSON.stringify(x).toLowerCase().includes(w)?1:0),0)})).sort((a,b)=>b.score-a.score||b.i-a.i).slice(0,3).map(x=>x.x);
 return {timezone:record.timezone,localTime:`${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}`,current,hobbies:record.hobbies,speakingExamples:record.speakingExamples.slice(-3),thinkingExamples:examples,replyHabit:{...record.replyHabit,applied:false,notice:'本轮仅记录回复间隔，测试立即回复，尚未执行延迟或微信发送。'}};
}
export function activityQuestion(value){if(/昨天|明天|小时候|以前|当时|去年|未来|\d+岁/.test(value)&&!/现在|目前|此刻|这会儿/.test(value))return false;return /在干[嘛吗什么]|在忙|在做什么|(?:你|我|分身)(?:现在|目前|此刻|这会儿)?在(?:哪里|哪儿|哪)(?:呢|呀|啊|吗)?(?:[？?。，,!！\s]|$)|(?:现在|目前|此刻|这会儿).*(?:在哪|做|干|忙)|what.*doing/i.test(value);}
export function markTwinAnswer(answer,context,question,now=new Date()){
 if(!activityQuestion(question))return answer;
 if(context.current.kind==='simulated')return '【模拟情境，非本人实时行踪】'+answer;
 if(context.current.kind==='owner_reported'&&Date.parse(context.current.expiresAt)>now.getTime())return '【本人自述状态，非实时定位】'+answer;
 return '我还没有有效的本人当前状态，无法确认你现在在哪里或在做什么。你可以在“本人当前状态”中告诉我，或设置作息供分身模拟。';
}
