!macro preInit
  IfFileExists "E:\" 0 +2
    StrCpy $INSTDIR "E:\Stillhere-Client"
!macroend
