"""MuseTalk 1.5 inference, batch=1. Stillhere supplies local landmarks and feather blending.
Uses vendored upstream MuseTalk VAE/audio code (MIT); no cloud inference or identity training.
"""
import argparse, json, os, sys, subprocess, wave, hashlib
from pathlib import Path

def validate_crop(crop,width,height):
    if not isinstance(crop,list) or len(crop)!=4 or any(type(x)!=int for x in crop): raise ValueError('Invalid face crop')
    x1,y1,x2,y2=crop
    if not (0<=x1<x2<=width and 0<=y1<y2<=height) or min(x2-x1,y2-y1)<48: raise ValueError('Face crop too small or outside image')
    return x1,y1,x2,y2

def main():
    p=argparse.ArgumentParser();p.add_argument('--models',required=True);p.add_argument('--job',required=True);args=p.parse_args()
    job=Path(args.job).resolve();models=Path(args.models).resolve()
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    with wave.open(str(job/'audio.wav')) as wav:
        duration=wav.getnframes()/wav.getframerate()
        if wav.getnchannels()!=1 or wav.getframerate()!=16000 or wav.getsampwidth()!=2 or not .2<=duration<=15:raise ValueError('Expected 0.2-15s mono PCM16 WAV')
    manifest=json.loads((models/'manifest.json').read_text())
    # Verify local binary weights before deserializing; installation also checks upstream LFS SHA.
    for entry in manifest['files']:
        path=models/entry['file'];digest=hashlib.sha256()
        with path.open('rb') as f:
            for part in iter(lambda:f.read(1024*1024),b''):digest.update(part)
        if digest.hexdigest()!=entry['sha256']:raise ValueError('Avatar model integrity check failed')
    import torch, cv2, numpy as np, imageio_ffmpeg
    from diffusers import UNet2DConditionModel
    from transformers import WhisperModel
    sys.path.insert(0,str(Path(__file__).parent/'vendor'))
    from musetalk.models.vae import VAE
    from musetalk.models.unet import PositionalEncoding
    from musetalk.utils.audio_processor import AudioProcessor
    if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
    frame=cv2.imread(str(job/'portrait.png'))
    if frame is None:raise ValueError('Cannot decode portrait')
    h,w=frame.shape[:2];crop=json.loads((job/'crop.json').read_text());x1,y1,x2,y2=validate_crop(crop,w,h)
    print('AVATAR: loading MuseTalk 1.5, fp16 UNet, batch 1',flush=True)
    torch.manual_seed(0);device=torch.device('cuda:0');dtype=torch.float16
    with torch.inference_mode():
        # Load CPU weights into a half model before moving it to GPU to reduce peak VRAM.
        config=json.loads((models/'musetalkV15/musetalk.json').read_text())
        unet=UNet2DConditionModel(**config).to(dtype=dtype)
        weights=torch.load(str(models/'musetalkV15/unet.pth'),map_location='cpu',weights_only=True)
        unet.load_state_dict(weights);del weights;unet=unet.to(device).eval()
        pe=PositionalEncoding(d_model=384).to(device=device,dtype=dtype)
        vae=VAE(model_path=str(models/'sd-vae'))
        vae.vae.eval()  # Keep VAE in float32 to avoid half precision overflow.
        processor=AudioProcessor(feature_extractor_path=str(models/'whisper'))
        whisper=WhisperModel.from_pretrained(str(models/'whisper'),local_files_only=True,torch_dtype=dtype).to(device).eval()
        features,length=processor.get_audio_feature(str(job/'audio.wav'))
        chunks=processor.get_whisper_chunk(features,device,dtype,whisper,length,fps=25)
        latent=vae.get_latents_for_unet(cv2.resize(frame[y1:y2,x1:x2],(256,256),interpolation=cv2.INTER_LANCZOS4)).to(device=device,dtype=dtype)
        mask=np.zeros((y2-y1,x2-x1),np.float32)
        # A local feathered lower-face blend replaces upstream mmpose/parser dependencies.
        cv2.ellipse(mask,((x2-x1)//2,int((y2-y1)*.70)),(max(1,int((x2-x1)*.46)),max(1,int((y2-y1)*.28))),0,0,360,1,-1)
        mask=cv2.GaussianBlur(mask,(0,0),max(1,(x2-x1)*.03))[...,None]
        command=[imageio_ffmpeg.get_ffmpeg_exe(),'-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s',str(w)+'x'+str(h),'-r','25','-i','pipe:0','-i',str(job/'audio.wav'),'-c:v','libx264','-preset','fast','-crf','20','-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2','-pix_fmt','yuv420p','-c:a','aac','-shortest','-movflags','+faststart',str(job/'result.mp4')]
        with (job/'ffmpeg.log').open('wb') as errors:
            encoder=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=errors)
            try:
                for i in range(len(chunks)):
                    batch=chunks[i:i+1].to(device=device,dtype=dtype)
                    predicted=unet(latent,torch.tensor([0],device=device),encoder_hidden_states=pe(batch)).sample
                    patch=vae.decode_latents(predicted.float())[0]
                    if not np.isfinite(patch).all():raise RuntimeError('Non-finite generated pixels')
                    patch=cv2.resize(patch,(x2-x1,y2-y1),interpolation=cv2.INTER_LANCZOS4)
                    output=frame.copy();original=output[y1:y2,x1:x2].astype(np.float32)
                    output[y1:y2,x1:x2]=(patch.astype(np.float32)*mask+original*(1-mask)).clip(0,255).astype(np.uint8)
                    cv2.putText(output,'AI GENERATED',(8,h-12),cv2.FONT_HERSHEY_SIMPLEX,.45,(255,255,255),1,cv2.LINE_AA)
                    encoder.stdin.write(output.tobytes())
                    if i%25==0:print('AVATAR: frame',i+1,'/',len(chunks),flush=True)
                encoder.stdin.close()
                if encoder.wait(timeout=60)!=0:raise RuntimeError('FFmpeg encoding failed')
            finally:
                if encoder.poll() is None:encoder.kill();encoder.wait()
    if not (job/'result.mp4').is_file() or (job/'result.mp4').stat().st_size<100:raise RuntimeError('Video output missing')
    print('AVATAR: complete',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as error:
        # Do not print audio, portrait bytes or personal story text.
        print('AVATAR_FAILED:',type(error).__name__,str(error)[:500],flush=True)
        sys.exit(1)
