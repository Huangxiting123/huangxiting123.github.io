import unittest
from render import validate_crop
class CropTests(unittest.TestCase):
    def test_crop_requires_in_image_integer_coordinates(self):
        self.assertEqual(validate_crop([1,2,90,100],100,120),(1,2,90,100))
        for value in ([-1,0,80,90],[0,0,101,100],[0,0,1,1],[0,0,80.5,90]):
            with self.assertRaises(ValueError):validate_crop(value,100,100)
if __name__=='__main__':unittest.main()
