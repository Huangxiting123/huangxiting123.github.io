import {mkdir,readFile,writeFile,rename,statfs,access} from 'node:fs/promises';
import {join,dirname} from 'node:path';import {homedir} from 'node:os';import {fileURLToPath} from 'node:url';import {spawn} from 'node:child_process';
import {modelStoragePlan,modelEnvironment} from '../local-models/storage.mjs';
const root=dirname(dirname(fileURLToPath(import.meta.url))),home=process.env.STILLHERE_LOCAL_HOME||join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local');let stage='检查目录';
async function run(exe,args,env){await new Promise((resolve,reject)=>{const child=spawn(exe,args,{env,stdio:'inherit',windowsHide:false});child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(Error('步骤失败，退出码 '+code)));});}
try{
 if(process.platform!=='win32')throw Error('此安装入口用于Windows');
 const stored=JSON.parse(await readFile(join(home,'model-storage.json'),'utf8'));const plan=modelStoragePlan({programRoot:root,dataHome:home,stored});await mkdir(plan.modelsHome,{recursive:true});const disk=await statfs(plan.modelsHome);if(Number(disk.bavail)*Number(disk.bsize)<15*1024**3)throw Error('请在模型磁盘预留至少15GiB安装空间');
 console.log('口型模型安装 dev34；照片和声音不上传。模型目录：'+plan.modelsHome);console.log('保留原有对话与声音环境，新建独立口型运行环境。需联网下载运行库和MuseTalk/VAE/Whisper权重。');
 const uv=join(plan.tools,'uv.exe');await access(uv);const environment=modelEnvironment(plan),runtime=join(plan.modelsHome,'avatar-runtime'),python=join(runtime,'Scripts','python.exe');
 stage='[1/4] Python 3.10';console.log(stage);try{await access(python);}catch{await run(uv,['venv','--python','3.10',runtime],environment);}
 stage='[2/4] PyTorch CUDA依赖';console.log(stage);await run(uv,['pip','install','--python',python,'torch==2.7.1','torchvision==0.22.1','--index-url','https://download.pytorch.org/whl/cu118'],environment);
 stage='[3/4] 口型推理依赖';console.log(stage);await run(uv,['pip','install','--python',python,'diffusers==0.30.2','accelerate==0.28.0','numpy==1.26.4','opencv-python==4.9.0.80','soundfile==0.12.1','transformers==4.39.2','huggingface_hub==0.30.2','librosa==0.11.0','einops==0.8.1','imageio-ffmpeg==0.6.0'],environment);
 stage='[4/4] 官方权重与校验';console.log(stage);const models=join(plan.modelsHome,'avatar-models');await run(python,[join(root,'local-avatar','download_models.py'),'--models',models],environment);
 const value={version:1,python,modelDir:models,manifest:join(models,'manifest.json')};await mkdir(home,{recursive:true});await writeFile(join(home,'avatar-models.json.tmp'),JSON.stringify(value,null,2));await rename(join(home,'avatar-models.json.tmp'),join(home,'avatar-models.json'));console.log('口型依赖和权重已准备。请启动软件进行首次真实口型生成验收；此消息不表示画面效果已验证。');
}catch(e){console.error('口型安装停在：'+stage+'；'+e.message);console.error('已完成的下载保留；请截图最后的错误，不要删除原模型。');process.exitCode=1;}
