"""Fetch only three model components from their published upstream repositories."""
import argparse, hashlib, json, os
from pathlib import Path
from huggingface_hub import HfApi, hf_hub_download

def main():
    p=argparse.ArgumentParser();p.add_argument('--models',required=True);args=p.parse_args()
    root=Path(args.models);root.mkdir(parents=True,exist_ok=True)
    import torch
    if not torch.cuda.is_available(): raise SystemExit('CUDA unavailable; inspect NVIDIA driver before downloading weights')
    print('GPU:',torch.cuda.get_device_name(0),flush=True)
    specs=[('TMElyralab/MuseTalk','musetalkV15',['musetalkV15/musetalk.json','musetalkV15/unet.pth']),
           ('stabilityai/sd-vae-ft-mse','sd-vae',['config.json','diffusion_pytorch_model.bin']),
           ('openai/whisper-tiny','whisper',['config.json','pytorch_model.bin','preprocessor_config.json'])]
    lock_path=root/'download-lock.json'
    lock=json.loads(lock_path.read_text()) if lock_path.exists() else {}
    manifest=[];api=HfApi(endpoint='https://huggingface.co')
    for repo,target,files in specs:
        revision=lock.get(repo)
        info=api.model_info(repo,revision=revision,files_metadata=True)
        if not revision:
            lock[repo]=info.sha;temp=lock_path.with_suffix('.tmp');temp.write_text(json.dumps(lock,indent=2));os.replace(temp,lock_path)
        revision=lock[repo];metadata={x.rfilename:x for x in info.siblings}
        print('Downloading',repo,'revision',revision,flush=True)
        for name in files:
            dest=root/target;dest.mkdir(exist_ok=True)
            downloaded=Path(hf_hub_download(repo_id=repo,filename=name,revision=revision,endpoint='https://huggingface.co'))
            h=hashlib.sha256()
            with downloaded.open('rb') as f:
                for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
            sha=h.hexdigest();meta=metadata.get(name);lfs=getattr(meta,'lfs',None)
            expected=lfs.get('sha256') if isinstance(lfs,dict) else getattr(lfs,'sha256',None)
            if expected and expected!=sha:raise RuntimeError('Weight SHA256 mismatch: '+repo+'/'+name)
            output=dest/Path(name).name
            if not output.exists() or output.stat().st_size!=downloaded.stat().st_size:
                temp=output.with_suffix(output.suffix+'.tmp')
                import shutil
                shutil.copyfile(downloaded,temp);os.replace(temp,output)
            else:
                # Check existing installed bytes as well, not only the download cache.
                old=hashlib.sha256()
                with output.open('rb') as f:
                    for chunk in iter(lambda:f.read(1024*1024),b''):old.update(chunk)
                if old.hexdigest()!=sha:
                    import shutil
                    shutil.copyfile(downloaded,output)
            manifest.append({'repo':repo,'revision':revision,'file':output.relative_to(root).as_posix(),'sha256':sha,'bytes':output.stat().st_size})
            print('Verified:',output.name,output.stat().st_size,flush=True)
    temporary=root/'manifest.json.tmp';temporary.write_text(json.dumps({'files':manifest,'engine':'MuseTalk 1.5, Stillhere landmark crop and feather blend'},indent=2));os.replace(temporary,root/'manifest.json')
if __name__=='__main__':main()
