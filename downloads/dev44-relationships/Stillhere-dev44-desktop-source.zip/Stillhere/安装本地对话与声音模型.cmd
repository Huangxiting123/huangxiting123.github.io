@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0local-models\setup.mjs"
) else (
  node "%~dp0local-models\setup.mjs"
)
pause
