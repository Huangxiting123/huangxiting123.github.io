import test from 'node:test';
import assert from 'node:assert/strict';
import {createCallTurn} from './call-turn.mjs';
test('transcription requires review; confirmed text uses authorized message id for speech',async()=>{
 const calls=[],phases=[];const t=createCallTurn({request:async(path,data)=>{calls.push({path,data});return path==='speech/transcribe'?{text:'原始转写'}:path==='chat'?{assistant:{id:'reply-1',text:'依据记忆回答'}}:new Blob(['audio']);},onChange:s=>phases.push(s.phase),play:async()=>{}});
 await t.transcribe(new Blob(['input']));assert.equal(t.snapshot().phase,'review');assert.equal(calls.length,1);await t.submit(' 核对后的文字 ');
 assert.equal(calls[1].data.text,'核对后的文字');assert.deepEqual(calls[2].data,{messageId:'reply-1'});assert.equal(t.snapshot().phase,'done');assert.equal(t.snapshot().answer,'依据记忆回答');assert.ok(phases.includes('speaking'));
});
test('cancelled transcription cannot populate a newer identity or turn',async()=>{
 let resolve,signal;const t=createCallTurn({request:(_,__,s)=>{signal=s;return new Promise(r=>resolve=r);},play:async()=>{}});
 const pending=t.transcribe(new Blob(['input']));t.cancel();resolve({text:'旧身份转写'});await pending;assert.equal(signal.aborted,true);assert.equal(t.snapshot().phase,'idle');assert.equal(t.snapshot().transcript,'');
});
test('interrupting pending chat prevents synthesis and late playback',async()=>{
 let resolve;const calls=[];const t=createCallTurn({request:async(path)=>{calls.push(path);if(path==='speech/transcribe')return {text:'问题'};return new Promise(r=>resolve=r);},play:async()=>assert.fail('late playback')});
 await t.transcribe(new Blob());const pending=t.submit('问题');t.cancel();resolve({assistant:{id:'late',text:'旧回复'}});await pending;assert.deepEqual(calls,['speech/transcribe','chat']);assert.equal(t.snapshot().answer,'');
});
test('blocked input never enters review or chat',async()=>{
 const t=createCallTurn({request:async()=>({blocked:true,message:'话题规则拦截'}),play:async()=>{}});await t.transcribe(new Blob());assert.equal(t.snapshot().phase,'idle');assert.match(t.snapshot().error,/拦截/);await t.submit('不应发送');assert.equal(t.snapshot().phase,'idle');
});
test('TTS failure retains returned subtitles and does not duplicate the chat',async()=>{
 let chats=0;const t=createCallTurn({request:async(path)=>{if(path==='speech/transcribe')return {text:'问题'};if(path==='chat'){chats++;return {assistant:{id:'a',text:'可阅读的字幕'}};}throw Error('朗读服务失败');},play:async()=>{}});
 await t.transcribe(new Blob());await t.submit('问题');assert.equal(t.snapshot().phase,'failed');assert.equal(t.snapshot().answer,'可阅读的字幕');await t.submit('问题');assert.equal(chats,1);
});
test('duplicate send and empty transcript are rejected before another chat request',async()=>{
 let resolve,chats=0;const t=createCallTurn({request:async path=>{if(path==='speech/transcribe')return {text:'问题'};chats++;return new Promise(r=>resolve=r);},play:async()=>{}});
 await t.transcribe(new Blob());await t.submit('  ');assert.equal(chats,0);const p=t.submit('确认');await t.submit('重复');assert.equal(chats,1);t.cancel();resolve({assistant:{id:'a',text:'旧回复'}});await p;
});
test('speech retry resynthesizes the same authorized reply without creating another chat',async()=>{
 const calls=[];let fail=true,played=0;const t=createCallTurn({request:async(path,data)=>{calls.push({path,data});if(path==='speech/transcribe')return {text:'问题'};if(path==='chat')return {assistant:{id:'reply',text:'保留的回复'}};if(fail){fail=false;throw Error('临时朗读故障');}return new Blob(['audio']);},play:async()=>{played++;}});
 await t.transcribe(new Blob());await t.submit('问题');assert.equal(t.snapshot().phase,'failed');await t.retrySpeech();assert.equal(t.snapshot().phase,'done');assert.equal(played,1);await t.retrySpeech();assert.equal(played,2);assert.equal(calls.filter(c=>c.path==='chat').length,1);assert.deepEqual(calls.filter(c=>c.path==='speech/synthesize').map(c=>c.data.messageId),['reply','reply','reply']);
});
test('duplicate retry and cancellation cannot play a late retry response',async()=>{
 let retry=false,resolve,syntheses=0;const t=createCallTurn({request:async path=>{if(path==='speech/transcribe')return {text:'问题'};if(path==='chat')return {assistant:{id:'a',text:'回复'}};syntheses++;if(retry)return new Promise(r=>resolve=r);throw Error('临时故障');},play:async()=>assert.fail('cancelled playback')});
 await t.transcribe(new Blob());await t.submit('问题');retry=true;const p=t.retrySpeech();await t.retrySpeech();assert.equal(syntheses,2);t.cancel();resolve(new Blob(['audio']));await p;assert.equal(t.snapshot().phase,'idle');assert.equal(t.snapshot().messageId,null);await t.retrySpeech();assert.equal(syntheses,2);
});
test('revoked speech access is reported without resending the question',async()=>{
 let chat=0;const t=createCallTurn({request:async path=>{if(path==='speech/transcribe')return {text:'问题'};if(path==='chat'){chat++;return {assistant:{id:'a',text:'回复'}};}throw Error('未找到此身份可朗读的回复');},play:async()=>{}});
 await t.transcribe(new Blob());await t.submit('问题');await t.retrySpeech();assert.equal(chat,1);assert.equal(t.snapshot().phase,'failed');assert.match(t.snapshot().error,/此身份/);
});
test('typed questions can finish as text without transcribing or synthesizing',async()=>{
 const calls=[];const t=createCallTurn({request:async(path,data)=>{calls.push({path,data});return {assistant:{id:'text-reply',text:'有来源的文字回答'}};},play:async()=>assert.fail('text-only mode must not play')});await t.ask('  一个文字问题  ');assert.deepEqual(calls,[{path:'chat',data:{text:'一个文字问题'}}]);assert.equal(t.snapshot().phase,'done');assert.equal(t.snapshot().inputMode,'text');assert.equal(t.snapshot().answer,'有来源的文字回答');
});
test('typed questions can explicitly request synthesis and reuse the same reply for replay',async()=>{
 const paths=[];let plays=0;const t=createCallTurn({request:async path=>{paths.push(path);return path==='chat'?{assistant:{id:'a',text:'回答'}}:new Blob(['audio']);},play:async()=>{plays++;}});await t.ask('问题',{speak:true});assert.deepEqual(paths,['chat','speech/synthesize']);assert.equal(plays,1);await t.retrySpeech();assert.deepEqual(paths,['chat','speech/synthesize','speech/synthesize']);assert.equal(plays,2);
});
test('typed questions cannot overwrite a pending voice review or submit duplicate in-flight questions',async()=>{
 let resolve,chats=0;const t=createCallTurn({request:async path=>{if(path==='speech/transcribe')return {text:'待核对的录音'};chats++;return new Promise(r=>resolve=r);},play:async()=>{}});await t.transcribe(new Blob());await t.ask('不能覆盖转写');assert.equal(chats,0);assert.equal(t.snapshot().transcript,'待核对的录音');t.cancel();const p=t.ask('唯一的问题');await t.ask('重复点击');assert.equal(chats,1);resolve({assistant:{id:'a',text:'回答'}});await p;assert.equal(t.snapshot().transcript,'唯一的问题');
});
test('canceling a typed question prevents a late reply and audio from reappearing',async()=>{
 let resolve;const t=createCallTurn({request:()=>new Promise(r=>resolve=r),play:async()=>assert.fail('late audio')});const p=t.ask('问题',{speak:true});t.cancel();resolve({assistant:{id:'late',text:'旧身份的回答'}});await p;assert.equal(t.snapshot().phase,'idle');assert.equal(t.snapshot().answer,'');assert.equal(t.snapshot().inputMode,null);
});
test('invalid typed input does not create chat requests or erase a previous answer',async()=>{
 let calls=0;const t=createCallTurn({request:async()=>{calls++;return {assistant:{id:'a',text:'旧回答'}};},play:async()=>{}});await t.ask('有效问题');for(const value of ['', '   ',null,'x'.repeat(5001)])await t.ask(value);assert.equal(calls,1);assert.equal(t.snapshot().answer,'旧回答');assert.match(t.snapshot().error,/5000/);
});
