# 续在 STILLHERE 0.7.0-dev.32

新增本人信息、语气示例及授权声样的对话原型，配套本机模型安装器和自动桥接启动。文本Ollama Qwen3 4B CPU、声音Qwen3-TTS0.6B Base CUDA；首次需安装Ollama并下载独立权重，本包不含Qwen权重。

154项Node、3项Python协议及浏览器模拟服务验证通过，采集回归通过。未验证真实Qwen生成、Windows安装、3060 Ti资源占用和声音相似度，不把模拟音频当作本人声音。请按功能验收目录dev32，从E00安装开始测试。
