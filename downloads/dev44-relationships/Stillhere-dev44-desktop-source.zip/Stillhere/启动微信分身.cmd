@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
 echo Extract this update into your existing Stillhere folder first.
 pause
 exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0wechat-twin\server.mjs"
pause
