import {ASSET_AUDIO_RATE} from './asset-audio.mjs';
// Energy-only pause hints, not a voice activity classifier. Never discard spans.
export function planSpeechSegments(samples){
 const rate=ASSET_AUDIO_RATE,frame=320,energies=[];for(let start=0;start<samples.length;start+=frame){let sum=0;const end=Math.min(samples.length,start+frame);for(let i=start;i<end;i++)sum+=samples[i]*samples[i];energies.push(Math.sqrt(sum/(end-start)));}
 const sorted=[...energies].sort((a,b)=>a-b),threshold=Math.max(.0003,Math.min(.003,(sorted[Math.floor(sorted.length*.1)]||0)*1.5));const spans=[];let start=0;
 while(start<samples.length){if(samples.length-start<=20*rate){spans.push({start,end:samples.length});break;}const low=Math.ceil((start+8*rate)/frame),high=Math.floor((start+20*rate)/frame);let run=0,best=null;
 for(let i=low;i<high;i++){if(energies[i]<threshold){run++;if(run>=10){const middle=(i-Math.floor(run/2))*frame,score=Math.abs(middle-(start+16*rate));if(!best||score<best.score)best={end:middle,score};}}else run=0;}
 const end=best?.end||Math.min(samples.length,start+20*rate);spans.push({start,end});start=end;
 }return spans;
}
export function prepareRecognitionAudio(input){
 let peak=0,sum=0,clipped=0;for(const x of input){peak=Math.max(peak,Math.abs(x));sum+=x*x;if(Math.abs(x)>=.99)clipped++;}const rms=Math.sqrt(sum/input.length),warnings=[];if(rms<.01)warnings.push('音量偏低，建议靠近麦克风并检查实际收音设备');if(clipped/input.length>.01)warnings.push('录音存在削波，建议降低麦克风增益并重新采集');
 const gain=rms>.0003&&rms<.03?Math.max(1,Math.min(4,.08/rms,.95/Math.max(peak,.000001))):1;const samples=gain>1?Float32Array.from(input,x=>x*gain):input;
 return {samples,quality:{rms,peak,clippedRatio:clipped/input.length,gain,warnings}};
}
