import test from 'node:test';
import assert from 'node:assert/strict';
import {stunAttribute,stunPacket,stunAttributes,validStunIntegrity,probeTurn} from './turn-probe.mjs';
test('STUN integrity matches the published RFC5769 request vector including padding and fingerprint',()=>{
 const packet=Buffer.from('000100582112a442b7e7a701bc34d686fa87dfae802200105354554e207465737420636c69656e74002400046e0001ff80290008932ff9b151263b36000600096576746a3a68367659202020000800149aeaa70cbfd8cb56781ef2b5b2d3f249c1b571a280280004e57a3bcf','hex');assert.equal(validStunIntegrity(packet,Buffer.from('VOkJxbRl1RmTxUk/WvJxBt')),true);const tampered=Buffer.from(packet);tampered[30]^=1;assert.equal(validStunIntegrity(tampered,Buffer.from('VOkJxbRl1RmTxUk/WvJxBt')),false);
});
test('STUN packets preserve padded attributes and reject malformed message boundaries',()=>{
 const p=stunPacket(3,[stunAttribute(6,Buffer.from('abc'))],Buffer.alloc(12));assert.equal(stunAttributes(p)[0].value.toString(),'abc');assert.throws(()=>stunAttributes(p.subarray(0,p.length-1)));const malformed=Buffer.from(p);malformed.writeUInt16BE(100,22);assert.throws(()=>stunAttributes(malformed));assert.equal(validStunIntegrity(p,Buffer.from('key')),false);
});
test('TURN checker rejects unsupported UDP and credentials before attempting a connection',async()=>{
 await assert.rejects(probeTurn({url:'turn:example.com?transport=udp',sharedSecret:'test-secret-not-used'}),/只支持/);await assert.rejects(probeTurn({url:'turns:example.com',sharedSecret:'short'}),/共享密钥/);
});
