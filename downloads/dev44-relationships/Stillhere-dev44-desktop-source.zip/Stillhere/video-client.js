import {createCapturePanel} from './capture-client.js';
import {createLocalReadiness} from './local-readiness-client.js';
import {createAvatarPresenter} from './avatar-presenter.js';
import {createRtcControls} from './rtc-client.js';
import {createConnectionPanel} from './connection-client.js';
import {createFaceControls} from './face-client.js';
import {createCallIdentity} from './call-identity-client.js';
import {createCallHistory,authorizedCallSummary} from './call-history.mjs';
import {memoryDetails} from './message-details.js';
import {createCallSpeech} from './call-speech.js';
import {createVideoSession} from './video-session.mjs';
export function createVideoControls(options){
 const panel=document.createElement('section');panel.className='video-workbench';
 panel.innerHTML=`<h2>数字分身素材采集 <small>本机开发预览</small></h2>
 <p class="muted">先采集本人的声音与形象说话素材。无需配置语音服务即可录制、回放和下载；转写与数字人制作后续单独接入。</p>
 <div class="video-grid"><div class="persona-placeholder"><strong>数字分身</strong><p data-persona></p><p>等待接入形象与实时视频服务</p></div><div><video autoplay muted playsinline aria-label="自己的摄像头预览"></video><p class="muted" data-camera-note>你的本机画面 · 播放始终静音以避免回声</p></div></div>
 <label>设备模式<select data-device-mode><option value="video">摄像头与麦克风</option><option value="audio">仅麦克风（不使用摄像头）</option></select></label><label><input data-consent type="checkbox" style="width:auto"> 允许本次预览使用所选设备</label>
 <div class="video-actions"><button type="button" data-start>开始设备预览</button><button type="button" data-mute class="secondary">关闭预览麦克风</button><button type="button" data-end class="secondary">结束预览</button></div>
 <p data-status role="status" aria-live="polite"></p><p class="muted">预览时长 <span data-duration>00:00</span> · 麦克风开关控制本机预览及双端实时发送；录音转写有独立的授权与设备控制。</p>`;
 document.querySelector('#chat').before(panel);
 const style=document.createElement('style');style.textContent='.video-workbench{border:1px solid #d5ddd6;border-radius:16px;padding:18px;margin-bottom:20px}.video-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.video-grid video{display:block;width:100%;aspect-ratio:4/3;background:#192f29;border-radius:14px;object-fit:cover}.persona-placeholder{background:#e9eee6;border-radius:14px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:15px}.video-actions{display:flex;flex-wrap:wrap;gap:8px}@media(max-width:600px){.video-grid{grid-template-columns:1fr}}';document.head.append(style);
 const q=s=>panel.querySelector(s),video=q('video'),consent=q('[data-consent]');let tick=null,previous='idle',summaryEpoch=0;const history=createCallHistory();
 const avatar=createAvatarPresenter(panel.querySelector('.persona-placeholder'));
 const connection=createConnectionPanel(panel);
 const summary=document.createElement('section');summary.hidden=true;summary.setAttribute('aria-live','polite');panel.append(summary);
 const session=createVideoSession({getUserMedia:options=>{
  if(!navigator.mediaDevices?.getUserMedia)throw Error('当前浏览器不支持设备预览，请使用本机地址和支持摄像头的浏览器。');
  return navigator.mediaDevices.getUserMedia(options);
 },onChange:update});
 let speech=null,face=null,rtc=null,readiness=null,capture=null;const identity=createCallIdentity({...options,panel,onChange:()=>{readiness?.sync();speech?.syncButtons();face?.sync();rtc?.sync();},onPause:()=>{session.end();history.clear();summaryEpoch++;summary.hidden=true;summary.replaceChildren();options.beforeRecord?.();}});
 readiness=createLocalReadiness({panel,getSession:session.snapshot,isConfirmed:identity.confirmed});
 speech=createCallSpeech({...options,panel,avatar,getSession:session.snapshot,onReply:id=>history.add(id),isIdentityConfirmed:()=>identity.confirmed()&&(!face||face.ready()),getCallSession:identity.id});
 face=createFaceControls({panel,getSession:session.snapshot,isConfirmed:identity.confirmed,onMismatch:identity.pause,onChange:()=>speech?.syncButtons()});
 rtc=createRtcControls({...options,panel,getSession:session.snapshot,getCallSession:identity.id,isConfirmed:identity.confirmed,onHangup:()=>session.end()});
 function syncButtons(){const s=session.snapshot();q('[data-device-mode]').disabled=s.phase!=='idle';q('[data-start]').disabled=s.phase!=='idle'||!consent.checked;q('[data-mute]').disabled=s.phase!=='preview';q('[data-end]').disabled=s.phase==='idle';speech.syncButtons();face?.sync();rtc?.sync();avatar.sync();readiness?.sync();capture?.sync();}
 function duration(){const s=session.snapshot();const seconds=s.startedAt===null?0:Math.floor((Date.now()-s.startedAt)/1000);q('[data-duration]').textContent=String(Math.floor(seconds/60)).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');}
 function update(s){if(s.phase==='preview'&&previous!=='preview'){history.begin();summaryEpoch++;summary.hidden=true;summary.replaceChildren();}if(s.phase==='idle'&&previous==='preview')history.finish();previous=s.phase;if(tick)clearInterval(tick);tick=null;const changed=video.srcObject!==s.stream;if(changed)video.srcObject=s.stream;video.hidden=s.phase==='preview'&&!s.videoEnabled;q('[data-camera-note]').textContent=video.hidden?'仅麦克风模式 · 未申请摄像头权限':'你的本机画面 · 播放始终静音以避免回声';
  q('[data-status]').textContent=s.error||(s.phase==='requesting'?'等待设备权限，可随时取消…':s.phase==='preview'?'本机预览中；未连接远端数字人。':'预览未开启。');
  q('[data-mute]').textContent=s.muted?'开启预览麦克风':'关闭预览麦克风';
  if(s.phase==='idle')consent.checked=false;
  if(s.phase==='preview'){tick=setInterval(duration,1000);if(changed&&s.videoEnabled)video.play().catch(()=>{if(session.snapshot().stream===s.stream)session.end('画面无法播放，请结束后重试。');});}
  duration();speech.deviceChanged(s);face?.deviceChanged(s);rtc?.deviceChanged(s);syncButtons();
 }
 function reset(){capture.reset();readiness?.reset();rtc?.reset();connection.reset();identity.reset();summaryEpoch++;history.clear();summary.hidden=true;summary.replaceChildren();session.end();q('[data-persona]').textContent='';}
 consent.onchange=()=>{if(!consent.checked)session.end();syncButtons();};q('[data-start]').onclick=()=>{if(consent.checked)session.start({video:q('[data-device-mode]').value==='video'});};q('[data-mute]').onclick=session.toggleMute;q('[data-end]').onclick=async()=>{session.end();const current=++summaryEpoch;if(history.snapshot().startedAt===null)return;summary.hidden=false;summary.textContent='正在核对本次交流记录与当前权限…';try{await options.refresh();if(current!==summaryEpoch)return;renderSummary();}catch{if(current===summaryEpoch)summary.textContent='无法取得当前授权记录，本次摘要暂不可展示。';}};
 document.addEventListener('workspacechange',e=>{if(e.detail!=='chat')session.end();});
 window.addEventListener('pagehide',reset);document.addEventListener('visibilitychange',()=>{if(document.hidden)session.end();});
 function renderSummary(){const h=history.snapshot();if(h.endedAt===null)return;const state=options.getState();const result=authorizedCallSummary(h,state);summary.replaceChildren();const title=document.createElement('h3');title.textContent='本次交流已结束';const info=document.createElement('p');info.textContent='设备预览 '+result.seconds+' 秒 · 当前可回看的回复 '+result.messages.length+' 条 · 参考记忆 '+result.memories.length+' 条';summary.append(title,info);const note=document.createElement('p');note.className='muted';note.textContent='仅统计此工作台收到的语音回复；取消后服务端才返回的消息可能不在摘要内。预览时长不是远端视频通话时长。参考记忆曾被召回，不代表回答已经逐项核实。';summary.append(note);for(const message of result.messages){const text=document.createElement('p');text.textContent=message.text;summary.append(text,memoryDetails(message,result.memories,state.role==='owner'));}}
 const advanced=document.createElement('details');const advancedTitle=document.createElement('summary');advancedTitle.textContent='进阶测试：对话、身份核对与双端连接（采集素材无需使用）';const children=[...panel.children].slice(2);advanced.append(advancedTitle,...children);capture=createCapturePanel(panel,options);panel.append(advanced);advanced.addEventListener('toggle',()=>{if(!advanced.open){session.end();identity.reset();}});
 syncButtons();return {reset,syncButtons,render:state=>{capture.render(state);readiness.render(state);connection.render(state);identity.render(state);rtc?.render(state);q('[data-persona]').textContent=state.profile.name||'尚未填写人物姓名';speech.render(state);if(!summary.hidden)renderSummary();}};
}
