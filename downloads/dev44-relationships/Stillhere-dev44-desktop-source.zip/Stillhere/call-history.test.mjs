import test from 'node:test';
import assert from 'node:assert/strict';
import {createCallHistory,authorizedCallSummary} from './call-history.mjs';
test('session tracks unique reply IDs, duration, and ignores replies after end',()=>{
 let time=0;const h=createCallHistory({now:()=>time});h.add('outside');h.begin();h.add('a');h.add('a');time=2500;h.finish();h.add('late');time=9000;h.finish();assert.deepEqual(h.snapshot(),{startedAt:0,endedAt:2500,messageIds:['a']});assert.equal(authorizedCallSummary(h.snapshot(),{}).seconds,2);h.begin();assert.deepEqual(h.snapshot().messageIds,[]);
});
test('summary uses only messages and memories from current authorized state',()=>{
 const history={startedAt:0,endedAt:1000,messageIds:['allowed','revoked','user']};
 const state={messages:[{id:'allowed',role:'assistant',text:'可见回答',memoryIds:['visible','secret']},{id:'other',role:'assistant',text:'其他会话',memoryIds:['other']},{id:'user',role:'user',text:'不是回复'}],memories:[{id:'visible',text:'可见记忆'},{id:'other',text:'其他记忆'}]};
 const result=authorizedCallSummary(history,state);assert.deepEqual(result.messages.map(m=>m.id),['allowed']);assert.deepEqual(result.memories.map(m=>m.id),['visible']);assert.doesNotMatch(JSON.stringify(result),/其他会话|其他记忆|不是回复/);
 const revoked=authorizedCallSummary(history,{messages:[],memories:[]});assert.equal(revoked.messages.length,0);assert.equal(revoked.memories.length,0);
});
test('clear removes session identifiers for account changes',()=>{
 const h=createCallHistory();h.begin();h.add('private');h.clear();assert.deepEqual(h.snapshot(),{startedAt:null,endedAt:null,messageIds:[]});assert.equal(authorizedCallSummary(h.snapshot(),{}).seconds,0);
});
test('references are deduplicated across replies and dropped when a memory is withdrawn',()=>{
 const h={startedAt:0,endedAt:3000,messageIds:['a','b']};const state={messages:[{id:'a',role:'assistant',memoryIds:['m','withdrawn']},{id:'b',role:'assistant',memoryIds:['m']}],memories:[{id:'m',text:'仍可见'}]};assert.deepEqual(authorizedCallSummary(h,state).memories,[{id:'m',text:'仍可见'}]);
});
