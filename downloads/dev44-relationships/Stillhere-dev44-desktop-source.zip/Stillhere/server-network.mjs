export function networkOptions(env={}){
 const port=Number(env.PORT||4317);if(!Number.isInteger(port)||port<1||port>65535)throw Error('PORT必须是1到65535的整数');
 const host=env.PERSONA_LISTEN_HOST||'127.0.0.1';if(!['127.0.0.1','0.0.0.0','::1'].includes(host))throw Error('PERSONA_LISTEN_HOST仅支持127.0.0.1、::1或0.0.0.0');
 const cert=env.PERSONA_TLS_CERT||'',key=env.PERSONA_TLS_KEY||'';
 if(Boolean(cert)!==Boolean(key))throw Error('HTTPS需要同时提供PERSONA_TLS_CERT与PERSONA_TLS_KEY文件路径');
 const tls=Boolean(cert&&key),scheme=tls?'https':'http';let publicOrigin=null;
 if(env.PERSONA_PUBLIC_ORIGIN){
  let url;try{url=new URL(env.PERSONA_PUBLIC_ORIGIN);}catch{throw Error('PERSONA_PUBLIC_ORIGIN必须是完整HTTPS来源');}
  if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash||url.hostname.includes('*'))throw Error('手机访问地址必须是HTTPS来源，不能带路径、查询、账号或通配符');
  if(Number(url.port||443)!==port)throw Error('手机访问地址的端口必须与PORT一致');
  if(!tls)throw Error('手机访问需要配置HTTPS证书与私钥');publicOrigin=url.origin;
 }
 if(host==='0.0.0.0'&&(!tls||!publicOrigin))throw Error('局域网监听必须配置HTTPS及PERSONA_PUBLIC_ORIGIN');
 const loopback=host==='::1'?`[::1]:${port}`:`127.0.0.1:${port}`;
 const origins=new Set([`${scheme}://${loopback}`,`${scheme}://localhost:${port}`].map(s=>new URL(s).origin));if(publicOrigin)origins.add(publicOrigin);
 const hosts=new Set([...origins].map(s=>new URL(s).host));
 return {port,host,tls,cert,key,origins,hosts,url:publicOrigin||`${scheme}://${loopback}`,mode:host==='0.0.0.0'?'lan-https':tls?'local-https':'local-http'};
}
export function checkRequestOrigin(options,headers){
 if(typeof headers.host!=='string'||!options.hosts.has(headers.host.toLowerCase()))throw Object.assign(Error('主机不允许'),{status:403});
 if(headers.origin!==undefined&&(typeof headers.origin!=='string'||!options.origins.has(headers.origin)))throw Object.assign(Error('来源不允许'),{status:403});
}
export function connectionInfo(options){return {mode:options.mode,secure:options.tls,url:options.url,remoteAccess:options.mode==='lan-https'};}
