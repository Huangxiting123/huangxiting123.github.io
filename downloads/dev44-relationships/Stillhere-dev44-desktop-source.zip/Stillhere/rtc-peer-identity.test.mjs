import test from 'node:test';
import assert from 'node:assert/strict';
import {describePeerIdentity} from './rtc-peer-identity.mjs';
test('identity wording never treats an invitation as a recognized person',()=>{
 const room={status:'waiting',peerName:'小雨',peerRelation:'女儿',peerIdentity:'awaiting'};
 assert.match(describePeerIdentity(room),/等待本人登录/);
 assert.doesNotMatch(describePeerIdentity(room),/对端已确认/);
 assert.match(describePeerIdentity({...room,peerIdentity:'account_confirmed'}),/小雨 · 关系：女儿/);
 assert.match(describePeerIdentity({...room,peerIdentity:'account_confirmed'}),/不代表已通过人脸或声纹识别/);
 assert.equal(describePeerIdentity({...room,status:'ended',peerIdentity:'account_confirmed'}),describePeerIdentity(null));
 assert.match(describePeerIdentity({...room,peerIdentity:undefined}),/未知/);
});
