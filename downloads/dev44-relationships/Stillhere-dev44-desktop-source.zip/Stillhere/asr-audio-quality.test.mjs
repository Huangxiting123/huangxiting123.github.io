import test from 'node:test';
import assert from 'node:assert/strict';
import {planSpeechSegments,prepareRecognitionAudio} from './asr-audio-quality.mjs';
const rate=16000;
const voice=seconds=>Float32Array.from({length:rate*seconds},(_,i)=>.15*Math.sin(i/8));
test('short utterances stay whole and long segments preserve every sample exactly once',()=>{assert.deepEqual(planSpeechSegments(voice(13)),[{start:0,end:13*rate}]);const samples=voice(65),spans=planSpeechSegments(samples);assert.equal(spans[0].start,0);assert.equal(spans.at(-1).end,samples.length);for(let i=0;i<spans.length;i++){assert.ok(spans[i].end-spans[i].start<=20*rate);if(i)assert.equal(spans[i].start,spans[i-1].end);}});
test('a natural pause near the target is preferred to a fixed boundary',()=>{const samples=voice(45);samples.fill(0,15*rate,16*rate);const [first]=planSpeechSegments(samples);assert.ok(first.end>=15*rate&&first.end<=16*rate);});
test('quiet speech is boosted within peak headroom without modifying the source',()=>{const samples=Float32Array.from(voice(2),x=>x*.03),copy=samples.slice();const {samples:prepared,quality}=prepareRecognitionAudio(samples);assert.ok(quality.gain>1&&quality.gain<=4);assert.match(quality.warnings.join(''),/音量偏低/);assert.deepEqual(samples,copy);assert.ok(Math.max(...prepared)<1);});
test('clipping is reported and no silent input is amplified into speech',()=>{const silent=new Float32Array(rate);assert.equal(prepareRecognitionAudio(silent).quality.gain,1);assert.ok(prepareRecognitionAudio(new Float32Array(rate).fill(1)).quality.warnings.some(x=>x.includes('削波')));});
