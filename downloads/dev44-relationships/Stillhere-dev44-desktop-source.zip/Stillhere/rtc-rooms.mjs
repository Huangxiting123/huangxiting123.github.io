import {randomBytes,randomUUID} from 'node:crypto';
export function createRtcRooms({now=()=>Date.now(),limit=50,ttl=15*60*1000,heartbeat=15000}={}){
 const rooms=new Map();
 const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
 function close(r,reason='通话已结束'){r.status='ended';r.reason=reason;r.offer=r.answer=null;}
 function prune(){for(const [id,r] of rooms)if(r.expiresAt<=now())rooms.delete(id);}
 function find(id,principal){prune();const r=rooms.get(id);if(!r)fail(404,'通话不存在或已过期');const side=r.host.principal===principal?'host':r.guest?.principal===principal?'guest':null;if(!side)fail(403,'不能访问其他人的通话');return {r,side};}
 function validate(r,verify){if(r.status==='ended')return;try{verify(r.host);if(r.guest)verify(r.guest);}catch{close(r,'交流身份已暂停或访问权限已变化');return;}
  if(r.guest&&(now()-r.host.seen>heartbeat||now()-r.guest.seen>heartbeat))close(r,'对端连接已中断，请重新发起通话');
 }
 function view(r,side){return {id:r.id,side,status:r.status,reason:r.reason||'',expiresAt:r.expiresAt,peerName:side==='host'?r.target.name:'档案所有者',peerRelation:side==='host'?r.target.relation:'本人',peerIdentity:r.status==='ended'?'unavailable':side==='host'&&!r.guest?'awaiting':'account_confirmed',offer:side==='guest'?r.offer:undefined,answer:side==='host'?r.answer:undefined};}
 return {
  create(host,target){prune();for(const r of rooms.values())if(r.host.principal===host.principal&&r.status!=='ended')close(r,'已创建另一通话');for(const [id,r] of rooms)if(r.status==='ended')rooms.delete(id);if(rooms.size>=limit)fail(429,'通话数量已满');const r={id:randomUUID(),code:randomBytes(16).toString('hex'),host:{...host,seen:now()},guest:null,target:{id:target.id,name:target.name,relation:target.relation},status:'waiting',offer:null,answer:null,expiresAt:now()+ttl};rooms.set(r.id,r);return {...view(r,'host'),joinCode:r.code};},
  join(code,guest,verify){verify(guest);prune();const r=[...rooms.values()].find(r=>r.code===code&&r.status!=='ended');if(!r||r.target.id!==guest.contactId)fail(404,'配对码无效，或当前账号不是受邀联系人');validate(r,verify);if(r.status==='ended')fail(403,r.reason);if(r.guest)fail(409,'该通话已有接听端');r.guest={...guest,seen:now()};r.status='joining';return view(r,'guest');},
  read(id,principal,verify){const {r,side}=find(id,principal);validate(r,verify);if(r.status!=='ended')r[side].seen=now();return view(r,side);},
  signal(id,principal,data,verify){const {r,side}=find(id,principal);validate(r,verify);if(r.status==='ended')fail(409,r.reason);const expected=side==='host'?'offer':'answer';if(data.type!==expected||typeof data.sdp!=='string'||data.sdp.length>60000||!data.sdp.startsWith('v=0'))fail(400,'通话信令无效');if(r[expected]||expected==='answer'&&!r.offer)fail(409,'通话协商状态已变化');r[expected]={type:expected,sdp:data.sdp};r[side].seen=now();if(expected==='answer')r.status='negotiated';return {ok:true};},
  end(id,principal){const {r}=find(id,principal);close(r);return {ended:true};},
  closeAll(reason='实时连接配置已变化，请重新配对'){for(const r of rooms.values())close(r,reason);},
  closeSession(sessionId){for(const r of rooms.values())if(r.host.sessionId===sessionId||r.guest?.sessionId===sessionId)close(r,'交流身份已暂停');}
 };
}
