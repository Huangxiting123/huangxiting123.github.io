import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {turnUrl,createRtcRelay} from './rtc-relay.mjs';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const config={urls:['turns:relay.example.test:443?transport=tcp'],sharedSecret:'fake-turn-secret-for-tests',policy:'relay'};
test('TURN URLs accept explicit TCP/TLS endpoints and reject embedded credentials or malformed hosts',()=>{
 for(const url of ['turn:127.0.0.1:3478?transport=tcp','turns:relay.example.test:443?transport=tcp','turn:[::1]:3478?transport=udp'])assert.equal(turnUrl(url),url);
 for(const url of ['https://relay.test','turn:user:pass@relay.test','turn:relay.test/path','turn:relay.test?secret=oops','turn:relay..test','turn:999.999.0.1','turn:[bad::ip]','turn:relay.test:0','turn:relay.test:65536','turns:relay.test?transport=udp','turn:relay.test\n','turn:*.test'])assert.throws(()=>turnUrl(url),e=>e.status===400);
});
test('default direct mode has no credentials and relay-only mode cannot silently run without configuration',()=>{
 assert.deepEqual(createRtcRelay().issue('room','caller'),{iceServers:[],iceTransportPolicy:'all'});assert.throws(()=>createRtcRelay({env:{PERSONA_RTC_POLICY:'relay'}}));assert.throws(()=>createRtcRelay({env:{PERSONA_RTC_POLICY:'invalid'}}));
 const r=createRtcRelay({env:{PERSONA_TURN_URLS:config.urls.join(','),PERSONA_TURN_SECRET:config.sharedSecret}});assert.equal(r.status().policy,'relay');assert.equal(r.status(true).urls,undefined);
});
test('TURN REST issues bounded HMAC credentials scoped by room and authenticated principal',()=>{
 const r=createRtcRelay({now:()=>1000000});r.apply(config);const a=r.issue('room-a','principal-a');const server=a.iceServers[0];assert.equal(a.expiresAt,1900);assert.ok(server.username.startsWith('1900:'));assert.equal(server.credential,createHmac('sha1',config.sharedSecret).update(server.username).digest('base64'));assert.equal(a.iceTransportPolicy,'relay');assert.notEqual(server.username,r.issue('room-b','principal-a').iceServers[0].username);assert.notEqual(server.username,r.issue('room-a','principal-b').iceServers[0].username);assert.doesNotMatch(JSON.stringify(a),/fake-turn-secret|principal-a|room-a/);
});
test('invalid updates preserve existing configuration and secrets never enter status output',()=>{
 const r=createRtcRelay();r.apply(config);for(const bad of [{...config,sharedSecret:'short'},{...config,sharedSecret:' padded-secret-value '},{...config,policy:'bad'},{...config,urls:[]},{...config,urls:Array(5).fill('turn:relay.test')}])assert.throws(()=>r.apply(bad));assert.equal(r.status().configured,true);assert.doesNotMatch(JSON.stringify(r.status()),/fake-turn-secret/);const s=r.status();s.urls.length=0;assert.equal(r.status().urls.length,1);const ice=r.issue('a','b');ice.iceServers[0].urls.length=0;assert.equal(r.issue('a','b').iceServers[0].urls.length,1);r.clear();assert.equal(r.status().configured,false);
});
test('temporary credentials expire on epoch time and renew without exposing the shared secret',()=>{
 let time=0;const r=createRtcRelay({now:()=>time});r.apply(config);const a=r.issue('a','b');time=1000;const b=r.issue('a','b');assert.equal(b.expiresAt-a.expiresAt,1);assert.notEqual(a.iceServers[0].credential,b.iceServers[0].credential);
});
test('HTTP relay configuration is owner-only; credentials require confirmed room membership and are absent from exports',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'stillhere-relay-'));let child;
 async function api(path,{token='owner-relay-test',method='GET',data,status=200,sessionId}={}){const r=await fetch('http://127.0.0.1:4347/api/'+path,{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json',...(sessionId?{'X-Stillhere-Call-Session':sessionId}:{})},...(data?{body:JSON.stringify(data)}:{})});assert.equal(r.status,status,await r.clone().text());return r.json();}
 try{child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('.',import.meta.url)),env:{...process.env,PORT:'4347',PERSONA_DATA:join(dir,'data.json'),PERSONA_OWNER_TOKEN:'owner-relay-test',PERSONA_TURN_URLS:'',PERSONA_TURN_SECRET:'',PERSONA_RTC_POLICY:'',PERSONA_API_URL:'',PERSONA_API_KEY:'',PERSONA_MODEL:''},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',()=>reject(Error('server exited')));});
 const a=await api('contacts',{method:'POST',data:{name:'女儿',relation:'女儿'},status:201}),b=await api('contacts',{method:'POST',data:{name:'朋友',relation:'朋友'},status:201});
 await api('rtc/relay',{token:a.token,status:403});await api('rtc/relay',{token:a.token,method:'PUT',data:config,status:403});await api('rtc/relay',{token:a.token,method:'DELETE',status:403});await api('rtc/relay',{method:'PUT',data:{...config,sharedSecret:'owner-relay-test'},status:400});await api('rtc/relay',{method:'PUT',data:config});
 const ownerState=await api('state'),contactState=await api('state',{token:a.token});assert.doesNotMatch(JSON.stringify(ownerState),/fake-turn-secret/);assert.equal(contactState.rtcRelay.urls,undefined);assert.equal(contactState.rtcRelay.policy,'relay');assert.doesNotMatch(JSON.stringify(await api('export')),/fake-turn-secret|turns:relay/);
 async function confirm(token){const s=await api('call/sessions',{token,method:'POST',data:{},status:201});await api('call/sessions/'+s.id,{token,method:'PUT',data:{action:'confirm'}});return s.id;}
 const h=await confirm('owner-relay-test'),g=await confirm(a.token),other=await confirm(b.token);const room=await api('rtc/rooms',{method:'POST',data:{contactId:a.id},sessionId:h,status:201});
 await api('rtc/rooms/'+room.id+'/ice',{status:403});await api('rtc/rooms/'+room.id+'/ice',{token:a.token,sessionId:g,status:403});await api('rtc/rooms/'+room.id+'/ice',{token:b.token,sessionId:other,status:403});
 const hi=await api('rtc/rooms/'+room.id+'/ice',{sessionId:h});await api('rtc/join',{token:a.token,method:'POST',data:{code:room.joinCode},sessionId:g});const gi=await api('rtc/rooms/'+room.id+'/ice',{token:a.token,sessionId:g});assert.equal(gi.iceTransportPolicy,'relay');assert.notEqual(hi.iceServers[0].username,gi.iceServers[0].username);assert.doesNotMatch(JSON.stringify(gi),/fake-turn-secret/);
 await api('rtc/relay',{method:'DELETE'});assert.equal((await api('rtc/rooms/'+room.id)).status,'ended');await api('rtc/rooms/'+room.id+'/ice',{sessionId:h,status:409});assert.equal((await api('rtc/relay')).configured,false);
 }finally{if(child?.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;}await rm(dir,{recursive:true,force:true});}
});
test('temporary credential expiry never extends beyond the room lifetime',()=>{
 const r=createRtcRelay({now:()=>1000000});r.apply(config);assert.equal(r.issue('a','b',1050000).expiresAt,1050);assert.throws(()=>r.issue('a','b',1000000),e=>e.status===409);
});
