import {createFaceEnrollment} from './face-match.mjs';
import {extractFaceDescriptor} from './face-engine.js';
import {createFaceMonitor} from './face-monitor.mjs';
export function createFaceControls({panel,getSession,isConfirmed,onMismatch,onChange=()=>{}}){
 const root=document.createElement('section');root.innerHTML='<h3>本次会话人脸核对 · 试验功能</h3><p class="muted">在本机浏览器提取人脸特征，仅与当前账号本次录入的样本比较。照片与特征不上传、不写入磁盘，退出或撤回时清除。不能用于防照片冒用，也不能自动识别所有家人；声纹尚未接入。</p><label><input data-face-consent type="checkbox" style="width:auto"> 我确认仅本人入镜，同意本次会话采集并比较本人的人脸特征</label><button type="button" data-face-enroll>拍摄并录入本人样本</button> <button type="button" data-face-verify>核对镜头前的人</button> <button type="button" data-face-clear class="secondary">删除样本并撤回</button><p data-face-status role="status" aria-live="polite">尚未录入样本；仍需手动确认交流身份。</p><label><input data-face-monitor type="checkbox" style="width:auto"> 开启通话中的定时人脸核对（需先录入样本）</label><p class="muted">开启后立即核对，随后每次核对完成约5秒再拍摄一帧。出现多人、未检测到脸、样本不匹配或核对超时，会暂停交流并关闭设备。两次检查之间无法保证身份未变化；关闭后回到手动确认模式。</p><p data-face-monitor-status role="status" aria-live="polite">定时核对未开启。</p><canvas data-face-preview hidden style="max-width:320px;width:100%;border-radius:12px" aria-label="最近一次采集画面，仅保留在本页面"></canvas>';panel.querySelector('.video-grid').after(root);
 const q=s=>root.querySelector(s),enrollment=createFaceEnrollment(),canvas=q('canvas');let epoch=0,busy=false,processing=false;
 function eligible(){const s=getSession();return isConfirmed()&&s.phase==='preview'&&s.videoEnabled&&s.stream?.getVideoTracks().some(t=>t.readyState==='live');}
 function permitted(){return eligible()&&q('[data-face-consent]').checked;}
 const monitor=createFaceMonitor({check:()=>inspect(false,true),onChange:s=>{
  q('[data-face-monitor]').checked=s.active;
  q('[data-face-monitor-status]').textContent=s.status==='alert'?'定时核对已暂停：'+s.reason:s.active?(s.checking?'正在本机核对镜头画面…':'本次核对通过 · 已完成 '+s.checks+' 次；约5秒后再次核对。'):'定时核对未开启。';sync();
 },onAlert:reason=>{onMismatch();q('[data-face-monitor-status]').textContent='定时核对发现异常，已暂停交流：'+reason;}});
 function sync(){const auto=monitor.snapshot().active;q('[data-face-enroll]').disabled=busy||processing||auto||!permitted()||enrollment.count()>=3;q('[data-face-verify]').disabled=busy||processing||auto||!permitted()||!enrollment.count();q('[data-face-monitor]').disabled=!auto&&(busy||processing||!permitted()||!enrollment.count());q('[data-face-clear]').disabled=false;onChange();}
 function reset(){epoch++;busy=false;monitor.stop();enrollment.clear();q('[data-face-consent]').checked=false;canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);canvas.width=0;canvas.height=0;canvas.hidden=true;q('[data-face-status]').textContent='样本已清除；仍需手动确认交流身份。';sync();}
 async function inspect(enroll,automated=false){
  if(processing)throw Error('上一次核对尚未结束，请稍后重新确认');if(!permitted())throw Error('当前摄像头、身份或人脸采集授权不可用');
  const current=epoch;processing=true;if(!automated){busy=true;q('[data-face-status]').textContent='正在本机加载模型并核对画面…';}sync();
  const frame=document.createElement('canvas');let descriptor=null;
  try{const video=panel.querySelector('video');if(!video.videoWidth||video.readyState<2)throw Error('摄像头尚未就绪，请稍后重试');const scale=Math.min(1,960/video.videoWidth);frame.width=Math.round(video.videoWidth*scale);frame.height=Math.round(video.videoHeight*scale);frame.getContext('2d').drawImage(video,0,0,frame.width,frame.height);canvas.width=frame.width;canvas.height=frame.height;canvas.getContext('2d').drawImage(frame,0,0);canvas.hidden=false;
   descriptor=await extractFaceDescriptor(frame);if(current!==epoch||!permitted())return null;
   if(enroll){const count=enrollment.add(descriptor);q('[data-face-status]').textContent='已录入 '+count+' / 3 份本次会话样本；可稍微转头补充或开始核对。';return {matched:true};}
   return enrollment.verify(descriptor);
  }finally{descriptor?.fill(0);frame.width=0;frame.height=0;processing=false;if(current===epoch)busy=false;sync();}
 }
 async function capture(enroll){if(busy||processing||monitor.snapshot().active||!permitted())return;const current=epoch;
  try{const result=await inspect(enroll);if(!result||current!==epoch||enroll)return;if(result.matched)q('[data-face-status]').textContent='与当前账号本次录入样本较接近。此结果不是身份认证，访问范围仍由登录授权决定。';else{onMismatch();q('[data-face-status]').textContent='未通过样本核对，已暂停交流；请本人重新登录或手动确认后重录。';}}
  catch(e){if(current===epoch){if(!enroll)onMismatch();q('[data-face-status]').textContent=(enroll?'':'核对未完成，已暂停交流。')+e.message;}}
 }
 q('[data-face-enroll]').onclick=()=>capture(true);q('[data-face-verify]').onclick=()=>capture(false);q('[data-face-clear]').onclick=reset;q('[data-face-consent]').onchange=()=>{if(!q('[data-face-consent]').checked)reset();else sync();};
 q('[data-face-monitor]').onchange=()=>{if(q('[data-face-monitor]').checked){if(permitted()&&enrollment.count()&&!processing)monitor.start();else{q('[data-face-monitor]').checked=false;sync();}}else monitor.stop();};
 sync();return {reset,sync,ready:()=>!monitor.snapshot().active||monitor.snapshot().lastCheckedAt!==null,deviceChanged:s=>{if(s.phase!=='preview'||!s.videoEnabled)reset();else sync();}};
}
