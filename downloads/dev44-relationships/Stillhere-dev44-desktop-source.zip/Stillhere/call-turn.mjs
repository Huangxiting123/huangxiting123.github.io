// Turn-based ASR -> review -> authorized chat -> TTS. Cancellation prevents late playback.
export function createCallTurn({request,onChange=()=>{},play,stopPlayback=()=>{}}){
 let epoch=0,controller=null,state={phase:'idle',transcript:'',answer:'',messageId:null,error:'',inputMode:null};
 const emit=patch=>{state={...state,...patch};onChange({...state});};
 function cancel(){epoch++;controller?.abort();controller=null;stopPlayback();emit({phase:'idle',transcript:'',answer:'',messageId:null,error:'',inputMode:null});}
 async function transcribe(blob){
  cancel();const current=epoch;controller=new AbortController();emit({phase:'transcribing'});
  try{const data=await request('speech/transcribe',blob,controller.signal);if(current!==epoch)return;
   if(data.blocked)throw Error(data.message||'录音触发话题规则');
   if(!data.text?.trim())throw Error('没有识别到文字，请重新录音');
   emit({phase:'review',transcript:data.text,inputMode:'voice'});
  }catch(e){if(current===epoch)emit({phase:'idle',error:e.message});}
 }
 function question(text){if(typeof text!=='string'||!text.trim()||text.trim().length>5000){emit({error:'请输入1到5000字的问题'});return null;}return text.trim();}
 async function reply(text,{speak=true,inputMode='voice'}={}){
  const current=++epoch;controller?.abort();controller=new AbortController();const signal=controller.signal;emit({phase:'thinking',transcript:text,error:'',inputMode});
  try{
   const data=await request('chat',{text},signal);if(current!==epoch)return;
   if(!data.assistant?.id||typeof data.assistant.text!=='string')throw Error('对话服务返回无效回复');
   emit({phase:speak?'synthesizing':'done',answer:data.assistant.text,messageId:data.assistant.id});
   if(speak)await synthesize(current,signal);
  }catch(e){if(current===epoch)emit({phase:'failed',error:e.message});}
 }
 async function submit(text,options){if(state.phase!=='review')return;const value=question(text);if(value===null)return;return reply(value,options);}
 async function ask(text,{speak=false}={}){if(!['idle','done','failed'].includes(state.phase))return;const value=question(text);if(value===null)return;cancel();return reply(value,{speak,inputMode:'text'});}
 async function synthesize(current,signal){
  const audio=await request('speech/synthesize',{messageId:state.messageId},signal);if(current!==epoch)return;
  emit({phase:'speaking'});await play(audio);if(current!==epoch)return;emit({phase:'done'});
 }
 async function retrySpeech(){
  if(!state.messageId||!['failed','done'].includes(state.phase))return;
  const current=++epoch;controller?.abort();stopPlayback();controller=new AbortController();const signal=controller.signal;emit({phase:'synthesizing',error:''});
  try{await synthesize(current,signal);}catch(e){if(current===epoch)emit({phase:'failed',error:e.message});}
 }
 return {transcribe,submit,ask,retrySpeech,cancel,snapshot:()=>({...state})};
}
