import {randomUUID,createHash} from 'node:crypto';
export const callPrincipal=token=>createHash('sha256').update(token).digest('hex');
export function createCallSessions({now=()=>Date.now(),ttl=30*60*1000,limit=200}={}){
 const sessions=new Map();
 function fail(status,message){throw Object.assign(Error(message),{status});}
 function prune(){for(const [id,s] of sessions)if(s.expiresAt<=now())sessions.delete(id);}
 function get(id,principal){prune();const s=sessions.get(id);if(!s||s.principal!==principal)fail(403,'通话身份会话无效或已过期，请重新确认身份');return s;}
 function view(s){return {id:s.id,status:s.status,expiresAt:s.expiresAt};}
 return {
  create(principal){prune();for(const [id,s] of sessions)if(s.principal===principal)sessions.delete(id);if(sessions.size>=limit)fail(429,'通话身份会话过多，请稍后重试');const s={id:randomUUID(),principal,status:'pending',expiresAt:now()+ttl};sessions.set(s.id,s);return view(s);},
  update(id,principal,action){const s=get(id,principal);if(!['confirm','pause'].includes(action))fail(400,'身份操作无效');s.status=action==='confirm'?'confirmed':'pending';return view(s);},
  check(id,principal){const s=get(id,principal);if(s.status!=='confirmed')fail(403,'请先确认当前由登录账号本人交流');return view(s);},
  remove(id,principal){get(id,principal);sessions.delete(id);}
 };
}
