import test from 'node:test';
import assert from 'node:assert/strict';
import {createRtcRooms} from './rtc-rooms.mjs';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const host={principal:'owner',sessionId:'hs',contactId:null},guest={principal:'daughter',sessionId:'gs',contactId:'daughter-id'},target={id:'daughter-id',name:'女儿',relation:'孩子'},verify=()=>{};
test('rooms pair only the targeted contact and isolate negotiation descriptions',()=>{
 const s=createRtcRooms(),r=s.create(host,target);assert.match(r.joinCode,/^[0-9a-f]{32}$/);assert.throws(()=>s.join(r.joinCode,{...guest,contactId:'other'},verify));assert.throws(()=>s.read(r.id,'other',verify),e=>e.status===403);
 s.signal(r.id,'owner',{type:'offer',sdp:'v=0\r\ntest-offer'},verify);s.join(r.joinCode,guest,verify);assert.throws(()=>s.join(r.joinCode,guest,verify),e=>e.status===409);
 const g=s.read(r.id,'daughter',verify);assert.match(g.offer.sdp,/offer/);assert.equal(g.joinCode,undefined);assert.equal(g.answer,undefined);assert.equal(g.principal,undefined);
 s.signal(r.id,'daughter',{type:'answer',sdp:'v=0\r\ntest-answer'},verify);const h=s.read(r.id,'owner',verify);assert.equal(h.status,'negotiated');assert.match(h.answer.sdp,/answer/);assert.equal(h.offer,undefined);
});
test('description roles, duplicate negotiations, and malformed SDP are rejected',()=>{
 const s=createRtcRooms(),r=s.create(host,target);s.join(r.joinCode,guest,verify);assert.throws(()=>s.signal(r.id,'daughter',{type:'answer',sdp:'v=0'},verify));assert.throws(()=>s.signal(r.id,'owner',{type:'answer',sdp:'v=0'},verify));assert.throws(()=>s.signal(r.id,'owner',{type:'offer',sdp:'invalid'},verify));s.signal(r.id,'owner',{type:'offer',sdp:'v=0'},verify);assert.throws(()=>s.signal(r.id,'owner',{type:'offer',sdp:'v=0'},verify));
});
test('identity revocation ends both sides and clears SDP',()=>{
 const s=createRtcRooms(),r=s.create(host,target);s.signal(r.id,'owner',{type:'offer',sdp:'v=0\r\nPRIVATE-SDP'},verify);s.join(r.joinCode,guest,verify);const result=s.read(r.id,'daughter',()=>{throw Error('revoked');});assert.equal(result.status,'ended');assert.equal(result.offer,null);assert.doesNotMatch(JSON.stringify(result),/PRIVATE-SDP/);assert.equal(s.read(r.id,'owner',verify).status,'ended');
});
test('session removal and hangup clear the room and prevent rejoining',()=>{
 const s=createRtcRooms(),r=s.create(host,target);s.join(r.joinCode,guest,verify);s.closeSession('gs');assert.equal(s.read(r.id,'owner',verify).status,'ended');assert.throws(()=>s.join(r.joinCode,guest,verify));const r2=s.create(host,target);s.end(r2.id,'owner');assert.equal(s.read(r2.id,'owner',verify).status,'ended');
});
test('heartbeat interruption and expiration cannot retain usable signaling',()=>{
 let time=0;const s=createRtcRooms({now:()=>time,ttl:60000}),r=s.create(host,target);s.join(r.joinCode,guest,verify);time=16000;assert.equal(s.read(r.id,'owner',verify).status,'ended');time=60000;assert.throws(()=>s.read(r.id,'owner',verify),e=>e.status===404);
});
test('new host pairing retires old calls and capacity is bounded',()=>{
 const s=createRtcRooms({limit:1}),r=s.create(host,target);const second=s.create(host,target);assert.throws(()=>s.read(r.id,'owner',verify));assert.equal(s.read(second.id,'owner',verify).status,'waiting');assert.throws(()=>s.create({...host,principal:'another'},target),e=>e.status===429);
});
test('HTTP signaling requires confirmed credentials, designated contact, and valid membership',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'stillhere-rtc-'));let child;
 async function api(path,{token='rtc-owner',method='GET',data,status=200,sessionId}={}){const r=await fetch('http://127.0.0.1:4345/api/'+path,{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json',...(sessionId?{'X-Stillhere-Call-Session':sessionId}:{})},...(data?{body:JSON.stringify(data)}:{})});assert.equal(r.status,status,await r.clone().text());return r.json();}
 try{child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('.',import.meta.url)),env:{...process.env,PORT:'4345',PERSONA_DATA:join(dir,'state.json'),PERSONA_OWNER_TOKEN:'rtc-owner',PERSONA_API_URL:'',PERSONA_API_KEY:'',PERSONA_MODEL:''},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',()=>reject(Error('server exited')));});
 const asset=await fetch('http://127.0.0.1:4345/rtc-peer-identity.mjs');assert.equal(asset.status,200);assert.match(asset.headers.get('content-type'),/javascript/);assert.match(await asset.text(),/describePeerIdentity/);
 const a=await api('contacts',{method:'POST',data:{name:'女儿',relation:'女儿'},status:201}),b=await api('contacts',{method:'POST',data:{name:'朋友',relation:'朋友'},status:201});
 async function confirm(token){const s=await api('call/sessions',{token,method:'POST',data:{},status:201});await api('call/sessions/'+s.id,{token,method:'PUT',data:{action:'confirm'}});return s.id;}
 await api('rtc/rooms',{method:'POST',data:{contactId:a.id},status:403});const h=await confirm('rtc-owner'),g=await confirm(a.token),other=await confirm(b.token);
 const room=await api('rtc/rooms',{method:'POST',data:{contactId:a.id},sessionId:h,status:201});await api('rtc/rooms',{token:a.token,method:'POST',data:{contactId:b.id},sessionId:g,status:403});
 await api('rtc/join',{token:b.token,method:'POST',data:{code:room.joinCode},sessionId:other,status:404});await api('rtc/rooms/'+room.id,{token:b.token,status:403});
 await api('rtc/rooms/'+room.id,{method:'POST',data:{type:'offer',sdp:'v=0\r\nowner-offer'}});await api('rtc/join',{token:a.token,method:'POST',data:{code:room.joinCode},sessionId:g});
 assert.equal((await api('rtc/rooms/'+room.id,{token:a.token})).offer.type,'offer');await api('call/sessions/'+g,{token:a.token,method:'DELETE'});const ended=await api('rtc/rooms/'+room.id);assert.equal(ended.status,'ended');assert.equal(ended.answer,null);
 }finally{if(child?.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;}await rm(dir,{recursive:true,force:true});}
});
test('joining checks the incoming guest before returning any stored offer',()=>{
 const s=createRtcRooms(),r=s.create(host,target);s.signal(r.id,'owner',{type:'offer',sdp:'v=0\r\nPRIVATE-OFFER'},verify);assert.throws(()=>s.join(r.joinCode,guest,member=>{if(member.principal===guest.principal)throw Object.assign(Error('expired guest'),{status:403});}),e=>e.status===403);assert.equal(s.read(r.id,'owner',verify).status,'waiting');
});

test('peer identity distinguishes invitation, confirmed account and ended sessions',()=>{
 const s=createRtcRooms(),r=s.create(host,target);
 assert.equal(r.peerIdentity,'awaiting');
 assert.equal(s.read(r.id,'owner',verify).peerIdentity,'awaiting');
 const joined=s.join(r.joinCode,guest,verify);
 assert.equal(joined.peerIdentity,'account_confirmed');
 assert.equal(joined.peerName,'档案所有者');
 const active=s.read(r.id,'owner',verify);
 assert.equal(active.peerIdentity,'account_confirmed');
 assert.equal(active.peerName,target.name);assert.equal(active.peerRelation,target.relation);
 s.closeSession(guest.sessionId);
 assert.equal(s.read(r.id,'owner',verify).peerIdentity,'unavailable');
 assert.equal(s.read(r.id,guest.principal,verify).peerIdentity,'unavailable');
});
test('failed identity verification never reports a confirmed peer',()=>{
 const s=createRtcRooms(),r=s.create(host,target);s.join(r.joinCode,guest,verify);
 const state=s.read(r.id,'owner',()=>{throw Error('identity expired');});
 assert.equal(state.status,'ended');assert.equal(state.peerIdentity,'unavailable');
});
