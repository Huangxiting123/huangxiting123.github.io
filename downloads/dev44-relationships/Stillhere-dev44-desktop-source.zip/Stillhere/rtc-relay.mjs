import {createHmac,createHash} from 'node:crypto';
import {isIP} from 'node:net';
export function turnUrl(value){
 if(typeof value!=='string'||value.length>512||/[\s\x00-\x1f]/.test(value))throw Object.assign(Error('TURN地址格式无效'),{status:400});
 const match=value.match(/^(turns?):(\[[a-f0-9:]+\]|[a-z0-9.-]+)(?::([0-9]{1,5}))?(?:\?transport=(tcp|udp))?$/i);
 if(!match)throw Object.assign(Error('请输入turn:或turns:地址；不能嵌入账号、密码、路径或额外查询参数'),{status:400});
 const [,scheme,host,port,transport]=match;const name=host.startsWith('[')?host.slice(1,-1):host;
 if(host.startsWith('[')?isIP(name)!==6:!isIP(name)&&(!name.split('.').every(s=>s.length<=63&&/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i.test(s))||/^[0-9.]+$/.test(name)))throw Object.assign(Error('TURN主机名或IP无效'),{status:400});
 if(port&&(Number(port)<1||Number(port)>65535)||scheme.toLowerCase()==='turns'&&transport?.toLowerCase()==='udp')throw Object.assign(Error('TURN端口无效，或TLS地址错误地指定了UDP'),{status:400});
 return scheme.toLowerCase()+':'+host.toLowerCase()+(port?':'+Number(port):'')+(transport?'?transport='+transport.toLowerCase():'');
}
export function createRtcRelay({env={},now=()=>Date.now(),ttlSeconds=900}={}){
 if(env.PERSONA_RTC_POLICY&&!['all','relay'].includes(env.PERSONA_RTC_POLICY))throw Error('PERSONA_RTC_POLICY必须为all或relay');
 let config=null;
 function status(publicView=false){return {configured:!!config,policy:config?.policy||'all',...(publicView?{}:{urls:[...(config?.urls||[])],ttlSeconds,credentialMode:'turn-rest-hmac-sha1'})};}
 function apply(input){
  if(!Array.isArray(input.urls)||input.urls.length<1||input.urls.length>4)throw Object.assign(Error('请提供1至4个TURN地址'),{status:400});
  const urls=[...new Set(input.urls.map(turnUrl))];if(!['all','relay'].includes(input.policy))throw Object.assign(Error('连接策略必须为all或relay'),{status:400});
  const secret=input.sharedSecret;if(typeof secret!=='string'||secret.length<16||secret.length>512||secret!==secret.trim()||/[\x00-\x1f]/.test(secret))throw Object.assign(Error('TURN共享密钥须为16至512字符，且不能含控制字符或首尾空白'),{status:400});
  config={urls,policy:input.policy,secret};return status();
 }
 function clear(){config=null;return status();}
 function issue(roomId,principal,roomExpiresAt=Infinity){if(!config)return {iceServers:[],iceTransportPolicy:'all'};const current=Math.floor(now()/1000);const expiresAt=Math.min(current+ttlSeconds,Math.floor(roomExpiresAt/1000));if(expiresAt<=current)throw Object.assign(Error('配对即将过期，请重新创建'),{status:409});const username=expiresAt+':'+createHash('sha256').update(roomId+'|'+principal).digest('hex').slice(0,24);const credential=createHmac('sha1',config.secret).update(username).digest('base64');return {iceServers:[{urls:[...config.urls],username,credential,credentialType:'password'}],iceTransportPolicy:config.policy,expiresAt};}
 if(env.PERSONA_TURN_URLS||env.PERSONA_TURN_SECRET){apply({urls:(env.PERSONA_TURN_URLS||'').split(/[\r\n,]+/).map(s=>s.trim()).filter(Boolean),sharedSecret:env.PERSONA_TURN_SECRET,policy:env.PERSONA_RTC_POLICY||'relay'});}else if(env.PERSONA_RTC_POLICY==='relay')throw Error('仅中继模式需要配置TURN地址与共享密钥');
 return {status,apply,clear,issue};
}
