@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
  echo Patch only. Extract these files into your current application folder containing runtime\node.exe.
  pause
  exit /b 1
)
set "STILLHERE_MODELS_HOME=E:\Stillhere-Models"
"%~dp0runtime\node.exe" "%~dp0local-models\setup.mjs"
pause
