import {localReadiness} from './local-readiness.mjs';
export function createLocalReadiness({panel,getSession,isConfirmed}){
 const root=document.createElement('section'),heading=document.createElement('h3'),note=document.createElement('p'),list=document.createElement('ul');
 root.dataset.localReadiness='';heading.textContent='本机体验检查';note.className='muted';note.textContent='此检查不会开启设备或发送语音。服务已配置不代表已验证可用；请按提示逐项试用。';root.append(heading,note,list);panel.querySelector('.video-grid').before(root);let state={};
 const labels={ready:'已就绪',action:'待操作',configured:'已配置·待验证',available:'接口可用·待验证',unavailable:'暂不可用',pending:'待开发'};
 function sync(){list.replaceChildren();for(const item of localReadiness({state,confirmed:isConfirmed(),devicePhase:getSession().phase,secure:window.isSecureContext,media:!!navigator.mediaDevices?.getUserMedia,recorder:typeof MediaRecorder==='function',rtc:typeof RTCPeerConnection==='function'})){const li=document.createElement('li');li.textContent=item.label+'【'+labels[item.status]+'】：'+item.detail;list.append(li);}}
 return {sync,render(value){state=value;sync();},reset(){state={};list.replaceChildren();}};
}
