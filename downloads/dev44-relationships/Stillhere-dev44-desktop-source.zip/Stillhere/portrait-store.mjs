import {mkdir,readFile,writeFile,rename,unlink} from 'node:fs/promises';
import {dirname} from 'node:path';
import {randomUUID} from 'node:crypto';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function validatePortrait(input){
 if(input?.authorized!==true)fail(400,'请确认这是本人形象并授权本机保存');
 const value=input.pngBase64;if(typeof value!=='string'||value.length>2800000||value.length%4!==0||!/^[A-Za-z0-9+/]*={0,2}$/.test(value))fail(400,'形象图片格式或大小无效');
 const bytes=Buffer.from(value,'base64');if(bytes.length<45||bytes.length>2*1024*1024||bytes.subarray(0,8).toString('hex')!=='89504e470d0a1a0a'||bytes.readUInt32BE(8)!==13||bytes.subarray(12,16).toString()!=='IHDR')fail(400,'只接收规范化PNG图片');
 const width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20);if(width<1||height<1||width>1024||height>1024)fail(400,'图片尺寸不能超过1024像素');
 return {id:randomUUID(),pngBase64:value,width,height,createdAt:new Date().toISOString(),authorization:'self_portrait_local_preview'};
}
export function createPortraitStore(path){let queue=Promise.resolve();const run=fn=>{const p=queue.then(fn);queue=p.catch(()=>{});return p;};return {
 read:()=>run(async()=>{try{return JSON.parse(await readFile(path,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}}),
 save:input=>run(async()=>{const row=validatePortrait(input);await mkdir(dirname(path),{recursive:true,mode:0o700});await writeFile(path+'.tmp',JSON.stringify(row),{mode:0o600});await rename(path+'.tmp',path);return row;}),
 remove:()=>run(async()=>{await unlink(path).catch(e=>{if(e.code!=='ENOENT')throw e;});return {removed:true};})
};}
