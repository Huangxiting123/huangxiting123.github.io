import {randomUUID} from 'node:crypto';
import {segmentSource} from './segments.mjs';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function reviewSegments(text,mode='source'){if(mode!=='paragraphs')return segmentSource(text);const rows=[];for(const match of text.matchAll(/[^\n]+/g)){const raw=match[0],clean=raw.trim();if(!clean)continue;const start=match.index+raw.indexOf(clean);for(const part of segmentSource(clean))rows.push({...part,index:rows.length,start:start+part.start,end:start+part.end});}return rows;}
export function reviewView(state,asset,original=''){
 const review=state.assetReviews?.[asset.id]||{assetId:asset.id,text:original,version:0,status:'draft'};
 return {...review,segments:segmentSource(review.text),voiceSegments:reviewSegments(review.text,'paragraphs'),title:asset.title,kind:asset.kind};
}
export function saveReview(state,asset,{text,version,assistanceId}){
 if(typeof text!=='string'||!text.trim()||text.length>10000)fail(400,'请输入1—10000字的校对原文');
 state.assetReviews??={};const old=state.assetReviews[asset.id];if((old?.version||0)!==version)fail(409,'整理稿已更新，请重新打开');if(old?.status==='published')fail(409,'此素材已入库，请到记忆页面编辑或删除对应记忆');if(assistanceId&&old?.assistance?.id!==assistanceId)fail(409,'模型建议已更新，请重新打开草稿，未覆盖你的修改');
 const review={assetId:asset.id,text:text.trim(),version:version+1,status:'draft',...(old?.assistance?{assistance:old.assistance}:{}),...((assistanceId||old?.appliedAssistanceIds)?{appliedAssistanceIds:[...new Set([...(old?.appliedAssistanceIds||[]),...(assistanceId?[assistanceId]:[])])].slice(-10)}:{}),...(old?.transcription?{transcription:{...old.transcription,edited:true},transcriptionHistory:old.transcriptionHistory||[]}:{}),updatedAt:new Date().toISOString()};state.assetReviews[asset.id]=review;return reviewView(state,asset);
}
export function publishReview(state,asset,{version,indices,visibility='private',contactIds=[],acknowledged,segmentation='source'}){
 const review=state.assetReviews?.[asset.id];if(!review||review.version!==version)fail(409,'请先保存校对原文，或重新打开最新版本');
 if(acknowledged!==true)fail(400,'请先确认内容真实、可使用且分享范围正确');
 if(!['source','paragraphs'].includes(segmentation))fail(400,'请选择有效的分段方式');const segments=reviewSegments(review.text,segmentation);if(!Array.isArray(indices)||!indices.length||new Set(indices).size!==indices.length||indices.some(i=>!Number.isInteger(i)||i<0||i>=segments.length))fail(400,'请选择有效片段');
 if(!['private','shared'].includes(visibility)||!Array.isArray(contactIds)||contactIds.some(id=>!state.contacts.some(c=>c.id===id))||visibility==='shared'&&!contactIds.length||visibility==='private'&&contactIds.length)fail(400,'请选择正确的访问范围与联系人');
 const normalized=[...indices].sort((a,b)=>a-b),ids=[...new Set(contactIds)].sort();const fingerprint=JSON.stringify({indices:normalized,visibility,contactIds:ids,...(segmentation==='paragraphs'?{segmentation}: {})});
 if(review.status==='published'){if(review.selection!==fingerprint)fail(409,'此素材已按其他范围入库，不能重复发布');return reviewView(state,asset);}
 const now=new Date().toISOString(),sourceId=randomUUID();state.sources.push({id:sourceId,assetId:asset.id,title:asset.title,text:review.text,speaker:'self',createdAt:now,status:'extracted',origin:'asset_manual_review'});
 const memories=normalized.map(i=>{const part=segments[i];return {id:randomUUID(),assetId:asset.id,sourceId,source:'本人校对素材：'+asset.title,text:part.text,type:'fact',date:'',factKey:'',status:'confirmed',visibility,contactIds:ids,relatedContactIds:[],createdAt:now,version:1,evidenceQuote:part.text,evidenceStart:part.start,evidenceEnd:part.end};});state.memories.push(...memories);
 Object.assign(review,{status:'published',publishedAt:now,selection:fingerprint,memoryIds:memories.map(m=>m.id),sourceId});state.messages=[];state.contextRevision++;return reviewView(state,asset);
}
export function removeAssetReview(state,id){if(state.voiceEnrollment?.assetId===id)delete state.voiceEnrollment;const sourceIds=new Set(state.sources.filter(x=>x.assetId===id).map(x=>x.id));state.sources=state.sources.filter(x=>x.assetId!==id);state.memories=state.memories.filter(m=>m.assetId!==id&&!sourceIds.has(m.sourceId));if(state.assetReviews)delete state.assetReviews[id];state.messages=[];state.contextRevision++;}
