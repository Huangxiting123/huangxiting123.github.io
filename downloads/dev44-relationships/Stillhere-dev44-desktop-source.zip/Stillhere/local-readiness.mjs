// Capability checks never request a device, call a provider, or prove service health.
export function localReadiness({state={},confirmed=false,devicePhase='idle',secure=false,media=false,recorder=false,rtc=false}={}){
 const owner=state.role==='owner';
 return [
  {id:'identity',label:'交流身份',status:confirmed?'ready':'action',detail:confirmed?'已确认当前账号本人交流。':'请先点击“确认由当前账号本人交流”。'},
  {id:'text',label:'文字问答',status:confirmed?'ready':'action',detail:confirmed?(state.mode==='demo'?'可输入问题；当前为检索演示，未验证真实模型。':'可输入问题；回答效果仍需实际提问验证。'):'确认身份后可直接输入问题，无需设备或语音服务。'},
  {id:'devices',label:'摄像头与麦克风',status:devicePhase==='preview'?'ready':secure&&media?'action':'unavailable',detail:devicePhase==='preview'?'本次设备已开启，请确认画面、收音与静音操作。':secure&&media?'浏览器提供采集能力；勾选预览授权后点击“开始设备预览”验证。':'需使用可信的本机/HTTPS地址和支持设备采集的浏览器；仍可文字问答。'},
  ...[['asr','录音转写'],['tts','回复朗读']].map(([id,label])=>({id,label,status:state.speech?.[id]?.configured?'configured':'action',detail:state.speech?.[id]?.configured?'已配置，尚需实际请求验证服务、网络和凭证。':owner?'尚未配置，请到“设置”填写对应语音服务；配置后再试用。':'尚未配置，请联系档案所有者设置语音服务。'})),
  {id:'recording',label:'浏览器录音',status:recorder?'available':'unavailable',detail:recorder?'浏览器提供录音接口；实际录制仍需麦克风与单独授权。':'浏览器没有录音接口，请换用新版浏览器，或继续文字问答。'},
  {id:'remote',label:'双端音视频',status:rtc?'available':'unavailable',detail:rtc?'可进行指定联系人双端测试；需要双方设备与授权，跨网络连通仍需实测。':'当前浏览器缺少WebRTC接口，不能建立双端音视频。'},
  {id:'avatar',label:'真人数字分身',status:'pending',detail:'当前只有声音驱动示意头像；真人形象、实时口型与完整数字人通话尚未接入。'}
 ];
}
