import test from 'node:test';
import assert from 'node:assert/strict';
import {deploymentFiles,generateDeployment,COTURN_IMAGE} from './generate.mjs';
import {mkdtemp,writeFile,readFile,stat,rm,access} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
const input={domain:'turn.example.com',publicIp:'8.8.8.8',certFile:'/certs/fullchain.pem',keyFile:'/certs/privkey.pem'};
test('deployment generates pinned image, TLS, TURN REST, restricted resources, and separate private app credentials',()=>{
 const secret='a'.repeat(64),files=deploymentFiles(input,{secret,uid:1000,gid:1000});assert.match(files['compose.yaml'],new RegExp(COTURN_IMAGE));assert.match(files['compose.yaml'],/cap_add: \[NET_BIND_SERVICE\]/);assert.match(files['compose.yaml'],/read_only: true/);assert.match(files['turnserver.conf'],/tls-listening-port=443/);assert.match(files['turnserver.conf'],/use-auth-secret/);assert.match(files['turnserver.conf'],/no-udp\n/);assert.match(files['turnserver.conf'],/denied-peer-ip=127/);assert.ok(files['stillhere.env'].includes(secret));const plan=JSON.parse(files['plan.json']);assert.equal(plan.status,'prepared-not-deployed');assert.equal(plan.publicMediaVerified,false);assert.equal(plan.endpoint,'turns:turn.example.com:443?transport=tcp');assert.ok(!files['plan.json'].includes(secret));assert.ok(!files['compose.yaml'].includes(secret));assert.ok(!files['README.md'].includes(secret));
});
test('deployment rejects config injection, unusable public IPs, relative certificate paths and invalid ranges',()=>{
 for(const bad of [{...input,domain:'bad.test\nuse-auth-secret=false'},{...input,domain:'turn.test/path'},{...input,publicIp:'127.0.0.1'},{...input,publicIp:'192.168.1.2'},{...input,publicIp:'203.0.113.5'},{...input,certFile:'relative.pem'},{...input,keyFile:'/secret/$EXPAND/key.pem'},{...input,relayMin:60000,relayMax:59000}])assert.throws(()=>deploymentFiles(bad));
});
test('NAT deployment explicitly maps public and local server IPs',()=>{
 const files=deploymentFiles({...input,privateIp:'10.1.2.3'});assert.match(files['turnserver.conf'],/external-ip=8.8.8.8\/10.1.2.3/);assert.match(files['turnserver.conf'],/relay-ip=10.1.2.3/);
});
test('CLI generation checks file readability, protects secrets and refuses overwrite',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'coturn-generator-'));try{const cert=join(dir,'cert.pem'),key=join(dir,'key.pem'),out=join(dir,'private-output');await writeFile(cert,'TEST CERT',{mode:0o600});await writeFile(key,'TEST KEY',{mode:0o600});const cfg={...input,certFile:cert,keyFile:key};const result=await generateDeployment(cfg,out);assert.equal(result.status,'prepared-not-deployed');assert.equal((await stat(out)).mode&0o777,0o700);assert.equal((await stat(join(out,'turnserver.conf'))).mode&0o777,0o600);const before=await readFile(join(out,'stillhere.env'),'utf8');assert.match(before,/PERSONA_TURN_SECRET='[a-f0-9]{64}'/);assert.doesNotMatch(JSON.stringify(result),/PERSONA_TURN_SECRET/);await assert.rejects(generateDeployment(cfg,out),e=>e.code==='EEXIST');assert.equal(await readFile(join(out,'stillhere.env'),'utf8'),before);const missing=join(dir,'must-not-exist');await assert.rejects(generateDeployment({...cfg,keyFile:join(dir,'missing')},missing));await assert.rejects(access(missing));}finally{await rm(dir,{recursive:true,force:true});}
});
