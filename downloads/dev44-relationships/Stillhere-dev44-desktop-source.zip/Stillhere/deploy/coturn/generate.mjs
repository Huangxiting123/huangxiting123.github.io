import {randomBytes} from 'node:crypto';
import {isIP} from 'node:net';
import {isAbsolute,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {mkdir,writeFile,access} from 'node:fs/promises';
import {constants} from 'node:fs';
export const COTURN_IMAGE='coturn/coturn@sha256:bbefd3e1fdfdc0d58770fe01b581fd8b00d9f3a5580d00acb77cf719a6bc78e3';
function invalid(message){throw Error(message);}
function publicIPv4(value){if(isIP(value)!==4)return false;const [a,b,c]=value.split('.').map(Number);return !(a===0||a===10||a===127||a>=224||a===169&&b===254||a===172&&b>=16&&b<=31||a===192&&b===168||a===100&&b>=64&&b<=127||a===198&&(b===18||b===19)||a===192&&b===0||a===198&&b===51&&c===100||a===203&&b===0&&c===113);}
export function deploymentFiles(input,{uid=0,gid=0,secret=randomBytes(32).toString('hex')}={}){
 const domain=String(input.domain||'').toLowerCase();if(domain.length>253||isIP(domain)||domain.split('.').length<2||!domain.split('.').every(s=>s.length<=63&&/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(s)))invalid('请提供有效的实际TURN域名');
 if(!publicIPv4(input.publicIp))invalid('请提供实际公网IPv4，不能使用内网或文档示例IP');
 const bindIp=input.privateIp||input.publicIp;if(isIP(bindIp)!==4||bindIp.startsWith('127.')||bindIp==='0.0.0.0')invalid('监听/中继IP无效');
 for(const path of [input.certFile,input.keyFile])if(typeof path!=='string'||!isAbsolute(path)||/[\r\n\x00$]/.test(path))invalid('证书与私钥须使用不含换行或$的绝对路径');
 const min=Number(input.relayMin||49160),max=Number(input.relayMax||49359);if(!Number.isInteger(min)||!Number.isInteger(max)||min<10000||max>65535||max<min||max-min>1000)invalid('中继UDP端口范围须在10000至65535之间，且不超过1001个端口');
 if(!/^[a-f0-9]{64}$/.test(secret)||!Number.isInteger(uid)||!Number.isInteger(gid)||uid<0||gid<0)invalid('部署生成参数无效');
 const endpoint='turns:'+domain+':443?transport=tcp';
 const conf=['# Generated for a dedicated public Linux server.','listening-port=3478','tls-listening-port=443','listening-ip='+bindIp,'relay-ip='+bindIp,'external-ip='+input.publicIp+(input.privateIp?'/'+bindIp:''),'realm='+domain,'server-name='+domain,'fingerprint','use-auth-secret','static-auth-secret='+secret,'cert=/etc/coturn/tls/fullchain.pem','pkey=/etc/coturn/tls/privkey.pem','no-udp','no-dtls','no-tcp-relay','no-cli','no-multicast-peers','denied-peer-ip=0.0.0.0-0.255.255.255','denied-peer-ip=10.0.0.0-10.255.255.255','denied-peer-ip=100.64.0.0-100.127.255.255','denied-peer-ip=127.0.0.0-127.255.255.255','denied-peer-ip=169.254.0.0-169.254.255.255','denied-peer-ip=172.16.0.0-172.31.255.255','denied-peer-ip=192.168.0.0-192.168.255.255','min-port='+min,'max-port='+max,'relay-threads=1','user-quota=4','total-quota=64','pidfile=/tmp/turnserver.pid','userdb=/tmp/turnserver.db','log-file=stdout','simple-log'].join('\n')+'\n';
 const compose=`services:
  coturn:
    image: ${COTURN_IMAGE}
    entrypoint: ["turnserver"]
    command: ["-c", "/etc/coturn/turnserver.conf"]
    network_mode: host
    user: "${uid}:${gid}"
    restart: unless-stopped
    init: true
    read_only: true
    cap_drop: [ALL]
    cap_add: [NET_BIND_SERVICE]
    security_opt: ["no-new-privileges:true"]
    cpus: 1.0
    mem_limit: 256m
    pids_limit: 256
    tmpfs:
      - /tmp:rw,nosuid,size=32m,mode=1777
    volumes:
      - type: bind
        source: ./turnserver.conf
        target: /etc/coturn/turnserver.conf
        read_only: true
      - type: bind
        source: ${JSON.stringify(input.certFile)}
        target: /etc/coturn/tls/fullchain.pem
        read_only: true
      - type: bind
        source: ${JSON.stringify(input.keyFile)}
        target: /etc/coturn/tls/privkey.pem
        read_only: true
`;
 const env="PERSONA_TURN_URLS='"+endpoint+"'\nPERSONA_TURN_SECRET='"+secret+"'\nPERSONA_RTC_POLICY=relay\n";
 const plan={status:'prepared-not-deployed',domain,publicIp:input.publicIp,bindIp,endpoint,image:COTURN_IMAGE,imageVersion:'4.18.0',openPorts:{tcp:[443,3478],udpRelay:[min,max]},certificateVerified:false,publicReachabilityVerified:false,publicMediaVerified:false};
 const readme=`# 续在TURN部署文件\n\n状态：仅生成，尚未部署或公网验收。\n\n目标域名：${domain}\n公网IPv4：${input.publicIp}\n监听/中继IP：${bindIp}\n应用TURN地址：${endpoint}\n\n在专用Linux公网服务器安装Docker Compose，使域名A记录指向公网IPv4，准备与域名匹配且客户端信任的TLS证书。云安全组与主机防火墙需允许TCP 443、3478及UDP ${min}-${max}。该UDP范围是服务端中继端口；浏览器接入仍可使用TCP/TLS。公网IP若由云平台NAT映射，必须确认本配置中的内网IP和端口映射正确。\n\n本Compose使用宿主机网络，适用于这台专用公网Linux服务器，不应在受托管网络策略限制的测试环境中用它规避策略。本机验证另用桥接网络与仅回环端口。生成文件的用户须能读取证书和私钥，容器采用相同UID/GID。\n\n启动前在本目录运行：\n\n\`\`\`sh\ndocker compose -f compose.yaml config --quiet\ndocker compose -f compose.yaml up -d\ndocker compose -f compose.yaml ps\n\`\`\`\n\n用源码提供的deploy/coturn/check.mjs执行TLS及临时凭证分配验收，例如：\n\n\`\`\`sh\nnode --env-file=./stillhere.env /path/to/Stillhere/deploy/coturn/check.mjs\n\`\`\`\n\n探测通过只说明TLS/认证/中继地址分配成功，不代表音视频可通。仍需两台真实设备、各自账号、仅中继策略验证双向音频和视频，并检查getStats中接收字节和解码帧增长及挂断清理。\n\nstillhere.env与turnserver.conf包含相同共享密钥，均以0600写入。不要把本目录当作公开源码或分享包。应用可用stillhere.env启动，或在所有者设置页填写对应地址与共享密钥。\n\n更新TLS证书后，应使用docker compose -f compose.yaml up -d --force-recreate重新挂载文件。回滚或停止可运行docker compose -f compose.yaml down；不要删除配置中的共享密钥，除非准备同步更新应用端配置。\n`;
 return {'compose.yaml':compose,'turnserver.conf':conf,'stillhere.env':env,'plan.json':JSON.stringify(plan,null,2)+'\n','README.md':readme};
}
export async function generateDeployment(input,out){
 const files=deploymentFiles(input,{uid:process.getuid?.()??0,gid:process.getgid?.()??0});await access(input.certFile,constants.R_OK);await access(input.keyFile,constants.R_OK);const target=resolve(out);await mkdir(target,{mode:0o700});for(const [name,text] of Object.entries(files))await writeFile(target+'/'+name,text,{mode:0o600,flag:'wx'});return {directory:target,status:'prepared-not-deployed',files:Object.keys(files)};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args={};try{for(let i=2;i<process.argv.length;i+=2){const key=process.argv[i],value=process.argv[i+1];if(!['--domain','--public-ip','--private-ip','--cert-file','--key-file','--out','--relay-min','--relay-max'].includes(key)||!value)invalid('参数格式无效，请查看deploy/coturn/README.md');args[key]=value;}if(!args['--out'])invalid('请指定尚不存在的--out私有目录');const result=await generateDeployment({domain:args['--domain'],publicIp:args['--public-ip'],privateIp:args['--private-ip'],certFile:args['--cert-file'],keyFile:args['--key-file'],relayMin:args['--relay-min'],relayMax:args['--relay-max']},args['--out']);console.log(JSON.stringify(result,null,2));}catch(e){console.error(e.message);process.exitCode=1;}
}
