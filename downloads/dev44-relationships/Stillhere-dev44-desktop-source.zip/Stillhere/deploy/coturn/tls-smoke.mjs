import {spawnSync,execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import net from 'node:net';
import {randomBytes} from 'node:crypto';
import assert from 'node:assert/strict';
import {COTURN_IMAGE} from './generate.mjs';
import {probeTurn} from '../../turn-probe.mjs';
const dir=await mkdtemp(join(tmpdir(),'stillhere-turn-tls-')),name='stillhere-turn-tls-'+randomBytes(5).toString('hex'),secret=randomBytes(32).toString('hex');
const dockerEnv={...process.env};for(const key of ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'])delete dockerEnv[key];
const docker=args=>execFileSync('docker',['--host=unix:///var/run/docker.sock',...args],{env:dockerEnv,stdio:['ignore','pipe','pipe']});
try{
 const cert=join(dir,'cert.pem'),key=join(dir,'key.pem'),config=join(dir,'turnserver.conf');execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],{stdio:'ignore'});
 await writeFile(config,['listening-port=3478','tls-listening-port=5349','fingerprint','use-auth-secret','static-auth-secret='+secret,'realm=stillhere-tls-test','cert=/etc/coturn/tls/cert.pem','pkey=/etc/coturn/tls/key.pem','no-dtls','no-udp','no-tcp-relay','no-cli','min-port=49160','max-port=49200','relay-threads=1','pidfile=/tmp/turnserver.pid','userdb=/tmp/turnserver.db','log-file=stdout'].join('\n')+'\n',{mode:0o600});
 docker(['run','-d','--name',name,'--read-only','--cap-drop=ALL','--cap-add=NET_BIND_SERVICE','--security-opt=no-new-privileges','--cpus=1','--memory=256m','--pids-limit=256','--user='+process.getuid()+':'+process.getgid(),'--tmpfs','/tmp:rw,nosuid,size=16m','-p','127.0.0.1:5350:5349/tcp','--mount','type=bind,src='+config+',dst=/etc/coturn/turnserver.conf,readonly','--mount','type=bind,src='+cert+',dst=/etc/coturn/tls/cert.pem,readonly','--mount','type=bind,src='+key+',dst=/etc/coturn/tls/key.pem,readonly','--entrypoint','turnserver',COTURN_IMAGE,'-c','/etc/coturn/turnserver.conf']);
 let ready=false;for(let i=0;i<50;i++){ready=await new Promise(resolve=>{const s=net.connect({host:'127.0.0.1',port:5350},()=>{s.destroy();resolve(true);});s.on('error',()=>resolve(false));});if(ready)break;await new Promise(r=>setTimeout(r,100));}assert.equal(ready,true);
 const url='turns:127.0.0.1:5350?transport=tcp';let result;for(let i=0;i<30;i++){try{result=await probeTurn({url,sharedSecret:secret,caFile:cert});break;}catch(e){if(i===29||!['ECONNRESET','ECONNREFUSED'].includes(e.code))throw e;await new Promise(r=>setTimeout(r,100));}}await assert.rejects(probeTurn({url,sharedSecret:secret}),e=>/self.signed|certificate/i.test(e.message));
 assert.equal(result.authenticated,true);assert.equal(result.integrityVerified,true);assert.equal(result.relayAllocated,true);assert.equal(result.certificateVerified,true);console.log(JSON.stringify(result));
 await assert.rejects(probeTurn({url,sharedSecret:'wrong-secret-for-rejection-check',caFile:cert}),/分配失败/);console.log('Real Coturn TLS passed: untrusted certificate rejected; trusted test CA, authenticated allocation and response integrity accepted; incorrect shared secret rejected. No public service deployed.');
}catch(e){try{const log=spawnSync('docker',['--host=unix:///var/run/docker.sock','logs','--tail','20',name],{env:dockerEnv,encoding:'utf8'});console.error((log.stdout+log.stderr).replaceAll(secret,'[redacted]'));}catch{}throw e;}
finally{try{docker(['rm','-f',name]);}catch{}await rm(dir,{recursive:true,force:true});}
