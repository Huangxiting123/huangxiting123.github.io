# 续在自建Coturn部署包

当前已完成部署文件生成与本机真实中继验证，尚未创建公网服务器、购买域名或上线公网服务。

## 首轮试用资源

建议从 Ubuntu 24.04 x64、2核2GB、固定公网IPv4和一个可管理DNS的域名起步。域名下可建立 `turn` 与 `app` 两个子域名，不需要分别购买两个域名。机房应靠近实际使用者；带宽与流量套餐要按并发视频需求选，以上规格不代表并发容量承诺。

四川家庭试用的当前选型和费用参考见RESOURCE-PLAN.md。

服务器与域名需要在用户自己的云账号下购买、续费。当前会话没有这些账号或已授权的公网资源，不能把临时开发环境当作交付的公网服务器。

## 文件与状态

- `generate.mjs`：生成受保护的配置目录、随机共享密钥、Compose和部署计划。不购买资源、不签发域名证书、不自动上线。
- `check.mjs`：通过TCP/TLS校验证书、TURN REST认证、响应完整性与中继分配。探测通过不代表媒体可通。
- `smoke.mjs`：用临时本机Coturn和两个真实浏览器验证中继音视频、静音轨道、身份暂停、挂断及网络故障清理。仅绑定回环端口，不部署公网服务。
- `tls-smoke.mjs`：验证本机真实Coturn TLS、测试CA信任、拒绝不可信证书与错误共享密钥。

固定镜像为Coturn 4.18.0，摘要见generate.mjs。镜像已拉取并在本机验证；未来更新时需重新验收。

## 生成公网服务器配置

先在准备部署的专用Linux服务器上安装Docker Engine/Compose、Node.js 22或更新版本，准备域名A记录及客户端信任的TLS证书。证书和私钥应与实际TURN域名匹配，生成命令的用户必须能读取二者。

将示例中的域名、IP与文件路径替换为实际值：

```sh
sudo node deploy/coturn/generate.mjs \
  --domain turn.your-domain.com \
  --public-ip YOUR_PUBLIC_IPV4 \
  --cert-file /etc/letsencrypt/live/turn.your-domain.com/fullchain.pem \
  --key-file /etc/letsencrypt/live/turn.your-domain.com/privkey.pem \
  --out /opt/stillhere-turn
```

若公网IP由云平台映射到服务器内网网卡，补充 `--private-ip 实际网卡IPv4`。生成器拒绝文档示例IP、相对证书路径与覆盖已有目录；应在拿到真实资源后生成。目录权限0700，文件0600，不在终端打印共享密钥。`plan.json`明确标记“仅准备，未部署”。

此生产Compose采用专用公网Linux主机的宿主网络，以保留TURN中继端口映射；本机托管环境验证使用桥接容器与回环端口，不用宿主网络绕过策略。

## 上线与验收

1. 在云安全组与主机防火墙放行TCP 443、3478和UDP 49160–49359，或生成时选择的范围。TCP/TLS是客户端接入方式；UDP范围是服务器之间/客户端之间的中继端口，不能因此省略。
2. 如果使用HTTP-01申请TLS证书，按证书签发工具要求另行处理TCP 80；也可以使用DNS-01。证书申请与续期不是生成器自动执行的步骤。
3. 在输出目录运行 `docker compose -f compose.yaml config --quiet`，再运行 `docker compose -f compose.yaml up -d`。检查 `docker compose -f compose.yaml ps`，以及文件中写明的监听IP和证书权限。
4. 使用完整源码运行：`node --env-file=/opt/stillhere-turn/stillhere.env deploy/coturn/check.mjs`。默认使用系统CA验证TLS，不关闭证书校验。工具输出不含密钥或临时密码。
5. 在续在所有者设置中填入服务地址与同一共享密钥，或用生成的stillhere.env启动续在，选择“仅中继”。由指定联系人使用自己的账号配对，完成真实双向音视频验收。
6. 依据实际媒体统计确认音频接收字节和视频解码帧持续增长，检查静音听感、挂断、身份暂停、人脸异常、断线及重新配对。物理设备、公网与目标运营商网络都需要实测。

更新证书文件后，按生成目录README重建容器以重新挂载证书。生成目录包含私有共享密钥，不应放进公共源码或聊天附件。

## 信令服务也需要可达

TURN负责媒体中继，双方还须能够通过同一个可信HTTPS地址访问续在应用与信令服务。当前应用可配置HTTPS监听；若与TURN同机，可先把应用配置在8443端口，TURN TLS使用443，分别准备匹配域名的证书与防火墙规则。应用的 `PERSONA_PUBLIC_ORIGIN` 端口必须与其 `PORT` 一致。

若目标网络只允许443，需要为应用和TURN分别准备可用入口，或后续适配经验证的统一TCP入口；不能让两个进程同时占用同一IP的443端口。当前应用没有反向代理来源适配，不能只把URL改成代理地址。

## 可复现的本机验证

常规单元/HTTP测试使用 `npm test`。可选集成验证需要本机Docker套接字、OpenSSL和Chromium；媒体验证还需要Playwright作为外部测试工具，应用运行本身不依赖它。

```sh
node deploy/coturn/tls-smoke.mjs
PLAYWRIGHT_MODULE=/path/to/playwright/index.mjs \
CHROMIUM_PATH=/path/to/chromium \
TURN_SMOKE_SCREENSHOT=/tmp/stillhere-rtc.png \
node deploy/coturn/smoke.mjs
```

验证脚本从固定镜像启动临时Coturn，仅发布回环TCP端口，生成临时密钥与测试数据，结束后清除容器和临时文件。它们不改变浏览器企业网络策略；本次在 `disable_non_proxied_udp` 策略下，通过TURN/TCP获得真实relay候选并收到双向RTP及视频解码帧。TLS验证使用显式信任的临时测试CA，不等同于已部署公众可信证书。
