import {probeTurn} from '../../turn-probe.mjs';
const url=process.env.TURN_CHECK_URL||(process.env.PERSONA_TURN_URLS||'').split(/[\r\n,]+/)[0]?.trim();
if(!url||!process.env.PERSONA_TURN_SECRET){console.error('请设置TURN_CHECK_URL（或PERSONA_TURN_URLS）与PERSONA_TURN_SECRET');process.exitCode=1;}else{try{console.log(JSON.stringify(await probeTurn({url,sharedSecret:process.env.PERSONA_TURN_SECRET,caFile:process.env.TURN_CHECK_CA}),null,2));}catch(e){console.error(e.message);process.exitCode=1;}}
