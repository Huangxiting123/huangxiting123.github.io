import {singleFace} from './face-match.mjs';
let loading;
async function load(){
 if(!loading)loading=(async()=>{const api=await import('/vendor/face-api/face-api.esm.js');await api.tf.setBackend('cpu');await api.tf.ready();await Promise.all([api.nets.tinyFaceDetector.loadFromUri('/vendor/face-api/models'),api.nets.faceLandmark68TinyNet.loadFromUri('/vendor/face-api/models'),api.nets.faceRecognitionNet.loadFromUri('/vendor/face-api/models')]);return api;})().catch(e=>{loading=null;throw Error('本机人脸模型加载失败，请保留手动确认身份。');});return loading;
}
export async function extractFaceDescriptor(canvas){const api=await load();const result=await api.detectAllFaces(canvas,new api.TinyFaceDetectorOptions({inputSize:320,scoreThreshold:0.5})).withFaceLandmarks(true).withFaceDescriptors();return singleFace(result);}
