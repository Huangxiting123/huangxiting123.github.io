import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('.',import.meta.url));
function launch(home){const processRef=spawn(process.execPath,['local-launcher.mjs','--no-browser'],{cwd:root,env:{...process.env,STILLHERE_LOCAL_HOME:home,PERSONA_PUBLIC_ORIGIN:'https://invalid.test:443',PERSONA_TLS_CERT:'/does-not-exist',PERSONA_TLS_KEY:'/does-not-exist',PERSONA_LISTEN_HOST:'0.0.0.0',PERSONA_TURN_URLS:'',PERSONA_TURN_SECRET:'',PERSONA_RTC_POLICY:''},stdio:['ignore','pipe','pipe']});let out='';processRef.stderr.on('data',p=>out+=p);const ready=new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('launcher timeout')),10000);processRef.stdout.on('data',part=>{out+=part;const url=out.match(/STILLHERE: (http:\/\/127\.0\.0\.1:[0-9]+)/);if(url){clearTimeout(timer);resolve(url[1]);}});processRef.once('exit',code=>{clearTimeout(timer);reject(Error('launcher exited '+code));});});return {process:processRef,ready,output:()=>out};}
async function end(item){if(item.process.exitCode===null){const done=new Promise(r=>item.process.once('exit',r));item.process.kill();await done;}}
async function api(url,token,path,{method='GET',data}={}){const r=await fetch(url+'/api/'+path,{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},...(data?{body:JSON.stringify(data)}:{})});assert.equal(r.status,200,await r.clone().text());return r.json();}
test('local launcher persists its own token and data, stays loopback-only, and rejects duplicate launchers',async()=>{
 const home=await mkdtemp(join(tmpdir(),'stillhere-launcher-'));let first,second,restart;
 try{first=launch(home);const url=await first.ready,token=(await readFile(join(home,'owner.token'),'utf8')).trim();assert.match(token,/^[a-f0-9]{64}$/);assert.equal((await api(url,token,'state')).connection.mode,'local-http');await api(url,token,'profile',{method:'POST',data:{name:'LAUNCHER_PERSIST_TEST'}});
 second=launch(home);const secondReady=second.ready.catch(()=>{});const code=await new Promise(r=>second.process.once('exit',r));await secondReady;assert.equal(code,1);assert.match(second.output(),/已在运行|端口被占用/);assert.equal((await api(url,token,'state')).profile.name,'LAUNCHER_PERSIST_TEST');
 await end(first);await assert.rejects(fetch(url+'/'));restart=launch(home);const restarted=await restart.ready;assert.equal((await readFile(join(home,'owner.token'),'utf8')).trim(),token);assert.equal((await api(restarted,token,'state')).profile.name,'LAUNCHER_PERSIST_TEST');
 }finally{if(first)await end(first);if(second)await end(second);if(restart)await end(restart);await rm(home,{recursive:true,force:true});}
});
test('backend launched with IPC supervision exits when its launcher connection disappears',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'stillhere-parent-watch-'));let child;
 try{child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:'4352',PERSONA_DATA:join(dir,'data.json'),PERSONA_OWNER_TOKEN:'parent-test-only',STILLHERE_PARENT_WATCH:'1'},stdio:['ignore','pipe','pipe','ipc']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);});const exited=new Promise(r=>child.once('exit',r));child.disconnect();assert.equal(await exited,0);}finally{if(child?.exitCode===null)child.kill();await rm(dir,{recursive:true,force:true});}
});
