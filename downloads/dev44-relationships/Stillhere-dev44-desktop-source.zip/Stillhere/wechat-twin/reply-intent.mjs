export function voiceReplyRequested(text){return typeof text==='string'&&!/不要|别用|别发|不用|不需要|取消|停止|如何|怎么让|怎样让/.test(text)&&(/^\s*\/语音(?:\s|$)/.test(text)||/(?:用|发|来|给我).{0,8}语音.{0,8}(?:回|说|讲|听|给我)|语音(?:回复|回我|说一下|告诉我)|说给我听/.test(text));}
export function messageReplyMode(configured,text){return configured==='text'&&voiceReplyRequested(text)?'both':configured;}
