import {createCipheriv,createHash,randomBytes} from 'node:crypto';
import {encode,getWavFileInfo,isSilk} from './vendor/silk-wasm/lib/index.mjs';
export function validateUploadUrl(value){const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||u.hash||!(u.hostname==='cdn.weixin.qq.com'||u.hostname.endsWith('.cdn.weixin.qq.com')))throw Error('语音上传地址不在微信官方CDN范围内');return u.href;}
export async function encodeReplyVoice(wav){
 if(!Buffer.isBuffer(wav)||wav.length>10*1024*1024)throw Error('本人声音文件为空或超过限制');let info;try{info=getWavFileInfo(wav);}catch{throw Error('本人声音服务未返回有效WAV');}
 const fmt=info.fmt,data=info.chunkInfo.find(x=>x.chunkId.trim()==='data');if(fmt.formatCode!==1||fmt.bitsPerSample!==16||fmt.numberOfChannels!==1||![8000,12000,16000,24000].includes(fmt.sampleRate)||!data)throw Error('本人声音需要单声道8—24kHz PCM16 WAV');const ms=data.dataLength/fmt.bytesPerSec*1000;if(ms<200||ms>60000)throw Error('微信语音回复支持0.2—60秒，请让分身简短回答');
 const result=await encode(wav,0),bytes=Buffer.from(result.data);if(!isSilk(bytes)||bytes.length>2*1024*1024||result.duration<200||result.duration>60000)throw Error('本人声音转换为微信语音失败或超过60秒');return {bytes,durationMs:Math.round(result.duration),sampleRate:fmt.sampleRate};
}
export async function uploadReplyVoice(voice,{getUploadUrl,fetcher=fetch,signal,beforeSend=async()=>{}}){
 if(!Buffer.isBuffer(voice?.bytes)||!isSilk(voice.bytes)||voice.bytes.length>2*1024*1024||!Number.isInteger(voice.durationMs)||voice.durationMs<200||voice.durationMs>60000||![8000,12000,16000,24000].includes(voice.sampleRate))throw Error('待发送语音格式无效');
 await beforeSend();if(signal?.aborted)throw Error('语音发送已取消');const key=randomBytes(16),filekey=randomBytes(16).toString('hex'),cipher=createCipheriv('aes-128-ecb',key,null),encrypted=Buffer.concat([cipher.update(voice.bytes),cipher.final()]);
 const value=await getUploadUrl({filekey,media_type:4,rawsize:voice.bytes.length,rawfilemd5:createHash('md5').update(voice.bytes).digest('hex'),filesize:encrypted.length,no_need_thumb:true,aeskey:key.toString('hex')});
 const raw=value.upload_full_url?.trim()||(value.upload_param?'https://novac2c.cdn.weixin.qq.com/c2c/upload?encrypted_query_param='+encodeURIComponent(value.upload_param)+'&filekey='+encodeURIComponent(filekey):null);if(!raw)throw Error('微信没有返回语音上传地址');const url=validateUploadUrl(raw);if(signal?.aborted)throw Error('语音发送已取消');
 const r=await fetcher(url,{method:'POST',redirect:'error',headers:{'Content-Type':'application/octet-stream'},body:encrypted,signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(90000)])});if(r.status!==200){try{await r.body?.cancel();}catch{}throw Error('微信语音上传失败（HTTP '+r.status+'）');}const param=r.headers.get('x-encrypted-param');try{await r.body?.cancel();}catch{}if(!param)throw Error('微信语音上传未返回媒体引用');await beforeSend();if(signal?.aborted)throw Error('语音发送已取消');
 return {type:3,voice_item:{media:{encrypt_query_param:param,aes_key:Buffer.from(key.toString('hex')).toString('base64'),encrypt_type:1},encode_type:6,bits_per_sample:16,sample_rate:voice.sampleRate,playtime:voice.durationMs}};
}
