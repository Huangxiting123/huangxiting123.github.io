// Explicit opt-in, serial checks. Scheduling is measured after each completed check.
export function createFaceMonitor({check,onChange=()=>{},onAlert=()=>{},schedule=setTimeout,cancel=clearTimeout,now=()=>Date.now(),intervalMs=5000,timeoutMs=15000}){
 let epoch=0,active=false,inFlight=false,timer=null,watchdog=null;
 let state={active:false,checking:false,checks:0,lastCheckedAt:null,status:'off',reason:''};
 const emit=patch=>{state={...state,...patch};onChange({...state});};
 const clear=()=>{if(timer!==null)cancel(timer);if(watchdog!==null)cancel(watchdog);timer=watchdog=null;};
 function stop(){epoch++;active=false;clear();emit({active:false,checking:false,status:'off',reason:''});}
 function alert(reason,current){if(current!==epoch||!active)return;epoch++;active=false;clear();emit({active:false,checking:false,status:'alert',reason});onAlert(reason);}
 function next(){if(active&&timer===null)timer=schedule(()=>{timer=null;run();},intervalMs);}
 async function run(){
  if(!active||inFlight)return;if(watchdog!==null)cancel(watchdog);watchdog=null;const current=epoch;inFlight=true;emit({checking:true,status:'checking'});
  watchdog=schedule(()=>alert('人脸核对超时，请重新确认交流身份。',current),timeoutMs);
  try{const result=await check();if(current!==epoch||!active)return;if(!result?.matched){alert(result?.reason||'与本人样本不匹配，请重新确认交流身份。',current);return;}
   emit({checking:false,checks:state.checks+1,lastCheckedAt:now(),status:'waiting',reason:''});
  }catch(e){alert(e.message||'无法核对镜头画面，请重新确认交流身份。',current);}
  finally{inFlight=false;if(current===epoch){if(watchdog!==null)cancel(watchdog);watchdog=null;}if(active)next();}
 }
 function start(){if(active)return;epoch++;clear();active=true;emit({active:true,checking:false,checks:0,lastCheckedAt:null,status:'checking',reason:''});if(!inFlight)run();else{const current=epoch;watchdog=schedule(()=>alert('上一次人脸核对尚未结束，请重新确认交流身份。',current),timeoutMs);}}
 return {start,stop,snapshot:()=>({...state})};
}
