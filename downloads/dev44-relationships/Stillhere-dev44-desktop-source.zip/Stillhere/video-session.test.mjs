import test from 'node:test';
import assert from 'node:assert/strict';
import {createVideoSession} from './video-session.mjs';
function media(){const tracks=['video','audio'].map(kind=>({kind,enabled:true,stopped:false,events:{},stop(){this.stopped=true;},addEventListener(event,cb){this.events[event]=cb;}}));return {getTracks:()=>tracks,getVideoTracks:()=>tracks.filter(t=>t.kind==='video'),getAudioTracks:()=>tracks.filter(t=>t.kind==='audio')};}
test('local preview supports mute, cleanup, and restart without retaining old tracks',async()=>{
 const a=media(),b=media();let calls=0;const s=createVideoSession({getUserMedia:async()=>calls++?b:a,now:()=>123});
 await s.start();assert.equal(s.snapshot().phase,'preview');assert.equal(s.snapshot().startedAt,123);await s.start();assert.equal(calls,1);
 s.toggleMute();assert.equal(a.getAudioTracks()[0].enabled,false);s.toggleMute();assert.equal(a.getAudioTracks()[0].enabled,true);
 s.end();assert.ok(a.getTracks().every(t=>t.stopped));assert.equal(s.snapshot().stream,null);assert.equal(s.snapshot().startedAt,null);
 await s.start();assert.equal(s.snapshot().stream,b);s.end();
});
test('cancel and restart while device permission is pending stops late devices',async()=>{
 let resolve;const late=media(),active=media();let calls=0;
 const s=createVideoSession({getUserMedia:()=>++calls===1?new Promise(r=>resolve=r):Promise.resolve(active)});
 const pending=s.start();assert.equal(s.snapshot().phase,'requesting');s.end();await s.start();resolve(late);await pending;
 assert.ok(late.getTracks().every(t=>t.stopped));assert.equal(s.snapshot().stream,active);s.end();
});
test('permission failure permits retry and device disconnect releases remaining tracks',async()=>{
 const a=media();let failed=false;const s=createVideoSession({getUserMedia:async()=>{if(!failed){failed=true;throw Object.assign(Error(),{name:'NotAllowedError'});}return a;}});
 await s.start();assert.equal(s.snapshot().phase,'idle');assert.match(s.snapshot().error,/权限/);await s.start();a.getVideoTracks()[0].events.ended();assert.ok(a.getTracks().every(t=>t.stopped));assert.equal(s.snapshot().phase,'idle');
});
test('a stale rejection does not interrupt a newer preview',async()=>{
 let reject;let calls=0;const a=media();const s=createVideoSession({getUserMedia:()=>++calls===1?new Promise((_,r)=>reject=r):Promise.resolve(a)});
 const p=s.start();s.end();await s.start();reject(Error('old request'));await p;assert.equal(s.snapshot().stream,a);assert.equal(s.snapshot().error,'');s.end();
});
test('partial media acquisition is rejected and all acquired tracks are released',async()=>{
 const a=media();a.getAudioTracks=()=>[];const s=createVideoSession({getUserMedia:async()=>a});await s.start();assert.equal(s.snapshot().phase,'idle');assert.ok(a.getTracks().every(t=>t.stopped));assert.match(s.snapshot().error,/麦克风/);
});
test('audio-only mode never requests camera and supports mute and cleanup',async()=>{
 const a=media();const audio=a.getAudioTracks();let constraints;const stream={getTracks:()=>audio,getAudioTracks:()=>audio,getVideoTracks:()=>[]};
 const s=createVideoSession({getUserMedia:async options=>{constraints=options;return stream;}});await s.start({video:false});assert.equal(constraints.video,false);assert.equal(s.snapshot().videoEnabled,false);assert.equal(s.snapshot().phase,'preview');s.toggleMute();assert.equal(audio[0].enabled,false);s.end();assert.ok(audio[0].stopped);
});
test('audio-only mode still rejects missing microphone and releases acquired devices',async()=>{
 const a=media();a.getAudioTracks=()=>[];const s=createVideoSession({getUserMedia:async()=>a});await s.start({video:false});assert.equal(s.snapshot().phase,'idle');assert.ok(a.getTracks().every(t=>t.stopped));
});
