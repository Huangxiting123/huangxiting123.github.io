@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0local-launcher.mjs"
) else (
  node "%~dp0local-launcher.mjs"
)
pause
