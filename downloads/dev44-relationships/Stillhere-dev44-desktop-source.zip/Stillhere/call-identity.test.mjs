import test from 'node:test';
import assert from 'node:assert/strict';
import {createCallSessions,callPrincipal} from './call-identity.mjs';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
test('identity requires explicit confirmation, is principal-bound, and can be paused',()=>{
 const s=createCallSessions();const a=s.create('alice');assert.equal(a.status,'pending');assert.throws(()=>s.check(a.id,'alice'),e=>e.status===403);assert.throws(()=>s.update(a.id,'bob','confirm'),e=>e.status===403);s.update(a.id,'alice','confirm');assert.equal(s.check(a.id,'alice').status,'confirmed');s.update(a.id,'alice','pause');assert.throws(()=>s.check(a.id,'alice'));s.remove(a.id,'alice');assert.throws(()=>s.update(a.id,'alice','confirm'));
});
test('expired identity cannot confirm or authorize more requests',()=>{
 let time=0;const s=createCallSessions({now:()=>time,ttl:10});const a=s.create('alice');s.update(a.id,'alice','confirm');time=10;assert.throws(()=>s.check(a.id,'alice'),e=>e.status===403);assert.throws(()=>s.update(a.id,'alice','confirm'));
});
test('new identity session replaces old session and token fingerprints distinguish credentials',()=>{
 const s=createCallSessions();const a=s.create('alice');s.update(a.id,'alice','confirm');const b=s.create('alice');assert.throws(()=>s.check(a.id,'alice'));assert.equal(b.status,'pending');assert.notEqual(callPrincipal('old-token'),callPrincipal('new-token'));assert.equal(callPrincipal('same'),callPrincipal('same'));
});
test('capacity limits do not evict unrelated active callers',()=>{
 const s=createCallSessions({limit:1});const a=s.create('alice');assert.throws(()=>s.create('bob'),e=>e.status===429);s.update(a.id,'alice','confirm');assert.equal(s.check(a.id,'alice').status,'confirmed');
});
test('HTTP identity is derived from bearer credentials and guards speech/chat without granting another identity',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'stillhere-identity-'));let child,upstream,release;
 async function api(path,{token='owner-test',data,method='GET',status=200,callId}={}){const r=await fetch('http://127.0.0.1:4342/api/'+path,{method,headers:{Authorization:'Bearer '+token,'Content-Type':'application/json',...(callId?{'X-Stillhere-Call-Session':callId}:{})},...(data?{body:JSON.stringify(data)}:{})});assert.equal(r.status,status,await r.clone().text());return r.json();}
 try{
  child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('.',import.meta.url)),env:{...process.env,PORT:'4342',PERSONA_DATA:join(dir,'state.json'),PERSONA_OWNER_TOKEN:'owner-test',PERSONA_API_URL:'',PERSONA_API_KEY:'',PERSONA_MODEL:'',PERSONA_ASR_URL:'',PERSONA_TTS_URL:''},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',()=>reject(Error('server exited')));});
  const a=await api('contacts',{method:'POST',data:{name:'小雨',relation:'女儿',address:'宝贝'},status:201});const b=await api('contacts',{method:'POST',data:{name:'朋友',relation:'朋友'},status:201});
  const own=await api('call/sessions',{method:'POST',data:{},status:201});assert.equal(own.identity.role,'owner');
  await api('call/sessions',{method:'POST',token:'invalid',data:{},status:401});
  const session=await api('call/sessions',{method:'POST',token:a.token,data:{},status:201});assert.equal(session.identity.name,'小雨');assert.equal(session.identity.relation,'女儿');assert.equal(session.capabilities.faceRecognition,false);assert.equal(session.capabilities.voiceprintRecognition,false);
  const state=await api('state',{token:a.token});assert.equal(state.contact.address,'宝贝');assert.equal(state.contacts,undefined);
  await api('chat',{token:a.token,callId:session.id,method:'POST',data:{text:'你好'},status:403});
  await api('call/sessions/'+session.id,{token:b.token,method:'PUT',data:{action:'confirm'},status:403});
  await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'confirm',speakerId:b.id},status:400});
  await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'confirm'}});
  const reply=await api('chat',{token:a.token,callId:session.id,method:'POST',data:{text:'你好'}});assert.equal(reply.assistant.contactId,a.id);
  await api('chat',{token:b.token,callId:session.id,method:'POST',data:{text:'越权'},status:403});
  await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'pause'}});
  await api('speech/transcribe',{token:a.token,callId:session.id,method:'POST',data:{},status:403});await api('speech/synthesize',{token:a.token,callId:session.id,method:'POST',data:{messageId:reply.assistant.id},status:403});
  let arrived;const started=new Promise(r=>arrived=r);const gate=new Promise(r=>release=r);upstream=http.createServer(async(req,res)=>{for await(const part of req){}arrived();await gate;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({text:'暂停后不可返回的转写'}));});await new Promise(r=>upstream.listen(0,'127.0.0.1',r));
  await api('speech/config/asr',{method:'PUT',data:{url:'http://127.0.0.1:'+upstream.address().port+'/asr',key:'fake-asr',model:'mock'}});
  await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'confirm'}});
  const audio=Buffer.alloc(48);audio.write('RIFF');audio.write('WAVE',8);
  const pending=fetch('http://127.0.0.1:4342/api/speech/transcribe',{method:'POST',headers:{Authorization:'Bearer '+a.token,'Content-Type':'audio/wav','X-Stillhere-Call-Session':session.id},body:audio});await started;
  await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'pause'}});release();const late=await pending;assert.equal(late.status,403);assert.doesNotMatch(await late.text(),/暂停后不可返回的转写/);
  await api('call/sessions/'+session.id,{token:a.token,method:'DELETE'});await api('call/sessions/'+session.id,{token:a.token,method:'PUT',data:{action:'confirm'},status:403});
 }finally{if(child?.exitCode===null){const ended=new Promise(r=>child.once('exit',r));child.kill();await ended;}release?.();if(upstream)await new Promise(r=>upstream.close(r));await rm(dir,{recursive:true,force:true});}
});
