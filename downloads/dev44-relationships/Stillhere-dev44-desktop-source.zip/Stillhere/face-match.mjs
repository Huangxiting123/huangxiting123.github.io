export const FACE_THRESHOLD=0.45; // Initial strict threshold; not a calibrated probability.
export function faceDescriptor(value){
 if(!Array.isArray(value)&&!ArrayBuffer.isView(value))throw Error('人脸特征无效，请重新采集');const v=Array.from(value);if(v.length!==128||v.some(x=>!Number.isFinite(x)||Math.abs(x)>10)||!v.some(x=>x!==0))throw Error('人脸特征无效，请重新采集');return v;
}
export function faceDistance(a,b){a=faceDescriptor(a);b=faceDescriptor(b);return Math.sqrt(a.reduce((sum,x,i)=>sum+(x-b[i])**2,0));}
export function singleFace(results){
 if(results.length!==1)throw Error(results.length?'镜头中有多张脸，请仅由本人单独入镜':'没有检测到人脸，请面向镜头并改善光线');
 const r=results[0];if(r.detection.score<0.7||r.detection.box.width<80||r.detection.box.height<80)throw Error('人脸太小或不清晰，请靠近镜头后重试');return faceDescriptor(r.descriptor);
}
export function createFaceEnrollment(){
 let samples=[];
 return {
  add(value){const descriptor=faceDescriptor(value);if(samples.length>=3)throw Error('已录入3份样本，可先核对或删除后重录');if(samples.length&&Math.min(...samples.map(x=>faceDistance(x,descriptor)))>FACE_THRESHOLD)throw Error('与已有样本差异较大，请确认仅本人入镜或删除后重录');samples.push(descriptor);return samples.length;},
  verify(value){if(!samples.length)throw Error('请先授权并录入本人样本');const descriptor=faceDescriptor(value);const distance=Math.min(...samples.map(x=>faceDistance(x,descriptor)));return {matched:distance<=FACE_THRESHOLD,distance,threshold:FACE_THRESHOLD};},
  count:()=>samples.length,
  clear(){for(const s of samples)s.fill(0);samples=[];}
 };
}
