let loading;
export async function locatePortraitFace(blob){
 if(!loading)loading=(async()=>{const api=await import('/vendor/face-api/face-api.esm.js');await api.tf.setBackend('cpu');await api.tf.ready();await Promise.all([api.nets.tinyFaceDetector.loadFromUri('/vendor/face-api/models'),api.nets.faceLandmark68TinyNet.loadFromUri('/vendor/face-api/models')]);return api;})().catch(e=>{loading=null;throw e;});
 const api=await loading,bitmap=await createImageBitmap(blob);try{const canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;canvas.getContext('2d').drawImage(bitmap,0,0);const results=await api.detectAllFaces(canvas,new api.TinyFaceDetectorOptions({inputSize:416,scoreThreshold:.5})).withFaceLandmarks(true);if(results.length!==1)throw Error('照片需要恰好一张清晰正面人脸，请更换照片');const points=results[0].landmarks.positions,jaw=points.slice(0,17),chin=Math.max(...jaw.map(p=>p.y)),nose=points[29].y;
 const crop=[Math.max(0,Math.floor(Math.min(...jaw.map(p=>p.x)))),Math.max(0,Math.floor(nose-(chin-nose))),Math.min(bitmap.width,Math.ceil(Math.max(...jaw.map(p=>p.x)))),Math.min(bitmap.height,Math.ceil(chin+10))];if(crop[2]-crop[0]<48||crop[3]-crop[1]<48)throw Error('人脸过小，请换用近景正面照');return crop;
 }finally{bitmap.close();}
}
