import {planSpeechSegments,prepareRecognitionAudio} from './asr-audio-quality.mjs';
import {execFile} from 'node:child_process';
import {access,mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {readPcmWav,pcmWav,ASSET_AUDIO_RATE} from './asset-audio.mjs';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function createLocalAsr({directory,language='zh',execute=execFile}={}){
 let active=false,child=null,closed=false,settled=Promise.resolve();
 const executable=join(directory,process.platform==='win32'?'sherpa-onnx-offline.exe':'sherpa-onnx-offline');
 const profiles={mandarin:{label:'普通话 / 四川口音',model:'paraformer-zh.int8.onnx',tokens:'paraformer-zh.tokens.txt'},sichuan:{label:'四川话 / 重庆话',model:'paraformer-chuan.int8.onnx',tokens:'paraformer-chuan.tokens.txt'}};
 const engineName=profile=>'sherpa-onnx / Paraformer '+(profile==='sichuan'?'川渝方言':'中文通用');
 async function status(){let executableReady=true;try{await access(executable);}catch{executableReady=false;}const modes=[];for(const [id,p] of Object.entries(profiles)){let available=executableReady;try{await Promise.all([p.model,p.tokens].map(f=>access(join(directory,f))));}catch{available=false;}modes.push({id,label:p.label,available,engine:engineName(id)});}return {available:modes.some(p=>p.available),profiles:modes,busy:active,engine:engineName('mandarin'),language,maxSeconds:65,localOnly:true};}
 async function transcribe(bytes,{signal,profile='mandarin'}={}){
 if(closed||signal?.aborted)fail(409,'转写已取消');if(active)fail(409,'已有本机转写任务，请稍后重试');if(!profiles[profile])fail(400,'请选择普通话或川渝方言模型');const {samples,quality}=prepareRecognitionAudio(readPcmWav(bytes));active=true;let finish;settled=new Promise(resolve=>{finish=resolve;});let dir;
 try{if(!(await status()).profiles.find(p=>p.id===profile)?.available)fail(503,'本地转写组件未就绪，请完整安装本版转写组件');dir=await mkdtemp(join(tmpdir(),'stillhere-asr-'));const texts=[];let partIndex=0;
 for(const {start,end} of planSpeechSegments(samples)){if(signal?.aborted||closed)fail(409,'转写已取消');const part=samples.subarray(start,end),rms=Math.sqrt(part.reduce((sum,x)=>sum+x*x,0)/part.length);if(rms<0.0003)continue;const path=join(dir,'part-'+String(partIndex++)+'.wav');await writeFile(path,pcmWav(part),{mode:0o600});
 const stdout=await new Promise((resolve,reject)=>{const abort=()=>child?.kill();signal?.addEventListener('abort',abort,{once:true});child=execute(executable,['--paraformer='+join(directory,profiles[profile].model),'--tokens='+join(directory,profiles[profile].tokens),'--num-threads=2',path],{windowsHide:true,timeout:120000,maxBuffer:1024*1024,encoding:'utf8'},(error,out)=>{signal?.removeEventListener('abort',abort);child=null;if(error)reject(Object.assign(Error(signal?.aborted||closed?'转写已取消':error.killed?'本机转写超时，请缩短素材后重试':'本地转写引擎运行失败，请检查组件是否完整、内存是否充足'),{status:502}));else resolve(out);});});
 let value;try{value=JSON.parse(stdout.trim());}catch{fail(502,'本地转写引擎返回格式异常');}if(typeof value.text!=='string')fail(502,'本地转写引擎没有返回文字');if(value.text.trim())texts.push(value.text.trim());
 }
 if(signal?.aborted||closed)fail(409,'转写已取消');const text=texts.join('\n');if(!text||text.length>10000)fail(422,'未识别到有效语音，请检查收音或缩短素材后重试');return {text,engine:engineName(profile),profile,quality,language,durationSeconds:samples.length/ASSET_AUDIO_RATE};
 }finally{try{if(dir)await rm(dir,{recursive:true,force:true});}finally{active=false;finish();}}
 }
 return {status,transcribe,close(){closed=true;child?.kill();return settled;}};
}
