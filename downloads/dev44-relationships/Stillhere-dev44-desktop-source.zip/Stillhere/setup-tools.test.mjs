import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,rm} from 'node:fs/promises';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {installVerifiedTool} from './local-models/prepare-tools.mjs';
test('bundled installer tool is copied only after validation and revalidated at destination',async()=>{const dir=await mkdtemp(join(tmpdir(),'stillhere-uv-copy-'));try{const source=join(dir,'bundle.exe'),target=join(dir,'E-models','setup-tools','uv.exe'),bytes=Buffer.from('test executable fixture');await writeFile(source,bytes);await installVerifiedTool(source,target,createHash('sha256').update(bytes).digest('hex'));assert.deepEqual(await readFile(target),bytes);}finally{await rm(dir,{recursive:true,force:true});}});
test('a bad bundled tool does not overwrite or execute an existing file',async()=>{const dir=await mkdtemp(join(tmpdir(),'stillhere-uv-invalid-'));try{const source=join(dir,'bundle.exe'),target=join(dir,'uv.exe');await writeFile(source,'corrupt');await writeFile(target,'existing');await assert.rejects(installVerifiedTool(source,target,'0'.repeat(64)),/校验失败/);assert.equal(await readFile(target,'utf8'),'existing');}finally{await rm(dir,{recursive:true,force:true});}});
