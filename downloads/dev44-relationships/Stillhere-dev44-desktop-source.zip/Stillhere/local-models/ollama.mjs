import {spawn,execFileSync} from 'node:child_process';
import {access} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import net from 'node:net';
export async function findOllama(saved,env=process.env){
 const candidates=[env.STILLHERE_OLLAMA_EXE,saved,join(env.LOCALAPPDATA||'','Programs','Ollama','ollama.exe'),join(env.ProgramFiles||'C:\\Program Files','Ollama','ollama.exe')];
 try{candidates.unshift(...execFileSync('where.exe',['ollama.exe'],{encoding:'utf8',windowsHide:true,stdio:['ignore','pipe','ignore']}).trim().split(/\r?\n/));}catch{}
 try{const output=execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',"[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false); Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -in @('ollama','ollama app') } | ForEach-Object { $_.Path }"],{encoding:'utf8',windowsHide:true,stdio:['ignore','pipe','ignore']});for(const line of output.trim().split(/\r?\n/)){if(line)candidates.push(line,join(dirname(line),'ollama.exe'));}}catch{}
 for(const p of candidates){if(!p||!p.toLowerCase().endsWith('ollama.exe'))continue;try{await access(p);return p;}catch{}}
 throw Error('没有找到Ollama命令程序；请打开已安装的Ollama再试，或设置STILLHERE_OLLAMA_EXE为其完整路径');
}
export async function freePort(){const probe=net.createServer();await new Promise((resolve,reject)=>{probe.once('error',reject);probe.listen(0,'127.0.0.1',resolve);});const port=probe.address().port;await new Promise(r=>probe.close(r));return port;}
export async function startOwnedOllama(executable,environment,{timeoutMs=30000,avoidPorts=[]}={}){
 let port;do{port=await freePort();}while(avoidPorts.includes(port));const url='http://127.0.0.1:'+port;const env={...environment,OLLAMA_HOST:'127.0.0.1:'+port};
 const child=spawn(executable,['serve'],{env,stdio:['ignore','ignore','ignore'],windowsHide:true});let failed=null;child.on('error',e=>{failed=e;});
 const until=Date.now()+timeoutMs;
 try{while(Date.now()<until){if(failed||child.exitCode!==null)throw Error('独立Ollama服务启动失败，请确认安装目录和可执行文件完整');try{const r=await fetch(url+'/api/tags',{signal:AbortSignal.timeout(1000)});if(r.ok)return {child,url,env};}catch{}await new Promise(r=>setTimeout(r,150));}throw Error('独立Ollama服务启动超时，请重试');}catch(e){child.kill();throw e;}
}
