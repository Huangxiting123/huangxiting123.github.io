import argparse, json, hashlib, datetime, importlib.metadata, urllib.request
from pathlib import Path
from modelscope import snapshot_download
p = argparse.ArgumentParser()
p.add_argument('--home', required=True)
p.add_argument('--models-home', required=True)
p.add_argument('--ollama-url', required=True)
p.add_argument('--ollama-executable', required=True)
a = p.parse_args()
root = Path(a.home)
model_root = Path(a.models_home)
voice_dir = model_root / 'models' / 'Qwen3-TTS-12Hz-0.6B-Base'
snapshot_download('Qwen/Qwen3-TTS-12Hz-0.6B-Base', local_dir=str(voice_dir))
required = ['config.json', 'speech_tokenizer/config.json']
if not all((voice_dir / name).is_file() for name in required) or not list(voice_dir.glob('*.safetensors')):
    raise SystemExit('Voice model incomplete; setup not enabled')
files = {}
for item in voice_dir.rglob('*'):
    if item.is_file() and item.suffix in ('.safetensors', '.json'):
        digest = hashlib.sha256()
        with item.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        files[item.relative_to(voice_dir).as_posix()] = digest.hexdigest()
packages = {name: importlib.metadata.version(name) for name in ('torch', 'torchaudio', 'qwen-tts', 'transformers', 'modelscope')}
with urllib.request.urlopen(a.ollama_url + '/api/tags', timeout=10) as response:
    tags = json.load(response).get('models', [])
text_info = next((item for item in tags if item.get('name') == 'qwen3:4b-instruct-2507-q4_K_M'), {})
(root / 'local-model-manifest.json').write_text(json.dumps({'voice_model': 'Qwen/Qwen3-TTS-12Hz-0.6B-Base',
    'source': 'ModelScope', 'files': files, 'packages': packages, 'text_model_digest': text_info.get('digest'),
    'installed_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}, ensure_ascii=False, indent=2), encoding='utf8')
settings = {'enabled': True, 'python': str(model_root / 'model-runtime' / 'Scripts' / 'python.exe'),
            'voiceModelDir': str(voice_dir), 'textModel': 'qwen3:4b-instruct-2507-q4_K_M',
            'voiceModel': 'Qwen/Qwen3-TTS-12Hz-0.6B-Base', 'modelsHome': str(model_root), 'ollamaExecutable': a.ollama_executable, 'managedOllama': True, 'version': 2}
temp = root / 'local-models.json.tmp'
temp.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding='utf8')
temp.replace(root / 'local-models.json')
print('Model files installed. Restart the main application. First synthesis remains unverified.')
