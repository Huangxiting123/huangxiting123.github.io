# Local conversation and reference-voice prototype

Target to be tested: Windows x64, 16GB system RAM, NVIDIA RTX 3060 Ti (usually 8GB VRAM). This hardware has not been exercised by this cloud task.

- Text: Ollama `qwen3:4b-instruct-2507-q4_K_M`, CPU explicitly selected through the native `/api/chat` options. Generation context is bounded at 8192 tokens, output 256 tokens, `keep_alive:0` unloads the text model after each reply. This favors available GPU memory, not real-time conversation speed.
- Voice: official `Qwen/Qwen3-TTS-12Hz-0.6B-Base`, conditional voice cloning from authorized 5–15s reference PCM plus an accurate transcript. CUDA, 16-bit precision and SDPA; no FlashAttention build requirement. This is inference with a pretrained model, not a training job.
- Separate dialogue expression examples affect the text model prompt; they do not guarantee learned emotion/prosody. No reference voice reaches the text model.

The installation command needs Ollama installed first, then provisions managed Python 3.12 via pinned/checksummed uv 0.13.7, PyTorch/torchaudio 2.7.1 CUDA11.8, qwen-tts 0.1.1 and modelscope 1.40.2. It downloads the voice model from the official Qwen ModelScope repository. At least 15GB free disk is checked; actual download sizes depend on caches and dependencies. Setup has not been executed on Windows here. Package/API syntax and protocol adapters were checked, but actual GPU inference, performance and resemblance remain acceptance work.

After setup, the launcher reads the completion flag from the persistent local home, starts an authenticated loopback Python bridge on a free port and points text/voice adapters to it. The dedicated bridge key is not the owner credential. The bridge uses an installed local snapshot with offline loading during inference. Ollama remains a separately installed local application. Model source file hashes, installed Python package versions and available Ollama model digest are recorded in `local-model-manifest.json` in the local data home.

Voice references are stored in the local persona database, excluded from normal state responses/export, and can be revoked; deleting their source asset also revokes the reference. Revocation prevents returned audio from using a stale authorization, although already started inference may finish. Raw user text/audio are not logged by the bridge. Preset/test audio is never a production fallback.

Official references:
- https://ollama.com/library/qwen3/tags
- https://github.com/QwenLM/Qwen3-TTS
- https://modelscope.cn/models/Qwen/Qwen3-TTS-12Hz-0.6B-Base
- https://github.com/astral-sh/uv/releases/tag/0.13.7
- https://pytorch.org/get-started/previous-versions/

Qwen model weights are not bundled in the main release ZIP and require first-time downloads on the customer's machine. Their licensing and dependency notices accompany their respective upstream distributions. The application continues to work in memory retrieval mode if models are not installed, but it must not label that mode as natural dialogue or a cloned voice.


## dev32-E1 storage hotfix
Data/credentials retain their original local home. Large models, virtual environment, managed Python, download caches and temp are placed under a separate modelsHome. Explicit STILLHERE_MODELS_HOME wins, then the persisted model-storage.json pointer, then Stillhere-Models on the application drive. 安装模型到E盘.cmd selects E:\Stillhere-Models explicitly.

An owned Ollama instance uses a private loopback port and OLLAMA_MODELS under modelsHome. Installation/pull, model-manifest lookup and runtime bridge all use this same owned instance; the user's existing GUI service and global environment are not reconfigured. A completed version2 local-models.json records the storage path and executable; the launcher preserves version1 legacy configs. No old data/cache directories are deleted or migrated.

Validated: Windows path planning, cache/environment routing, original-data preservation and owned-server protocol tests plus regression suites. Actual Windows installation/drive writes and GPU inference still require customer acceptance.
