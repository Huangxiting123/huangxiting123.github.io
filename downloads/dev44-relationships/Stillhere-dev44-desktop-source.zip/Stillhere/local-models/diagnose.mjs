import {readFile,writeFile} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {modelStoragePlan,modelEnvironment} from './storage.mjs';
import {findOllama,startOwnedOllama} from './ollama.mjs';
const model='qwen3:4b-instruct-2507-q4_K_M';
export async function probeOllama(url,{fetcher=fetch,log=()=>{}}={}){
 const parsed=new URL(url);if(parsed.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(parsed.hostname)||parsed.username||parsed.password||parsed.search||parsed.hash||parsed.pathname!=='/')throw Error('Expected loopback Ollama URL');
 const request=async(path,data)=>{const r=await fetcher(url+path,{method:data?'POST':'GET',redirect:'error',headers:{'Content-Type':'application/json'},body:data?JSON.stringify(data):undefined,signal:AbortSignal.timeout(data?180000:10000)});const value=await r.json();return {status:r.status,value};};
 const version=await request('/api/version');log('Ollama version: '+String(version.value.version||'unknown'));
 const tags=await request('/api/tags');if(tags.status!==200)throw Error('Cannot list models: HTTP '+tags.status);
 const found=tags.value.models?.find(m=>m.name===model);log('Target model listed: '+Boolean(found));
 if(!found){log('RESULT: MODEL_NOT_LISTED (no automatic download or deletion)');return {ok:false,kind:'missing'};}
 log('Model size bytes: '+String(found.size||'unknown'));log('Testing CPU text inference with fixed public prompt; please wait...');
 const result=await request('/api/chat',{model,messages:[{role:'user',content:'Reply with OK.'}],stream:false,keep_alive:0,options:{num_gpu:0,num_ctx:8192,num_predict:16}});
 log('Chat HTTP: '+result.status);
 if(result.status!==200){log('Ollama error (fixed test only): '+String(result.value.error||'No error detail').replace(/[\r\n]/g,' ').slice(0,3000));return {ok:false,kind:'inference',status:result.status};}
 const ok=Boolean(result.value.message?.content?.trim());log('RESULT: '+(ok?'TEXT_INFERENCE_OK':'EMPTY_RESPONSE'));return {ok,kind:ok?'ok':'empty'};
}
if(process.argv.includes('--run')){
 const output=[];const log=line=>{output.push(line);console.log(line);};let owned=null;
 process.once('SIGINT',()=>{owned?.child.kill();process.exit(130);});process.on('exit',()=>owned?.child.kill());
 const root=dirname(dirname(fileURLToPath(import.meta.url)));
 try{
  if(process.platform!=='win32')throw Error('Run this diagnostic on Windows');
  log('Stillhere dev32-E4 local text diagnostic (no personal stories/voice/credentials read)');
  const home=process.env.STILLHERE_LOCAL_HOME||join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local');
  const config=JSON.parse(await readFile(join(home,'local-models.json'),'utf8'));
  if(!config.managedOllama||!config.modelsHome)throw Error('Expected E-drive managed Ollama configuration');
  const plan=modelStoragePlan({programRoot:root,dataHome:home,selected:config.modelsHome});
  const executable=await findOllama(config.ollamaExecutable);log('Ollama executable: '+executable);log('Model directory: '+plan.ollamaModels);
  owned=await startOwnedOllama(executable,modelEnvironment(plan));const result=await probeOllama(owned.url,{log});if(!result.ok)process.exitCode=1;
 }catch(e){log('CHECK_FAILED: '+e.message);process.exitCode=1;}
 finally{owned?.child.kill();try{await writeFile(join(root,'Stillhere-model-diagnostic.txt'),output.join('\r\n'),'utf8');console.log('Report saved: Stillhere-model-diagnostic.txt');}catch{console.log('Could not save report; use this window output.');}}
}
