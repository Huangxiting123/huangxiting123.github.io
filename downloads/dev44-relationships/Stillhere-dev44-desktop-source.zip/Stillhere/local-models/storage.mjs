import {win32,join,resolve} from 'node:path';
export function modelStoragePlan({programRoot,dataHome,selected,stored,platform=process.platform,env=process.env}){
 const path=platform==='win32'?win32:null;
 const home=selected||env.STILLHERE_MODELS_HOME||stored?.modelsHome||(path?path.join(path.parse(path.resolve(programRoot)).root,'Stillhere-Models'):join(dataHome,'model-storage'));
 const root=path?path.resolve(home):resolve(home),pjoin=path?path.join:join;
 return {modelsHome:root,dataHome,runtime:pjoin(root,'model-runtime'),python:pjoin(root,'model-runtime',platform==='win32'?'Scripts':'bin',platform==='win32'?'python.exe':'python'),voiceDir:pjoin(root,'models','Qwen3-TTS-12Hz-0.6B-Base'),ollamaModels:pjoin(root,'ollama-models'),tools:pjoin(root,'setup-tools'),temp:pjoin(root,'tmp'),cache:pjoin(root,'cache'),pythonInstall:pjoin(root,'python'),uvCache:pjoin(root,'cache','uv'),hfHome:pjoin(root,'cache','huggingface'),hfHub:pjoin(root,'cache','huggingface','hub'),transformersCache:pjoin(root,'cache','huggingface','transformers'),modelscopeCache:pjoin(root,'cache','modelscope'),numbaCache:pjoin(root,'cache','numba')};
}
export function modelEnvironment(plan,base=process.env){return {...base,TEMP:plan.temp,TMP:plan.temp,TMPDIR:plan.temp,UV_CACHE_DIR:plan.uvCache,UV_PYTHON_INSTALL_DIR:plan.pythonInstall,HF_HOME:plan.hfHome,HF_HUB_CACHE:plan.hfHub,TRANSFORMERS_CACHE:plan.transformersCache,MODELSCOPE_CACHE:plan.modelscopeCache,NUMBA_CACHE_DIR:plan.numbaCache,OLLAMA_MODELS:plan.ollamaModels};}
