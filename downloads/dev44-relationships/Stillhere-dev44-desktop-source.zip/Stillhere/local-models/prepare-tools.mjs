import {mkdir,readFile,copyFile} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {modelStoragePlan} from './storage.mjs';
export const UV_EXE_SHA='1791d7a9ed5b6df13ccf80f102e025c333010d96326b4ff0262aa3b578835c5a';
export async function installVerifiedTool(source,target,expected=UV_EXE_SHA){const digest=data=>createHash('sha256').update(data).digest('hex');const input=await readFile(source);if(digest(input)!==expected)throw Error('内置Python工具校验失败，未执行；请重新下载修复包');await mkdir(dirname(target),{recursive:true});await copyFile(source,target);if(digest(await readFile(target))!==expected)throw Error('Python工具复制后校验失败');}
if(process.argv.includes('--install')){try{const root=dirname(dirname(fileURLToPath(import.meta.url))),home=process.env.STILLHERE_LOCAL_HOME||join(process.env.LOCALAPPDATA||join(homedir(),'AppData','Local'),'Stillhere-Local');let stored=null;try{stored=JSON.parse(await readFile(join(home,'model-storage.json'),'utf8'));}catch{}const plan=modelStoragePlan({programRoot:root,dataHome:home,stored});await installVerifiedTool(join(root,'runtime','setup-tools','uv.exe'),join(plan.tools,'uv.exe'));console.log('已校验并准备Python工具：'+join(plan.tools,'uv.exe'));}catch(e){console.error(e.message);process.exitCode=1;}}
