// Room identity is issued by the server after validating each call session.
// It does not establish biometric identity or certify a remote face.
export function describePeerIdentity(room){
 if(!room||room.status==='ended'||room.peerIdentity==='unavailable')return '尚无对端身份确认。';
 const name=String(room.peerName||'对端'),relation=room.peerRelation?' · 关系：'+room.peerRelation:'';
 if(room.peerIdentity==='awaiting')return '受邀账号：'+name+relation+'。等待本人登录并确认交流身份。';
 if(room.peerIdentity==='account_confirmed')return '对端已确认交流身份：'+name+relation+'。依据：登录账号与本人确认；不代表已通过人脸或声纹识别。';
 return '对端身份状态未知，请重新配对。';
}
