import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm,writeFile,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createAssetStore} from './asset-store.mjs';
async function temporary(fn){const dir=await mkdtemp(join(tmpdir(),'stillhere-assets-'));try{await fn(dir);}finally{await rm(dir,{recursive:true,force:true});}}
const item=(changes={})=>({id:randomUUID(),title:'故事原文',mime:'text/plain',body:Buffer.from('小时候在成都学骑自行车。'),...changes});
test('asset persistence, exact bytes, idempotent retry and permanent deletion',()=>temporary(async dir=>{
 const store=createAssetStore(dir),input=item();const row=await store.save(input);assert.equal(row.kind,'story');assert.equal(row.digest,undefined);assert.equal((await store.save(input)).id,row.id);assert.equal((await store.list()).items.length,1);
 const restarted=createAssetStore(dir);assert.deepEqual((await restarted.load(row.id)).body,input.body);await restarted.remove(row.id);assert.equal((await restarted.list()).items.length,0);assert.deepEqual((await readdir(dir)).sort(),['index.json']);await assert.rejects(restarted.load(row.id),e=>e.status===404);
}));
test('conflicting retries, invalid IDs, unsupported types and oversized stories are rejected',()=>temporary(async dir=>{
 const store=createAssetStore(dir),input=item();await store.save(input);await assert.rejects(store.save({...input,body:Buffer.from('changed')}),e=>e.status===409);
 for(const changes of [{id:'../escape'},{mime:'text/html'},{title:''},{body:Buffer.alloc(64001)}])await assert.rejects(store.save(item(changes)));
 assert.equal((await store.list()).items.length,1);
}));
test('capacity checks are serialized across concurrent saves',()=>temporary(async dir=>{
 const store=createAssetStore(dir,{maxCount:1,maxBytes:100});const results=await Promise.allSettled([store.save(item()),store.save(item())]);assert.equal(results.filter(x=>x.status==='fulfilled').length,1);assert.equal((await store.list()).items.length,1);
}));
test('startup cleans unindexed media left by interrupted writes but preserves indexed originals',()=>temporary(async dir=>{
 const store=createAssetStore(dir),input=item();await store.save(input);const orphan=randomUUID()+'.bin';await writeFile(join(dir,orphan),'unfinished');await createAssetStore(dir).list();assert.equal((await readdir(dir)).includes(orphan),false);assert.deepEqual((await store.load(input.id)).body,input.body);
}));
test('HTTP assets are owner-only, durable and never exposed through static paths or state',()=>temporary(async dir=>{
 let child;const base='http://127.0.0.1:4353';
 async function start(){child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('.',import.meta.url)),env:{...process.env,PORT:'4353',PERSONA_DATA:join(dir,'persona.json'),PERSONA_OWNER_TOKEN:'asset-test-owner'},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',()=>reject(Error('server exited')));});}
 async function stop(){if(child?.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;}}
 const headers={Authorization:'Bearer asset-test-owner'};
 try{await start();assert.equal((await fetch(base+'/api/assets')).status,401);const contactResponse=await fetch(base+'/api/contacts',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({name:'家人',relation:'朋友'})});const contact=await contactResponse.json();for(const method of ['GET','POST','DELETE'])assert.equal((await fetch(base+'/api/assets'+(method==='DELETE'?'/'+randomUUID():''),{method,headers:{Authorization:'Bearer '+contact.token}})).status,403);
 const input=item();let response=await fetch(base+'/api/assets',{method:'POST',headers:{...headers,'Content-Type':input.mime,'X-Asset-Id':input.id,'X-Asset-Title':encodeURIComponent(input.title)},body:input.body});assert.equal(response.status,201);await stop();await start();const list=await(await fetch(base+'/api/assets',{headers})).json();assert.equal(list.items[0].id,input.id);assert.equal(await(await fetch(base+'/api/assets/'+input.id,{headers})).text(),input.body.toString());assert.equal((await fetch(base+'/data/assets/'+input.id+'.bin')).status,401);const state=await(await fetch(base+'/api/state',{headers:{Authorization:'Bearer '+contact.token}})).json();assert.doesNotMatch(JSON.stringify(state),/小时候在成都学骑自行车/);const reviewUrl=base+'/api/assets/'+input.id+'/review';assert.equal((await fetch(reviewUrl,{headers:{Authorization:'Bearer '+contact.token}})).status,403);
 const initial=await(await fetch(reviewUrl,{headers})).json();assert.equal(initial.version,0);assert.equal(initial.text,input.body.toString());
 let result=await fetch(reviewUrl,{method:'PUT',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({version:0,text:initial.text})});assert.equal(result.status,200);
 assert.equal((await(await fetch(base+'/api/state',{headers})).json()).memories.length,0);
 for(let i=0;i<2;i++){result=await fetch(reviewUrl+'/publish',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({version:1,indices:[0],acknowledged:true,visibility:'private',contactIds:[]})});assert.equal(result.status,200);}
 let ownerState=await(await fetch(base+'/api/state',{headers})).json();assert.equal(ownerState.memories.length,1);assert.equal(ownerState.memories[0].assetId,input.id);assert.equal((await(await fetch(base+'/api/state',{headers:{Authorization:'Bearer '+contact.token}})).json()).memories.length,0);
 await stop();await start();assert.equal((await(await fetch(reviewUrl,{headers})).json()).status,'published');
 assert.equal((await fetch(base+'/api/assets/'+input.id,{headers,method:'DELETE'})).status,200);ownerState=await(await fetch(base+'/api/state',{headers})).json();assert.equal(ownerState.memories.length,0);assert.equal(ownerState.sources.length,0);assert.equal((await fetch(base+'/api/assets/'+input.id,{headers})).status,404);
 }finally{await stop();}
}));
