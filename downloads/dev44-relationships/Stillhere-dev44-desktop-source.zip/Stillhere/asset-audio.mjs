export const ASSET_AUDIO_RATE=16000,ASSET_AUDIO_SECONDS=65;
export function pcmWav(samples){
 const bytes=new Uint8Array(44+samples.length*2),v=new DataView(bytes.buffer),word=(at,text)=>[...text].forEach((c,i)=>bytes[at+i]=c.charCodeAt(0));
 word(0,'RIFF');v.setUint32(4,bytes.length-8,true);word(8,'WAVE');word(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);v.setUint32(24,ASSET_AUDIO_RATE,true);v.setUint32(28,ASSET_AUDIO_RATE*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);word(36,'data');v.setUint32(40,samples.length*2,true);
 for(let i=0;i<samples.length;i++){const x=Math.max(-1,Math.min(1,Number.isFinite(samples[i])?samples[i]:0));v.setInt16(44+i*2,Math.round(x*(x<0?32768:32767)),true);}return bytes;
}
export function readPcmWav(bytes){
 const fail=()=>{throw Object.assign(Error('需要16kHz单声道16位PCM WAV，请重新提取声音'),{status:400});};
 if(bytes.length<46||bytes.length>44+ASSET_AUDIO_RATE*2*ASSET_AUDIO_SECONDS)fail();const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),word=(at,n)=>String.fromCharCode(...bytes.subarray(at,at+n));
 if(word(0,4)!=='RIFF'||word(8,4)!=='WAVE'||word(12,4)!=='fmt '||word(36,4)!=='data'||v.getUint32(16,true)!==16||v.getUint16(20,true)!==1||v.getUint16(22,true)!==1||v.getUint32(24,true)!==16000||v.getUint16(34,true)!==16||v.getUint32(28,true)!==32000||v.getUint16(32,true)!==2||v.getUint32(4,true)!==bytes.length-8||v.getUint32(40,true)!==bytes.length-44||(bytes.length-44)%2)fail();
 const samples=new Float32Array((bytes.length-44)/2);for(let i=0;i<samples.length;i++)samples[i]=v.getInt16(44+i*2,true)/32768;return samples;
}
export async function decodeAssetAudio(blob){
 if(typeof OfflineAudioContext!=='function')throw Error('此浏览器不支持提取声音，请使用新版Chrome或Edge。');
 const context=new OfflineAudioContext(1,1,ASSET_AUDIO_RATE);let audio;try{audio=await context.decodeAudioData(await blob.arrayBuffer());}catch{throw Error('无法从素材解码声音；请确认回放有声音，或重新录制为浏览器支持的格式。');}
 if(audio.duration<=0||audio.duration>ASSET_AUDIO_SECONDS)throw Error('本版支持不超过65秒的素材，请分段采集。');
 const samples=new Float32Array(audio.length);for(let c=0;c<audio.numberOfChannels;c++){const channel=audio.getChannelData(c);for(let i=0;i<samples.length;i++)samples[i]+=channel[i]/audio.numberOfChannels;}return new Blob([pcmWav(samples)],{type:'audio/wav'});
}
