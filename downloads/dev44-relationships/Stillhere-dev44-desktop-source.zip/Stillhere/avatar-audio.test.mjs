import test from 'node:test';
import assert from 'node:assert/strict';
import {mouthLevel,smoothMouth,avatarCaption} from './avatar-audio.mjs';
test('mouth level is zero for silence and background noise, grows with actual audio energy, and ignores polarity',()=>{
 assert.equal(mouthLevel(new Float32Array(256)),0);assert.equal(mouthLevel(Array(256).fill(0.005)),0);const quiet=Float32Array.from({length:256},(_,i)=>0.08*Math.sin(i)),loud=Float32Array.from(quiet,x=>x*3);assert.ok(mouthLevel(quiet)>0);assert.ok(mouthLevel(loud)>mouthLevel(quiet));assert.ok(Math.abs(mouthLevel(quiet)-mouthLevel(Float32Array.from(quiet,x=>-x)))<1e-6);
});
test('invalid samples cannot drive a mouth, and extreme input is bounded',()=>{
 assert.equal(mouthLevel([]),0);assert.equal(mouthLevel([NaN]),0);assert.equal(mouthLevel([Infinity]),0);assert.equal(mouthLevel([100]),1);assert.equal(mouthLevel([-100]),1);
});
test('envelope smoothing remains bounded and returns to silence instead of keeping a mouth open',()=>{
 let level=0;for(let i=0;i<20;i++){level=smoothMouth(level,1,1/60);assert.ok(level>=0&&level<=1);}assert.ok(level>0.9);for(let i=0;i<60;i++)level=smoothMouth(level,0,1/60);assert.ok(level<0.001);assert.equal(smoothMouth(NaN,1),0);assert.equal(smoothMouth(0.5,1,-1),0.5);
});
test('speaking captions require actual playback and distinguish paused, waiting, and buffering',()=>{
 assert.match(avatarCaption('speaking'),/等待/);assert.match(avatarCaption('speaking',{playing:true}),/正在说话/);assert.match(avatarCaption('speaking',{paused:true}),/暂停/);assert.match(avatarCaption('speaking',{buffering:true}),/缓冲/);assert.match(avatarCaption('listening'),/聆听/);assert.match(avatarCaption('thinking'),/记忆/);assert.match(avatarCaption('review'),/核对/);assert.match(avatarCaption('failed'),/失败/);
});
test('offline demo is a bounded PCM test tone, distinct from a generated voice',async()=>{
 const {avatarTestTone}=await import('./avatar-audio.mjs');const bytes=avatarTestTone(),v=new DataView(bytes.buffer);assert.equal(new TextDecoder().decode(bytes.subarray(0,4)),'RIFF');assert.equal(v.getUint16(20,true),1);assert.equal(v.getUint16(22,true),1);assert.equal(v.getUint32(24,true),16000);assert.equal(v.getUint32(40,true),bytes.length-44);let maximum=0;for(let pos=44;pos<bytes.length;pos+=2)maximum=Math.max(maximum,Math.abs(v.getInt16(pos,true)));assert.ok(maximum>0&&maximum<32767*0.2);assert.match(avatarCaption('demo',{playing:true}),/非人物声音/);
});
