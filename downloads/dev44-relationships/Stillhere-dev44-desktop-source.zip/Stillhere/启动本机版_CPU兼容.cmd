@echo off
setlocal
cd /d "%~dp0"
set "STILLHERE_TEXT_DEVICE=cpu"
"%~dp0runtime\node.exe" "%~dp0local-launcher.mjs"
pause
