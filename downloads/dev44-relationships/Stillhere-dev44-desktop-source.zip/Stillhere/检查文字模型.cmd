@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
  echo Extract this package into your existing application folder first.
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0local-models\diagnose.mjs" --run
pause
