import test from 'node:test';
import assert from 'node:assert/strict';
import {probeOllama} from './local-models/diagnose.mjs';
const model='qwen3:4b-instruct-2507-q4_K_M';
function mock(chat,listed=true){let calls=[];return {calls,fetcher:async(url,options)=>{calls.push({url,options});return {status:url.endsWith('/api/chat')?500:200,json:async()=>url.endsWith('/api/version')?{version:'fixture'}:url.endsWith('/api/tags')?{models:listed?[{name:model,size:25}]:[]}:chat};}};}
test('reports upstream 500 detail from fixed test without any credentials or private inputs',async()=>{const f=mock({error:'runner DLL not found'}),lines=[];const result=await probeOllama('http://127.0.0.1:1234',{fetcher:f.fetcher,log:x=>lines.push(x)});assert.equal(result.status,500);assert.ok(lines.some(x=>x.includes('runner DLL not found')));const sent=JSON.parse(f.calls[2].options.body);assert.deepEqual(sent.messages,[{role:'user',content:'Reply with OK.'}]);assert.equal(sent.options.num_gpu,0);assert.equal(sent.options.num_ctx,8192);assert.equal(f.calls[2].options.redirect,'error');});
test('missing model is reported without pulling or performing inference',async()=>{const f=mock({},false);assert.equal((await probeOllama('http://127.0.0.1:1234',{fetcher:f.fetcher})).kind,'missing');assert.equal(f.calls.length,2);});
test('rejects non-loopback diagnostic endpoint',async()=>{await assert.rejects(probeOllama('https://example.com'),/loopback/);});
