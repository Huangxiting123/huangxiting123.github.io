import test from 'node:test';
import assert from 'node:assert/strict';
import {createFaceMonitor} from './face-monitor.mjs';
function clock(){let time=0,id=0;const jobs=new Map();return {now:()=>time,schedule:(f,ms)=>{jobs.set(++id,{f,at:time+ms});return id;},cancel:i=>jobs.delete(i),advance:async ms=>{time+=ms;for(const [i,j] of [...jobs])if(j.at<=time){jobs.delete(i);j.f();}await new Promise(r=>setImmediate(r));},size:()=>jobs.size};}
test('monitor checks immediately, then schedules after completion without overlapping inference',async()=>{
 const c=clock();let calls=0,resolve;const m=createFaceMonitor({...c,check:()=>{calls++;return new Promise(r=>resolve=r);}});m.start();assert.equal(calls,1);m.start();await c.advance(5000);assert.equal(calls,1);resolve({matched:true});await c.advance(0);assert.equal(m.snapshot().checks,1);await c.advance(4999);assert.equal(calls,1);await c.advance(1);assert.equal(calls,2);m.stop();resolve({matched:true});await c.advance(0);assert.equal(c.size(),0);
});
test('mismatch stops recurring checks and alerts once',async()=>{
 const c=clock(),alerts=[];const m=createFaceMonitor({...c,check:async()=>({matched:false,reason:'不同人'}),onAlert:r=>alerts.push(r)});m.start();await c.advance(0);assert.equal(m.snapshot().active,false);assert.deepEqual(alerts,['不同人']);await c.advance(60000);assert.equal(alerts.length,1);assert.equal(c.size(),0);
});
test('missing face, multiple faces, and inference failure pause instead of silently retrying',async()=>{
 for(const reason of ['没有检测到人脸','镜头中有多张脸','模型不可用']){const c=clock(),alerts=[];const m=createFaceMonitor({...c,check:async()=>{throw Error(reason);},onAlert:r=>alerts.push(r)});m.start();await c.advance(0);assert.equal(m.snapshot().status,'alert');assert.deepEqual(alerts,[reason]);assert.equal(c.size(),0);}
});
test('timeout pauses and ignores a late match',async()=>{
 const c=clock(),alerts=[];let resolve;const m=createFaceMonitor({...c,check:()=>new Promise(r=>resolve=r),onAlert:r=>alerts.push(r)});m.start();await c.advance(15000);assert.equal(m.snapshot().active,false);assert.match(alerts[0],/超时/);resolve({matched:true});await c.advance(0);assert.equal(m.snapshot().checks,0);assert.equal(c.size(),0);
});
test('withdrawal discards a late mismatch without another alert or timer',async()=>{
 const c=clock();let resolve;const m=createFaceMonitor({...c,check:()=>new Promise(r=>resolve=r),onAlert:()=>assert.fail('stale alert')});m.start();m.stop();resolve({matched:false});await c.advance(0);assert.equal(m.snapshot().status,'off');assert.equal(c.size(),0);
});
test('restart serializes with outstanding checks and does not reuse an old success',async()=>{
 const c=clock();let resolve,calls=0;const m=createFaceMonitor({...c,check:()=>{calls++;return new Promise(r=>resolve=r);}});m.start();m.stop();m.start();assert.equal(calls,1);resolve({matched:true});await c.advance(0);assert.equal(m.snapshot().lastCheckedAt,null);await c.advance(5000);assert.equal(calls,2);resolve({matched:true});await c.advance(0);assert.equal(m.snapshot().checks,1);m.stop();assert.equal(c.size(),0);
});
test('restart has a deadline even if an old inference never settles',async()=>{
 const c=clock(),alerts=[];const m=createFaceMonitor({...c,check:()=>new Promise(()=>{}),onAlert:r=>alerts.push(r)});m.start();m.stop();m.start();await c.advance(15000);assert.equal(m.snapshot().active,false);assert.equal(alerts.length,1);assert.equal(c.size(),0);
});
