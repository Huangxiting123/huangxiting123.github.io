import test from 'node:test';
import assert from 'node:assert/strict';
import {networkOptions,checkRequestOrigin,connectionInfo} from './server-network.mjs';
import {spawn,execFileSync} from 'node:child_process';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import https from 'node:https';
const secure={PORT:'4343',PERSONA_LISTEN_HOST:'0.0.0.0',PERSONA_PUBLIC_ORIGIN:'https://localhost:4343',PERSONA_TLS_CERT:'/cert',PERSONA_TLS_KEY:'/key'};
test('default network remains loopback-only and rejects unrecognized hosts and origins',()=>{
 const n=networkOptions();assert.equal(n.host,'127.0.0.1');assert.equal(n.tls,false);assert.equal(n.mode,'local-http');checkRequestOrigin(n,{host:'127.0.0.1:4317',origin:'http://127.0.0.1:4317'});assert.throws(()=>checkRequestOrigin(n,{host:'evil.test:4317'}),e=>e.status===403);for(const origin of ['null','https://evil.test','http://localhost:4317/'])assert.throws(()=>checkRequestOrigin(n,{host:'localhost:4317',origin}));
});
test('nonlocal listening cannot be enabled without explicit HTTPS origin and certificate pair',()=>{
 for(const bad of [{PERSONA_LISTEN_HOST:'0.0.0.0'},{...secure,PERSONA_TLS_KEY:''},{...secure,PERSONA_PUBLIC_ORIGIN:''},{...secure,PERSONA_PUBLIC_ORIGIN:'http://localhost:4343'}])assert.throws(()=>networkOptions(bad));assert.equal(networkOptions(secure).mode,'lan-https');
});
test('public origin rejects paths, credentials, wildcard host, fragments, query, and port mismatch',()=>{
 for(const origin of ['https://localhost:4343/path','https://user:secret@localhost:4343','https://*.example.com:4343','https://localhost:4343/#x','https://localhost:4343/?x=1','https://localhost:4344'])assert.throws(()=>networkOptions({...secure,PERSONA_PUBLIC_ORIGIN:origin}));
});
test('network configuration validates ports and bind addresses',()=>{
 for(const PORT of ['0','65536','abc','4.5'])assert.throws(()=>networkOptions({PORT}));assert.throws(()=>networkOptions({PERSONA_LISTEN_HOST:'192.0.2.1'}));const n=networkOptions({PERSONA_LISTEN_HOST:'::1'});checkRequestOrigin(n,{host:'[::1]:4317'});
});
test('default HTTPS port is canonical and transport state never exposes key or certificate paths',()=>{
 const n=networkOptions({...secure,PORT:'443',PERSONA_PUBLIC_ORIGIN:'https://localhost'});checkRequestOrigin(n,{host:'localhost',origin:'https://localhost'});const info=connectionInfo(n);assert.equal(info.secure,true);assert.doesNotMatch(JSON.stringify(info),/\/cert|\/key|TLS_KEY/);
});
test('HTTPS listener authenticates, enforces Host and Origin, and serves local mobile assets',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'stillhere-tls-'));let child;
 try{
  const cert=join(dir,'test-cert.pem'),key=join(dir,'test-key.pem');execFileSync('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],{stdio:'ignore'});
  child=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('.',import.meta.url)),env:{...process.env,...secure,PERSONA_TLS_CERT:cert,PERSONA_TLS_KEY:key,PERSONA_DATA:join(dir,'data.json'),PERSONA_OWNER_TOKEN:'tls-test-owner',PERSONA_API_URL:'',PERSONA_API_KEY:'',PERSONA_MODEL:''},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',()=>reject(Error('HTTPS server exited')));});
  const ca=await readFile(cert);async function request(path,headers={}){return new Promise((resolve,reject)=>{const req=https.get({hostname:'127.0.0.1',servername:'localhost',port:4343,path,ca,headers},res=>{let text='';res.on('data',part=>text+=part);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text}));});req.on('error',reject);});}
  assert.equal((await request('/api/state')).status,401);const auth={Authorization:'Bearer tls-test-owner'};
  const response=await request('/api/state',auth);assert.equal(response.status,200);const state=JSON.parse(response.text);assert.equal(state.connection.mode,'lan-https');assert.equal(state.connection.url,'https://localhost:4343');assert.doesNotMatch(response.text,/test-key.pem|test-cert.pem/);
  assert.equal((await request('/api/state',{...auth,Host:'evil.test:4343'})).status,403);assert.equal((await request('/api/state',{...auth,Origin:'https://evil.test'})).status,403);
  assert.equal((await request('/api/state',{...auth,Origin:'https://localhost:4343'})).status,200);
  const page=await request('/');assert.equal(page.status,200);assert.match(page.headers['permissions-policy'],/camera=\(self\)/);assert.match((await request('/connection-client.js')).text,/手机接入/);const preview=await request('/avatar-preview');assert.equal(preview.status,200);assert.match(preview.headers['content-security-policy'],/connect-src 'none'/);assert.match(preview.text,/播放本机测试音/);assert.doesNotMatch(preview.text,/tls-test-owner|test-key.pem/);
 }finally{if(child?.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;}await rm(dir,{recursive:true,force:true});}
});
