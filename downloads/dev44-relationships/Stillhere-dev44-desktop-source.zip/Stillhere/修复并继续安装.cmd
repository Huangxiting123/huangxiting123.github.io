@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
  echo Extract this repair package into your current application folder first.
  pause
  exit /b 1
)
set "STILLHERE_MODELS_HOME=E:\Stillhere-Models"
"%~dp0runtime\node.exe" "%~dp0local-models\prepare-tools.mjs" --install
if errorlevel 1 goto done
"%~dp0runtime\node.exe" "%~dp0local-models\setup.mjs"
:done
pause
