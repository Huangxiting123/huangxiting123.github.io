// Export a clearly labelled still portrait with generated audio; no lip animation.
export async function recordPortraitVideo(imageBlob,audioBlob,{signal,onProgress=()=>{}}={}){
 const mime=['video/webm;codecs=vp8,opus','video/webm'].find(t=>globalThis.MediaRecorder?.isTypeSupported(t));
 if(!mime||!HTMLCanvasElement.prototype.captureStream)throw Error('请使用新版Edge或Chrome导出视频');
 const context=new AudioContext();let bitmap,stream,source,timer,recorder;
 try{
  const audio=await context.decodeAudioData(await audioBlob.arrayBuffer());if(audio.duration>60)throw Error('首版样片最多60秒，请生成简短回答');if(signal?.aborted)throw new DOMException('已取消','AbortError');
  bitmap=await createImageBitmap(imageBlob);const canvas=document.createElement('canvas');canvas.width=720;canvas.height=720;const c=canvas.getContext('2d');
  const draw=()=>{c.fillStyle='#172e29';c.fillRect(0,0,720,720);const scale=Math.min(720/bitmap.width,660/bitmap.height),w=bitmap.width*scale,h=bitmap.height*scale;c.drawImage(bitmap,(720-w)/2,(660-h)/2,w,h);c.fillStyle='#172e29';c.fillRect(0,660,720,60);c.fillStyle='#ffffff';c.font='22px sans-serif';c.textAlign='center';c.fillText('静态形象样片 · 未驱动口型',360,698);};draw();
  stream=canvas.captureStream(20);const destination=context.createMediaStreamDestination();source=context.createBufferSource();source.buffer=audio;source.connect(destination);for(const track of destination.stream.getAudioTracks())stream.addTrack(track);
  await context.resume();if(context.state!=='running')throw Error('浏览器未允许音频处理，请再次点击导出');
  const parts=[];recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:1200000});
  return await new Promise((resolve,reject)=>{let done=false;const finish=error=>{if(done)return;done=true;signal?.removeEventListener('abort',abort);clearInterval(timer);if(recorder.state!=='inactive')recorder.stop();if(error)reject(error);};const abort=()=>finish(new DOMException('已取消','AbortError'));signal?.addEventListener('abort',abort,{once:true});recorder.ondataavailable=e=>{if(e.data.size)parts.push(e.data);};recorder.onerror=()=>finish(Error('视频导出失败'));recorder.onstop=()=>{finish();if(parts.length)resolve(new Blob(parts,{type:mime}));else reject(Error('浏览器没有生成视频数据'));};source.onended=()=>finish();const started=performance.now();timer=setInterval(()=>{draw();onProgress(Math.min(100,Math.round((performance.now()-started)/(audio.duration*10))));},100);recorder.start(250);source.start();if(signal?.aborted)abort();});
 }finally{clearInterval(timer);try{source?.stop();}catch{}if(recorder&&recorder.state!=='inactive')recorder.stop();stream?.getTracks().forEach(t=>t.stop());bitmap?.close();await context.close();}
}
