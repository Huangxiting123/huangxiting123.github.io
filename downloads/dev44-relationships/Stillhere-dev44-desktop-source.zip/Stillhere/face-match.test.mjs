import test from 'node:test';
import assert from 'node:assert/strict';
import {createFaceEnrollment,faceDescriptor,faceDistance,singleFace} from './face-match.mjs';
const vector=(x=0.1)=>Array(128).fill(x);
test('face samples must be valid nonzero finite 128-dimensional descriptors',()=>{
 for(const bad of [null,'a'.repeat(128),[],Array(128).fill(0),Array(128).fill(NaN),Array(128).fill(Infinity),vector(100)])assert.throws(()=>faceDescriptor(bad));assert.equal(faceDistance(vector(),vector()),0);
});
test('enrollment requires consistent single-person samples and limits sample count',()=>{
 const e=createFaceEnrollment(),a=vector();assert.equal(e.add(a),1);a.fill(9);assert.equal(e.verify(vector()).matched,true);assert.throws(()=>e.add(vector(1)),/差异/);e.add(vector(0.11));e.add(vector(0.12));assert.equal(e.count(),3);assert.throws(()=>e.add(vector()),/3/);
});
test('verification rejects unmatched samples and withdrawal removes enrollment',()=>{
 const e=createFaceEnrollment();assert.throws(()=>e.verify(vector()),/录入/);e.add(vector());assert.equal(e.verify(vector(0.11)).matched,true);assert.equal(e.verify(vector(1)).matched,false);e.clear();assert.equal(e.count(),0);assert.throws(()=>e.verify(vector()),/录入/);
});
test('no face, multiple faces, and poor quality cannot enroll or verify',()=>{
 const result={descriptor:vector(),detection:{score:0.9,box:{width:100,height:100}}};assert.throws(()=>singleFace([]),/没有/);assert.throws(()=>singleFace([result,result]),/多张/);assert.throws(()=>singleFace([{...result,detection:{score:0.6,box:{width:100,height:100}}}]),/不清晰/);assert.throws(()=>singleFace([{...result,detection:{score:0.9,box:{width:50,height:100}}}]),/太小/);assert.equal(singleFace([result]).length,128);
});
