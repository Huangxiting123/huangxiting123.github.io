import {randomUUID,createHash} from 'node:crypto';
const fail=(message,status=400)=>{throw Object.assign(Error(message),{status});};
export function learnPersona(state,input){
 const {requestId,memoryText='',situation='',response='',factsConfirmed=false,styleConfirmed=false}=input;
 if(typeof requestId!=='string'||!/^[a-f0-9-]{36}$/.test(requestId))fail('学习请求编号无效');
 for(const [text,max] of [[memoryText,5000],[situation,120],[response,600]])if(typeof text!=='string'||text.length>max)fail('输入内容过长或格式无效');
 const fact=memoryText.trim(),scene=situation.trim(),example=response.trim();if(!fact&&!example)fail('请填写记忆或表达示例');if(fact&&!factsConfirmed)fail('请确认记忆内容真实且允许保存');if(example&&(!scene||!styleConfirmed))fail('请填写表达场景，并确认示例可用于通用语气');
 const fingerprint=createHash('sha256').update(JSON.stringify({fact,scene,example})).digest('hex');state.learningReceipts??=[];const old=state.learningReceipts.find(x=>x.requestId===requestId);if(old){if(old.fingerprint!==fingerprint)fail('相同请求内容已变化',409);return old.result;}
 const now=new Date().toISOString();let memoryId=null;
 if(fact){memoryId=randomUUID();state.memories.push({id:memoryId,text:fact,type:'fact',date:'',factKey:'',source:'本人在分身体验中明确确认输入',status:'confirmed',visibility:'private',contactIds:[],relatedContactIds:[],createdAt:now,version:1});}
 if(example){state.profile.expressionExamples??=[];state.profile.expressionExamples.push({id:randomUUID(),situation:scene,response:example,confirmedAt:now,scope:'persona_general'});}
 state.messages=[];state.contextRevision++;const result={memoryId,exampleCount:state.profile.expressionExamples?.length||0};state.learningReceipts.push({requestId,fingerprint,result});state.learningReceipts=state.learningReceipts.slice(-100);return result;
}
export function publicVoiceEnrollment(value){if(!value)return null;const {id,assetId,referenceText,startSeconds,durationSeconds,createdAt}=value;return {id,assetId,referenceText,startSeconds,durationSeconds,createdAt};}
