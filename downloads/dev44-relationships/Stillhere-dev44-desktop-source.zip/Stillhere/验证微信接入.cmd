@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
 echo Extract this package into the existing Stillhere application folder.
 pause
 exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0wechat-probe\server.mjs"
pause
