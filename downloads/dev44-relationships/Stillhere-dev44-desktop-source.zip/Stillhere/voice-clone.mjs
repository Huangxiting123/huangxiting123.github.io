import {validateAudio} from './speech.mjs';
const fail=(status,message)=>{throw Object.assign(Error(message),{status});};
export function createVoiceClone({env=process.env,fetcher=fetch}={}){
 const url=env.PERSONA_CLONE_URL,key=env.PERSONA_CLONE_KEY;let configured=false;
 if(url&&key){const parsed=new URL(url);if(parsed.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(parsed.hostname)||parsed.username||parsed.password||parsed.search||parsed.hash)throw Error('本版专属声音服务必须是本机HTTP地址');configured=true;}
 function status(){return {configured,localOnly:true,engine:'Qwen3-TTS 0.6B Base bridge',maxCharacters:300};}
 async function synthesize(text,enrollment,{signal}={}){
 if(!configured)fail(503,'本机声音复刻服务尚未安装或启动，请先完成本地模型安装');if(!enrollment?.wavBase64)fail(409,'请先授权并保存本人声音样本');if(typeof text!=='string'||!text.trim()||text.length>300)fail(400,'专属声音每次支持1—300字，请缩短回复');
 let r;try{r=await fetcher(url,{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({text,reference_wav:enrollment.wavBase64,reference_text:enrollment.referenceText,authorized:true}),signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(600000)])});}catch(e){fail(502,e.name==='TimeoutError'?'声音生成超时，请缩短回复或检查显存':'无法连接本机声音复刻服务，或生成已取消');}
 if(!r.ok)fail(502,r.status===401?'本机声音服务凭证不匹配':'本机声音生成失败，请查看模型服务窗口；可能正在加载或显存不足');
 const type=String(r.headers.get('content-type')||'').split(';')[0];if(type!=='audio/wav')fail(502,'专属声音服务未返回WAV音频');const chunks=[];let size=0;for await(const chunk of r.body){size+=chunk.length;if(size>10*1024*1024)fail(502,'生成音频超过10MB限制');chunks.push(Buffer.from(chunk));}const bytes=Buffer.concat(chunks);validateAudio(bytes,type);return {bytes,type};
 }
 async function release({signal}={}){if(!configured)fail(503,'本机声音服务未配置');let r;try{r=await fetcher(new URL('/v1/release-voice',url).href,{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:'{}',signal:AbortSignal.any([...(signal?[signal]:[]),AbortSignal.timeout(30000)])});}catch{fail(502,'释放声音模型显存失败，请重启主程序');}if(!r.ok)fail(r.status===409?409:502,r.status===409?'声音模型仍在生成，请完成后再生成口型':'声音服务未更新，请覆盖本次更新包并重启');}
 return {status,synthesize,release};
}
