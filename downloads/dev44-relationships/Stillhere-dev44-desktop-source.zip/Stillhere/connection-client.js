export function createConnectionPanel(panel){
 const root=document.createElement('section');root.innerHTML='<h3>手机接入</h3><p data-connection-mode></p><p data-connection-address style="overflow-wrap:anywhere"></p><p data-device-readiness class="muted"></p>';panel.querySelector('.video-grid').before(root);
 const q=s=>root.querySelector(s);
 return {render(state){const c=state.connection||{};q('[data-connection-mode]').textContent=c.remoteAccess?'已启用HTTPS局域网入口。手机需与电脑处于可互通的网络，打开下方地址并使用自己的受邀凭证登录。':'当前仅限电脑本机使用，手机尚不能访问。需先配置可信HTTPS局域网入口。';q('[data-connection-address]').textContent='服务地址：'+(c.url||'未知');q('[data-device-readiness]').textContent=!window.isSecureContext?'当前页面不是浏览器可信的安全环境，摄像头与麦克风可能不可用。':!navigator.mediaDevices?.getUserMedia?'此浏览器尚不支持摄像头与麦克风采集，可继续文字交流。':'当前浏览器支持安全环境下的摄像头与麦克风采集。'+(typeof RTCPeerConnection==='function'?'支持WebRTC，但当前未建立实时数字人连接。':'此浏览器未提供WebRTC实时连接能力。');},reset(){for(const el of root.querySelectorAll('p'))el.textContent='';}};
}
